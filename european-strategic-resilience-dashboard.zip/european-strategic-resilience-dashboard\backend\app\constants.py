"""Static seed definitions: categories, regions, confidence levels, source types."""

CATEGORIES = [
    # (name, side, initial_score, confidence, trend)
    ("Hybrid Warfare", "threat", 9.7, "HIGH", "UP"),
    ("Cyber Operations", "threat", 8.5, "HIGH", "UP"),
    ("Dependency Risk", "threat", 8.5, "MEDIUM", "UP"),
    ("Strategic Divergence", "threat", 7.2, "MEDIUM", "STABLE"),
    ("Strategic Overstretch", "threat", 7.8, "MEDIUM", "UP"),
    ("Multi-Theatre Stress", "threat", 9.0, "HIGH", "UP"),
    ("Air Defence Scarcity", "threat", 8.3, "HIGH", "UP"),
    ("Critical Infrastructure Vulnerability", "threat", 8.7, "HIGH", "UP"),
    ("Trust Architecture", "threat", 6.9, "MEDIUM", "DOWN"),
    ("Information Warfare", "threat", 8.1, "MEDIUM", "UP"),
    ("Eastern Flank Pressure", "threat", 9.2, "HIGH", "UP"),
    ("Middle East Escalation", "threat", 8.4, "HIGH", "UP"),
    ("Indo-Pacific Competition", "threat", 7.5, "MEDIUM", "STABLE"),
    ("Korean Peninsula Tension", "threat", 6.8, "MEDIUM", "STABLE"),
    ("Strategic Autonomy", "resilience", 8.5, "HIGH", "UP"),
    ("Financial Resilience", "resilience", 8.0, "MEDIUM", "STABLE"),
    ("Territorial Defence", "resilience", 8.6, "HIGH", "UP"),
    ("NATO Adaptation", "resilience", 8.8, "HIGH", "UP"),
]

REGIONS = [
    ("Ukraine", 48.3794, 31.1656),
    ("Russia", 55.7558, 37.6173),
    ("Baltics", 56.8796, 24.6032),
    ("Poland", 52.2297, 21.0122),
    ("Finland", 61.9241, 25.7482),
    ("Romania", 44.4268, 26.1025),
    ("Black Sea", 43.2, 34.0),
    ("Middle East", 29.3117, 47.4833),
    ("Persian Gulf", 26.2, 51.5),
    ("South China Sea", 15.0, 115.0),
    ("Korean Peninsula", 37.5, 127.0),
    ("Arctic", 78.0, 15.0),
]

CONFIDENCE_LEVELS = [
    ("HIGH", 3, "Government statements, military reports, intelligence assessments, official publications."),
    ("MEDIUM", 2, "Major media, expert analysis, open-source intelligence."),
    ("LOW", 1, "Social media, rumours, unverified claims."),
]

SOURCE_TYPES = [
    ("Government Statement", "HIGH"),
    ("Military Report", "HIGH"),
    ("Intelligence Assessment", "HIGH"),
    ("Official Publication", "HIGH"),
    ("Major Media", "MEDIUM"),
    ("Expert Analysis", "MEDIUM"),
    ("Open-Source Intelligence", "MEDIUM"),
    ("Social Media", "LOW"),
    ("Rumour", "LOW"),
    ("Unverified Claim", "LOW"),
]
