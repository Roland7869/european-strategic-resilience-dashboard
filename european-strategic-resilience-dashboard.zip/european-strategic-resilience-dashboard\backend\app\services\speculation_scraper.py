"""Speculation feed scraper for the Feed tab (read-only). Reuses the SSRF-safe fetch.
No topic filter — these feeds are curated by category/fringe, so all headlines are kept."""
from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import select

from app.models import SpeculationItem, SpeculationSource
from app.services.scraper import fetch_source  # SSRF-validated fetch + RSS/HTML parse


async def scrape_speculation(sources: list[SpeculationSource], db) -> dict:
    new_count = 0
    errors: list[str] = []
    for src in sources:
        if not src.enabled:
            continue
        try:
            items = await fetch_source(src)
        except Exception as e:  # noqa: BLE001 - collect per-source errors
            errors.append(f"{src.name}: {e}")
            continue
        for it in items:
            exists = (
                await db.execute(
                    select(SpeculationItem).where(
                        SpeculationItem.source_id == src.id,
                        SpeculationItem.title == it["title"],
                    )
                )
            ).scalar_one_or_none()
            if exists:
                continue
            db.add(SpeculationItem(
                source_id=src.id,
                title=it["title"][:1000],
                url=it.get("url"),
                summary=(it.get("summary") or "")[:4000] or None,
                category=src.category,
                topic=src.topic,
                fringe_level=src.fringe_level,
            ))
            new_count += 1
        src.last_fetched = datetime.now(timezone.utc).replace(tzinfo=None)
    await db.commit()
    return {"sources": len([s for s in sources if s.enabled]), "new_items": new_count, "errors": errors}
