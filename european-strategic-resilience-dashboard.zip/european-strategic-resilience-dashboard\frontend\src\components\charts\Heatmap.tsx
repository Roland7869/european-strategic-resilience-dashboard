"use client";

import type { HeatmapCell } from "@/lib/types";

export function Heatmap({ data }: { data: HeatmapCell[] }) {
  const max = Math.max(
    1,
    ...data.flatMap((d) => d.weeks.map((w) => w.count))
  );
  return (
    <div className="overflow-x-auto">
      <table className="w-full border-collapse text-[11px]">
        <thead>
          <tr>
            <th className="label sticky left-0 bg-[#111827] px-2 py-1 text-left">Category</th>
            {data[0]?.weeks.map((w) => (
              <th key={w.week} className="px-1 py-1 text-center text-[9px] text-slate-500">
                {w.week.slice(5)}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {data.map((row) => (
            <tr key={row.category} className="border-t border-[#1a2334]">
              <td className="sticky left-0 max-w-[180px] truncate bg-[#111827] px-2 py-1 text-slate-300">
                <span
                  className="mr-1 inline-block h-2 w-2 rounded-full align-middle"
                  style={{ background: row.side === "threat" ? "#ef4444" : "#22c55e" }}
                />
                {row.category}
              </td>
              {row.weeks.map((w, i) => {
                const intensity = w.count / max;
                return (
                  <td key={i} className="p-0.5">
                    <div
                      className="flex h-6 items-center justify-center rounded-sm text-[10px] font-bold"
                      style={{
                        background:
                          w.count === 0
                            ? "#131c2b"
                            : `rgba(249, 115, 22, ${0.15 + intensity * 0.85})`,
                        color: intensity > 0.5 ? "#0b0f17" : "#cbd5e1",
                      }}
                      title={`${w.count} events`}
                    >
                      {w.count > 0 ? w.count : ""}
                    </div>
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
