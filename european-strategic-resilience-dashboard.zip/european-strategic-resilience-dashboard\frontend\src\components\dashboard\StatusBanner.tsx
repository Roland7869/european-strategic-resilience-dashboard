"use client";

import type { ExecutiveSummary } from "@/lib/types";
import { STATUS_COLORS, STATUS_LABELS } from "@/lib/constants";

export function StatusBanner({ summary }: { summary: ExecutiveSummary }) {
  const status = summary.overall_status;
  const color = STATUS_COLORS[status];
  return (
    <div
      className="panel relative overflow-hidden"
      style={{ borderColor: `${color}66` }}
    >
      <div
        className="absolute inset-0 opacity-[0.07]"
        style={{ background: `radial-gradient(1200px 200px at 50% 0%, ${color}, transparent)` }}
      />
      <div className="relative flex flex-wrap items-center justify-between gap-4 px-6 py-5">
        <div className="flex items-center gap-4">
          <div
            className="flex h-14 w-14 items-center justify-center rounded-full border-2"
            style={{ borderColor: color, boxShadow: `0 0 24px ${color}55` }}
          >
            <span className="h-5 w-5 animate-pulse rounded-full" style={{ background: color }} />
          </div>
          <div>
            <div className="label">Current Strategic Status</div>
            <div
              className="font-mono text-3xl font-black tracking-[0.15em]"
              style={{ color }}
            >
              {status}
            </div>
            <div className="text-xs text-slate-400">{STATUS_LABELS[status]}</div>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          <Metric label="Threat Env" value={summary.threat_score.toFixed(1)} trend={summary.threat_trend} />
          <Metric label="Resilience Env" value={summary.resilience_score.toFixed(1)} trend={summary.resilience_trend} color="#22c55e" />
          <Metric label="Surprise Index" value={summary.strategic_surprise_index.toFixed(0)} suffix="/100" />
          <Metric label="Event Density" value={summary.event_density_index.toFixed(0)} suffix="/100" />
        </div>
      </div>
    </div>
  );
}

function Metric({
  label,
  value,
  trend,
  suffix = "",
  color,
}: {
  label: string;
  value: string;
  trend?: string;
  suffix?: string;
  color?: string;
}) {
  const trendColor =
    trend === "UP" ? "#ef4444" : trend === "DOWN" ? "#22c55e" : "#8494ab";
  return (
    <div className="rounded border border-[#1f2a3d] bg-[#0d1420] px-3 py-2">
      <div className="label">{label}</div>
      <div className="flex items-baseline gap-1">
        <span className="font-mono text-xl font-bold" style={{ color: color || "#e2e8f0" }}>
          {value}
        </span>
        <span className="text-[10px] text-slate-500">{suffix}</span>
        {trend && (
          <span className="ml-1 text-[10px] font-bold" style={{ color: trendColor }}>
            {trend === "UP" ? "▲" : trend === "DOWN" ? "▼" : "■"} {trend}
          </span>
        )}
      </div>
    </div>
  );
}
