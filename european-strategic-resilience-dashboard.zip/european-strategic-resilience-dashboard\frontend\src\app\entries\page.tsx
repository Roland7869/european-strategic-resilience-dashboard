"use client";

import { useEffect, useRef, useState } from "react";
import { api } from "@/lib/api";
import type {
  Category,
  ConfidenceLevel,
  EventAIOut,
  EventCreateMinimal,
  EventFilters,
  EventItem,
  Region,
  SourceType,
} from "@/lib/types";
import { StatusBadge, ConfidenceBadge } from "@/components/ui/Badges";

const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

function ImageUpload({ eventId, onUploaded }: { eventId: number; onUploaded?: () => void }) {
  const ref = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const upload = async (files: FileList | null) => {
    if (!files?.length) return;
    setBusy(true);
    try {
      for (const f of Array.from(files)) {
        await api.uploadAttachment(eventId, f);
      }
      onUploaded?.();
    } catch (e) {
      alert(`Upload failed: ${e}`);
    } finally {
      setBusy(false);
      if (ref.current) ref.current.value = "";
    }
  };
  return (
    <div className="mt-3">
      <label className="label">Pictures</label>
      <input
        ref={ref}
        type="file"
        accept="image/jpeg,image/png,image/gif,image/webp"
        multiple
        className="mt-1 text-[11px]"
        onChange={(e) => upload(e.target.files)}
        disabled={busy}
      />
      {busy && <div className="mt-1 text-[11px] text-sky-400">Uploading…</div>}
      <div className="mt-1 text-[10px] text-slate-500">JPEG / PNG / GIF / WebP · max 5 MB each</div>
    </div>
  );
}

function AttachmentGrid({ eventId, attachments, onChanged }: {
  eventId: number;
  attachments: { id: number; path: string; filename: string }[];
  onChanged?: () => void;
}) {
  if (!attachments.length) return null;
  return (
    <div className="mt-2 flex flex-wrap gap-2">
      {attachments.map((a) => (
        <div key={a.id} className="relative">
          <a href={`${API_URL}${a.path}`} target="_blank" rel="noopener noreferrer">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={`${API_URL}${a.path}`}
              alt={a.filename}
              className="h-20 w-20 rounded border border-[#2a3a55] object-cover"
            />
          </a>
          <button
            className="absolute -right-1.5 -top-1.5 flex h-5 w-5 items-center justify-center rounded-full bg-red-500 text-[10px] text-white"
            title="Remove"
            onClick={async () => {
              if (!confirm("Remove image?")) return;
              await api.deleteAttachment(eventId, a.id);
              onChanged?.();
            }}
          >
            ×
          </button>
        </div>
      ))}
    </div>
  );
}

export default function EntriesPage() {
  const [events, setEvents] = useState<EventItem[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [regions, setRegions] = useState<Region[]>([]);
  const [sourceTypes, setSourceTypes] = useState<SourceType[]>([]);
  const [levels, setLevels] = useState<ConfidenceLevel[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [filters, setFilters] = useState<EventFilters>({});
  const [showForm, setShowForm] = useState(false);

  // Minimal intake — raw data only. The AI classifies everything else.
  const [form, setForm] = useState<EventCreateMinimal>({
    event_date: "2026-10-21",
    title: "",
    summary: "",
    source_name: "",
  });
  const [saving, setSaving] = useState(false);
  const [result, setResult] = useState<EventAIOut | null>(null);

  useEffect(() => {
    (async () => {
      try {
        const [cats, regs, stps, lvls] = await Promise.all([
          api.getCategories(),
          api.getRegions(),
          api.getSourceTypes(),
          api.getConfidenceLevels(),
        ]);
        setCategories(cats);
        setRegions(regs);
        setSourceTypes(stps);
        setLevels(lvls);
      } catch (e) {
        setError(String(e));
      }
    })();
  }, []);

  const loadEvents = async (f: EventFilters = filters) => {
    setLoading(true);
    try {
      setEvents(await api.getEvents(f));
      setError(null);
    } catch (e) {
      setError(String(e));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadEvents(filters);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filters]);

  const submit = async () => {
    if (!form.title || !form.summary) {
      alert("Title and description are required.");
      return;
    }
    setSaving(true);
    setResult(null);
    try {
      const res = await api.createEventAI(form);
      setResult(res);
      setForm({ event_date: form.event_date, title: "", summary: "", source_name: "" });
      await loadEvents(filters);
    } catch (e) {
      alert(`Failed to save entry: ${e}`);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-lg font-bold tracking-wide">New Entry</h1>
          <p className="text-xs text-slate-500">
            Just drop the raw data. The AI categorises it — confidence, categories, regions, source type and notes.
          </p>
        </div>
        <button className="btn btn-primary" onClick={() => setShowForm((s) => !s)}>
          {showForm ? "Close" : "+ New Entry"}
        </button>
      </div>

      {showForm && (
        <div className="panel">
          <div className="panel-header">
            <span className="text-[12px] font-bold uppercase tracking-wider">Collect Data</span>
            <span className="text-[10px] text-slate-500">AI does the rest</span>
          </div>
          <div className="grid grid-cols-1 gap-3 p-4 md:grid-cols-3">
            <div>
              <label className="label">Date</label>
              <input
                type="date"
                className="mt-1 w-full"
                value={form.event_date}
                onChange={(e) => setForm({ ...form, event_date: e.target.value })}
              />
            </div>
            <div className="md:col-span-2">
              <label className="label">Source (optional)</label>
              <input
                className="mt-1 w-full"
                value={form.source_name}
                onChange={(e) => setForm({ ...form, source_name: e.target.value })}
                placeholder="e.g. Reuters, NATO Official Statement"
              />
            </div>
            <div className="md:col-span-3">
              <label className="label">Title</label>
              <input
                className="mt-1 w-full"
                value={form.title}
                onChange={(e) => setForm({ ...form, title: e.target.value })}
                placeholder="Short headline for the event"
              />
            </div>
            <div className="md:col-span-3">
              <label className="label">Description (the raw data)</label>
              <textarea
                rows={5}
                className="mt-1 w-full"
                value={form.summary}
                onChange={(e) => setForm({ ...form, summary: e.target.value })}
                placeholder="Paste or type what happened. The AI will classify it — you don't need to pick categories, regions or confidence."
              />
            </div>
            <div className="md:col-span-3 flex justify-end gap-2">
              <button className="btn" onClick={() => setShowForm(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={submit} disabled={saving}>
                {saving ? "AI analysing…" : "Save & Auto-Classify"}
              </button>
            </div>
          </div>

          {saving && (
            <div className="border-t border-[#1f2a3d] px-4 py-3 text-[12px] text-sky-400">
              <span className="mr-2 inline-block h-3 w-3 animate-spin rounded-full border-2 border-sky-400 border-t-transparent align-[-2px]" />
              LM Studio is classifying this entry…
            </div>
          )}

          {result && (
            <div className="border-t border-[#1f2a3d] bg-[#0d1420] px-4 py-3">
              <div className="label mb-2">
                {result.ai_available ? "AI classification applied" : "Saved (AI offline) — manual review needed"}
              </div>
              <div className="flex flex-wrap items-center gap-2 text-[12px]">
                <span className="text-slate-500">Entry</span>
                <span className="font-mono text-sky-400">#{result.event.entry_number}</span>
                <StatusBadge status={result.event.status} />
                <ConfidenceBadge level={result.ai_confidence} />
                <span className="text-slate-500">·</span>
                <span className="text-slate-400">{result.ai_source_type}</span>
              </div>
              <div className="mt-2 flex flex-wrap gap-1.5">
                {result.ai_categories.map((c) => (
                  <span key={c} className="rounded bg-[#1a2334] px-2 py-0.5 text-[11px] text-slate-300">▸ {c}</span>
                ))}
                {result.ai_regions.map((r) => (
                  <span key={r} className="rounded bg-emerald-900/40 px-2 py-0.5 text-[11px] text-emerald-300">◎ {r}</span>
                ))}
              </div>
              {result.proposals_created > 0 && (
                <div className="mt-2 text-[11px] text-amber-400">
                  {result.proposals_created} score change(s) queued for your approval in the AI Assistant.
                </div>
              )}
              <ImageUpload
                eventId={result.event.id}
                onUploaded={async () => {
                  await loadEvents(filters);
                  // Refresh the result event so the new picture shows immediately.
                  try {
                    const fresh = await api.getEvent(result.event.id);
                    setResult({ ...result, event: fresh });
                  } catch { /* ignore */ }
                }}
              />
            </div>
          )}
        </div>
      )}

      {/* Filters */}
      <div className="panel">
        <div className="panel-header">
          <span className="text-[12px] font-bold uppercase tracking-wider">Filters</span>
          <button className="text-[11px] text-sky-400 hover:underline" onClick={() => setFilters({})}>
            Reset
          </button>
        </div>
        <div className="grid grid-cols-2 gap-3 p-3 md:grid-cols-6">
          <div>
            <label className="label">Date From</label>
            <input
              type="date"
              className="mt-1 w-full"
              value={filters.date_from || ""}
              onChange={(e) => setFilters({ ...filters, date_from: e.target.value })}
            />
          </div>
          <div>
            <label className="label">Date To</label>
            <input
              type="date"
              className="mt-1 w-full"
              value={filters.date_to || ""}
              onChange={(e) => setFilters({ ...filters, date_to: e.target.value })}
            />
          </div>
          <div>
            <label className="label">Confidence</label>
            <select
              className="mt-1 w-full"
              value={filters.confidence || ""}
              onChange={(e) => setFilters({ ...filters, confidence: e.target.value })}
            >
              <option value="">All</option>
              {levels.map((l) => (
                <option key={l.id} value={l.name}>{l.name}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="label">Category</label>
            <select
              className="mt-1 w-full"
              value={filters.category_id || ""}
              onChange={(e) => setFilters({ ...filters, category_id: e.target.value ? Number(e.target.value) : undefined })}
            >
              <option value="">All</option>
              {categories.map((c) => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="label">Region</label>
            <select
              className="mt-1 w-full"
              value={filters.region_id || ""}
              onChange={(e) => setFilters({ ...filters, region_id: e.target.value ? Number(e.target.value) : undefined })}
            >
              <option value="">All</option>
              {regions.map((r) => (
                <option key={r.id} value={r.id}>{r.name}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="label">Source Type</label>
            <select
              className="mt-1 w-full"
              value={filters.source_type_id || ""}
              onChange={(e) => setFilters({ ...filters, source_type_id: e.target.value ? Number(e.target.value) : undefined })}
            >
              <option value="">All</option>
              {sourceTypes.map((t) => (
                <option key={t.id} value={t.id}>{t.name}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Feed */}
      <div className="panel">
        <div className="panel-header">
          <span className="text-[12px] font-bold uppercase tracking-wider">Entry Feed</span>
          <span className="text-[10px] text-slate-500">{events.length} entries · newest first</span>
        </div>
        {error && <div className="p-4 text-sm text-red-400">{error}</div>}
        {loading ? (
          <div className="p-8 text-center text-sm text-slate-500">Loading…</div>
        ) : events.length === 0 ? (
          <div className="p-8 text-center text-sm text-slate-500">No entries match the current filters.</div>
        ) : (
          <div className="divide-y divide-[#1a2334]">
            {events.map((e) => (
              <EntryRow key={e.id} event={e} onChanged={() => loadEvents(filters)} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function EntryRow({ event: e, onChanged }: { event: EventItem; onChanged?: () => void }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="px-3 py-2.5 transition hover:bg-[#141d2e]">
      <button className="w-full text-left" onClick={() => setOpen((o) => !o)}>
        <div className="flex flex-wrap items-center gap-2">
          <span className="font-mono text-[11px] font-bold text-sky-400">#{e.entry_number}</span>
          <span className="font-mono text-[11px] text-slate-500">{e.event_date}</span>
          <StatusBadge status={e.status} />
          <ConfidenceBadge level={e.confidence_level.name} />
          <span className="text-[13px] font-semibold text-slate-200">{e.title}</span>
          {e.attachments?.length > 0 && (
            <span className="text-[10px] text-slate-500">🖼 {e.attachments.length}</span>
          )}
        </div>
        <div className="mt-1 line-clamp-1 text-[11px] text-slate-500">{e.summary}</div>
      </button>
      {open && (
        <div className="mt-2 grid grid-cols-1 gap-3 rounded border border-[#1f2a3d] bg-[#0d1420] p-3 md:grid-cols-2">
          <div>
            <div className="label">Evidence</div>
            <p className="mt-1 text-[12px] text-slate-300">{e.evidence_notes || "—"}</p>
            <div className="label mt-2">Source</div>
            <p className="mt-1 text-[12px] text-slate-300">
              {e.source.name} · {e.source_type.name}
            </p>
            <ImageUpload eventId={e.id} onUploaded={onChanged} />
          </div>
          <div>
            <div className="label">Interpretation (AI)</div>
            <p className="mt-1 text-[12px] text-slate-300">{e.analyst_notes || "—"}</p>
            <div className="label mt-2">Affected Categories</div>
            <div className="mt-1 flex flex-wrap gap-1">
              {e.category_links.map((cl) => (
                <span key={cl.category_id} className="rounded bg-[#1a2334] px-1.5 py-0.5 text-[10px] text-slate-300">
                  {cl.category.name} ({cl.impact_delta > 0 ? "+" : ""}
                  {cl.impact_delta})
                </span>
              ))}
            </div>
            <div className="label mt-2">Regions</div>
            <div className="mt-1 flex flex-wrap gap-1">
              {e.region_links.map((rl) => (
                <span key={rl.region_id} className="rounded bg-[#1a2334] px-1.5 py-0.5 text-[10px] text-slate-300">
                  {rl.region.name}
                </span>
              ))}
            </div>
            {e.attachments?.length > 0 && (
              <>
                <div className="label mt-2">Pictures</div>
                <AttachmentGrid eventId={e.id} attachments={e.attachments} onChanged={onChanged} />
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
