import json
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.database import get_db
from app.models import AIProposal, Category, Event, EventCategory, ProposalStatus
from app.schemas import AIPromptIn, AIProposalDecision, AIProposalOut, WatchlistOut
from app.services import ai_service
from app.services.scoring import get_category_scores

router = APIRouter(prefix="/ai", tags=["ai"])


def _build_context(db: AsyncSession, context: str | None = None) -> str:
    if context:
        return context
    # Build a compact context from recent events + category scores
    cats = get_category_scores.__wrapped__ if hasattr(get_category_scores, "__wrapped__") else None
    return ""  # populated by caller


async def _events_context(db: AsyncSession, limit: int = 15) -> str:
    from app.models import ConfidenceLevel, SourceType
    result = await db.execute(
        select(Event)
        .options(
            selectinload(Event.source_type),
            selectinload(Event.confidence_level),
            selectinload(Event.category_links).selectinload(EventCategory.category),
        )
        .order_by(Event.event_date.desc())
        .limit(limit)
    )
    events = list(result.scalars().unique().all())
    lines = []
    for e in events:
        cats = ", ".join(l.category.name for l in e.category_links)
        summary = (e.summary or "").strip()
        if len(summary) > 300:
            summary = summary[:300] + "…"
        title = e.title if len(e.title) <= 120 else e.title[:120] + "…"
        lines.append(
            f"[{e.event_date}] {title}\n"
            f"  Status: {e.status} | Source: {e.source_type.name} | Confidence: {e.confidence_level.name}\n"
            f"  Categories: {cats}\n"
            f"  Summary: {summary}"
        )
    cat_lines = []
    cats = await get_category_scores(db)
    for c in cats:
        cat_lines.append(f"  - {c.name} ({c.side}): {c.current_score}/10 [{c.confidence}] {c.trend}")

    from app.services.scoring import flashpoints
    flash = await flashpoints(db)
    flash_lines = [
        f"  - {f['region']} ({f['event_count']} events): " +
        ", ".join(f"{c['name']} {c['score']}/10" for c in f["top_categories"])
        for f in flash
    ]
    flash_block = "FLASHPOINTS (hottest regions):\n" + ("\n".join(flash_lines) if flash_lines else "  (none)")

    return (
        flash_block + "\n\nCATEGORY SCORES:\n" + "\n".join(cat_lines) +
        "\n\nRECENT EVENTS:\n" + "\n\n".join(lines)
    )


@router.get("/health")
async def ai_health():
    return await ai_service.health_check()


@router.post("/run")
async def run_capability(payload: AIPromptIn, db: AsyncSession = Depends(get_db)):
    context = payload.context or await _events_context(db)
    try:
        raw = await ai_service.run_capability(payload.capability, context)
    except Exception as e:  # noqa: BLE001
        raise HTTPException(status_code=502, detail=f"LM Studio error: {e}")

    proposals = []
    if payload.capability == "suggest_scores":
        proposals = ai_service.parse_score_proposals(raw)
        from app.services import approvals as _appr
        auto = await _appr.is_auto_approve(db)
        for p in proposals:
            cat_result = await db.execute(select(Category).where(Category.name == p.get("category")))
            cat = cat_result.scalar_one_or_none()
            proposal = AIProposal(
                category_id=cat.id if cat else None,
                proposed_changes_json=json.dumps(p),
                rationale=p.get("rationale"),
                status=ProposalStatus.PENDING.value,
            )
            db.add(proposal)
            if auto:
                await db.flush()
                await _appr.approve_and_apply(db, proposal)
        await db.commit()

    return {"raw": raw, "proposals": proposals}


@router.post("/watchlist", response_model=WatchlistOut)
async def generate_watchlist(db: AsyncSession = Depends(get_db)):
    """Generate the Strategic Watch List using the Senior Strategic Warning Analyst prompt.
    Base: current category scores + flashpoints + recent events. Monitors indicators and
    trigger conditions only — never forecasts outcomes."""
    from app.services.scoring import compute_summary, flashpoints

    summary = await compute_summary(db)
    events_ctx = await _events_context(db)
    header = (
        "CURRENT DASHBOARD STATE (use this as the basis for all indicators):\n"
        f"- Overall status: {summary.get('overall_status')}\n"
        f"- Threat environment: {summary.get('threat_score')}/10 (trend {summary.get('threat_trend')})\n"
        f"- Resilience environment: {summary.get('resilience_score')}/10 (trend {summary.get('resilience_trend')})\n"
        f"- Strategic Friction Index: {summary.get('strategic_friction_index')}/10\n"
        f"- Strategic Surprise Index: {summary.get('strategic_surprise_index')}/10\n"
        f"- Event Density: {summary.get('event_density_index')}/100\n\n"
    )
    messages = [
        {"role": "system", "content": ai_service.WATCHLIST_PROMPT},
        {"role": "user", "content": header + events_ctx},
    ]
    try:
        md = await ai_service.call_llm(messages, temperature=0.4)
    except Exception as e:  # noqa: BLE001
        raise HTTPException(status_code=502, detail=f"LM Studio error: {e}")
    return WatchlistOut(markdown=md)


@router.get("/proposals", response_model=list[AIProposalOut])
async def list_proposals(db: AsyncSession = Depends(get_db), status: str | None = None):
    q = select(AIProposal).order_by(AIProposal.created_at.desc())
    if status:
        q = q.where(AIProposal.status == status)
    result = await db.execute(q)
    return list(result.scalars().all())


@router.post("/proposals/{proposal_id}/decide", response_model=AIProposalOut)
async def decide_proposal(proposal_id: int, payload: AIProposalDecision, db: AsyncSession = Depends(get_db)):
    if payload.decision not in ("APPROVED", "REJECTED"):
        raise HTTPException(status_code=400, detail="decision must be APPROVED or REJECTED")
    proposal = await db.get(AIProposal, proposal_id)
    if not proposal:
        raise HTTPException(status_code=404, detail="Proposal not found")
    proposal.status = payload.decision
    proposal.reviewed_at = datetime.utcnow()

    if payload.decision == "APPROVED" and proposal.category_id:
        changes = json.loads(proposal.proposed_changes_json)
        cat = await db.get(Category, proposal.category_id)
        if cat:
            if "new_score" in changes:
                cat.current_score = min(max(float(changes["new_score"]), 0.0), 10.0)
            if "confidence" in changes and changes["confidence"] in ("LOW", "MEDIUM", "HIGH"):
                cat.confidence = changes["confidence"]
            if "trend" in changes and changes["trend"] in ("UP", "DOWN", "STABLE"):
                cat.trend = changes["trend"]

    await db.commit()
    await db.refresh(proposal)
    return proposal
