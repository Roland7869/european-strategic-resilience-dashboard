import json
from datetime import date, datetime, timedelta

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.database import get_db
from app.models import AIProposal, Category, Event, EventCategory, ProposalStatus
from app.schemas import (
    AIPromptIn, AIProposalDecision, AIProposalOut, CascadeOut, ChatIn, ChatOut,
    WatchlistOut
)
from app.services import ai_service
from app.services.scoring import get_category_scores

router = APIRouter(prefix="/ai", tags=["ai"])


def _build_context(db: AsyncSession, context: str | None = None) -> str:
    if context:
        return context
    # Build a compact context from recent events + category scores
    cats = get_category_scores.__wrapped__ if hasattr(get_category_scores, "__wrapped__") else None
    return ""  # populated by caller


async def _events_context(db: AsyncSession, limit: int = 15) -> str:
    from app.models import ConfidenceLevel, SourceType
    result = await db.execute(
        select(Event)
        .options(
            selectinload(Event.source_type),
            selectinload(Event.confidence_level),
            selectinload(Event.category_links).selectinload(EventCategory.category),
        )
        .order_by(Event.event_date.desc())
        .limit(limit)
    )
    events = list(result.scalars().unique().all())
    lines = []
    for e in events:
        cats = ", ".join(l.category.name for l in e.category_links)
        summary = (e.summary or "").strip()
        if len(summary) > 300:
            summary = summary[:300] + "…"
        title = e.title if len(e.title) <= 120 else e.title[:120] + "…"
        lines.append(
            f"[{e.event_date}] {title}\n"
            f"  Status: {e.status} | Source: {e.source_type.name} | Confidence: {e.confidence_level.name}\n"
            f"  Categories: {cats}\n"
            f"  Summary: {summary}"
        )
    cat_lines = []
    cats = await get_category_scores(db)
    for c in cats:
        cat_lines.append(f"  - {c.name} ({c.side}): {c.current_score}/10 [{c.confidence}] {c.trend}")

    from app.services.scoring import flashpoints
    flash = await flashpoints(db)
    flash_lines = [
        f"  - {f['region']} ({f['event_count']} events): " +
        ", ".join(f"{c['name']} {c['score']}/10" for c in f["top_categories"])
        for f in flash
    ]
    flash_block = "FLASHPOINTS (hottest regions):\n" + ("\n".join(flash_lines) if flash_lines else "  (none)")

    return (
        flash_block + "\n\nCATEGORY SCORES:\n" + "\n".join(cat_lines) +
        "\n\nRECENT EVENTS:\n" + "\n\n".join(lines)
    )


@router.get("/health")
async def ai_health():
    return await ai_service.health_check()


@router.post("/run")
async def run_capability(payload: AIPromptIn, db: AsyncSession = Depends(get_db)):
    context = payload.context or await _events_context(db)
    try:
        raw = await ai_service.run_capability(payload.capability, context)
    except Exception as e:  # noqa: BLE001
        raise HTTPException(status_code=502, detail=f"LM Studio error: {e}")

    proposals = []
    if payload.capability == "suggest_scores":
        proposals = ai_service.parse_score_proposals(raw)
        from app.services import approvals as _appr
        auto = await _appr.is_auto_approve(db)
        for p in proposals:
            cat_result = await db.execute(select(Category).where(Category.name == p.get("category")))
            cat = cat_result.scalar_one_or_none()
            proposal = AIProposal(
                category_id=cat.id if cat else None,
                proposed_changes_json=json.dumps(p),
                rationale=p.get("rationale"),
                status=ProposalStatus.PENDING.value,
            )
            db.add(proposal)
            if auto:
                await db.flush()
                await _appr.approve_and_apply(db, proposal)
        await db.commit()

    return {"raw": raw, "proposals": proposals}


@router.post("/watchlist", response_model=WatchlistOut)
async def generate_watchlist(db: AsyncSession = Depends(get_db)):
    """Generate the Strategic Watch List using the Senior Strategic Warning Analyst prompt.
    Base: current category scores + flashpoints + recent events. Monitors indicators and
    trigger conditions only — never forecasts outcomes."""
    from app.services.scoring import compute_summary, flashpoints

    summary = await compute_summary(db)
    events_ctx = await _events_context(db)
    header = (
        "CURRENT DASHBOARD STATE (use this as the basis for all indicators):\n"
        f"- Overall status: {summary.get('overall_status')}\n"
        f"- Threat environment: {summary.get('threat_score')}/10 (trend {summary.get('threat_trend')})\n"
        f"- Resilience environment: {summary.get('resilience_score')}/10 (trend {summary.get('resilience_trend')})\n"
        f"- Strategic Friction Index: {summary.get('strategic_friction_index')}/10\n"
        f"- Strategic Surprise Index: {summary.get('strategic_surprise_index')}/10\n"
        f"- Event Density: {summary.get('event_density_index')}/100\n\n"
    )
    messages = [
        {"role": "system", "content": ai_service.WATCHLIST_PROMPT},
        {"role": "user", "content": header + events_ctx},
    ]
    try:
        md = await ai_service.call_llm(messages, temperature=0.4)
    except Exception as e:  # noqa: BLE001
        raise HTTPException(status_code=502, detail=f"LM Studio error: {e}")
    return WatchlistOut(markdown=md)


async def _cascade_context(db: AsyncSession) -> str:
    """Aggregate ALL ESRD data sources into one bounded context for cascade analysis."""
    from app.services.scoring import compute_summary, flashpoints, get_category_scores
    from app.models import CyberAttack, PowerOutage, ScrapedItem
    from app.services.scoring_discipline import strategic_friction_index

    summary = await compute_summary(db)
    sfi = await strategic_friction_index(db)
    cats = await get_category_scores(db)
    flash = await flashpoints(db, limit=8)

    parts: list[str] = []

    # 1) Dashboard metrics
    parts.append("=== DASHBOARD METRICS ===")
    parts.append(
        f"Status: {summary.get('overall_status')} | Threat: {summary.get('threat_score')}/10 "
        f"({summary.get('threat_trend')}) | Resilience: {summary.get('resilience_score')}/10 "
        f"({summary.get('resilience_trend')}) | Surprise: {summary.get('strategic_surprise_index')}/10 "
        f"| Event Density: {summary.get('event_density_index')}/100"
    )
    parts.append(
        "Strategic Friction Index: "
        f"{sfi['index']}/10 — " + ", ".join(f"{k.replace('_',' ')} {v}" for k, v in sfi["signals"].items())
    )

    # 2) Categories (threat + resilience) with score/confidence/trend/events
    parts.append("\n=== THREAT CATEGORIES ===")
    for c in cats:
        if c.side == "threat":
            parts.append(
                f"- {c.name}: {c.current_score}/10 | {c.trend} | conf {c.confidence} "
                f"({c.confidence_pct:.0f}%) | events {c.corroboration_count}"
            )
    parts.append("\n=== RESILIENCE CATEGORIES ===")
    for c in cats:
        if c.side == "resilience":
            parts.append(
                f"- {c.name}: {c.current_score}/10 | {c.trend} | conf {c.confidence} "
                f"({c.confidence_pct:.0f}%) | events {c.corroboration_count}"
            )

    # 3) Flashpoints
    parts.append("\n=== FLASHPOINTS (hottest regions) ===")
    for f in flash:
        top = ", ".join(f"{c['name']} {c['score']}" for c in f["top_categories"])
        parts.append(f"- {f['region']}: {f['event_count']} events | {top}")

    # 4) Recent events
    parts.append("\n=== RECENT EVENTS ===")
    result = await db.execute(
        select(Event).options(
            selectinload(Event.source_type),
            selectinload(Event.confidence_level),
            selectinload(Event.category_links).selectinload(EventCategory.category),
        ).order_by(Event.event_date.desc()).limit(15)
    )
    for e in result.scalars().unique().all():
        cl = ", ".join(l.category.name for l in e.category_links)
        summ = (e.summary or "")[:160]
        parts.append(f"- [{e.event_date}] {e.title} ({e.status}/{e.confidence_level.name}) — {cl}: {summ}")

    # 5) OSINT (recent scraped)
    osint = (await db.execute(
        select(ScrapedItem).order_by(ScrapedItem.fetched_at.desc()).limit(12)
    )).scalars().all()
    if osint:
        parts.append("\n=== OSINT REPORTS ===")
        for i in osint:
            parts.append(f"- {i.title}")

    # 6) Cyber incidents
    cyber = (await db.execute(
        select(CyberAttack).order_by(CyberAttack.scraped_at.desc()).limit(12)
    )).scalars().all()
    if cyber:
        parts.append("\n=== CYBER INCIDENTS ===")
        for c in cyber:
            parts.append(f"- [{c.severity}/{c.attack_type}] {c.title}")

    # 7) Outages / infrastructure
    outages = (await db.execute(
        select(PowerOutage).order_by(PowerOutage.scraped_at.desc()).limit(12)
    )).scalars().all()
    if outages:
        parts.append("\n=== POWER OUTAGE REPORTS ===")
        for o in outages:
            loc = ", ".join(x for x in [o.city, o.region, o.country] if x)
            parts.append(f"- [{o.outage_type}] {loc}: {o.title}")

    # 8) Preparation indicators
    from app.api.preps import compute_readiness
    r = await compute_readiness(db)
    parts.append("\n=== PREPARATION INDICATORS ===")
    parts.append(
        f"Household {r.household_size} person(s): readiness {r.household_readiness}/10 "
        f"(economic {r.economic}, infrastructure {r.infrastructure}, threat {r.threat_environment})"
    )

    return "\n".join(parts)


@router.post("/cascade", response_model=CascadeOut)
async def generate_cascade(db: AsyncSession = Depends(get_db)):
    """Cascade Risk Assessment — systemic interaction-risk analysis across all ESRD data.
    Not a prediction engine: identifies where simultaneous developments could compound."""
    context = await _cascade_context(db)
    messages = [
        {"role": "system", "content": ai_service.CASCADE_PROMPT},
        {"role": "user", "content": "CURRENT ESRD DATA:\n\n" + context},
    ]
    try:
        md = await ai_service.call_llm(messages, temperature=0.3)
    except Exception as e:  # noqa: BLE001
        raise HTTPException(status_code=502, detail=f"LM Studio error: {e}")
    return CascadeOut(markdown=md)


async def _dashboard_chat_context(db: AsyncSession) -> str:
    """Everything the Score Analyst needs to explain WHY scores moved."""
    from app.services.scoring import compute_summary, get_category_scores
    from app.services.scoring_discipline import strategic_friction_index

    summary = await compute_summary(db)
    sfi = await strategic_friction_index(db)
    cats = await get_category_scores(db)

    parts: list[str] = []

    # 1) The scoring model rules (the "why")
    parts.append("=== SCORING MODEL RULES (the reason scores move as they do) ===")
    parts.append(
        "- STATE vs SIGNAL: additional reporting that corroborates an already-known situation "
        "raises CONFIDENCE, not the score. The score only moves on a MATERIAL STATE CHANGE "
        "(outside the 48h corroboration window, or CRITICAL severity).\n"
        "- CONFIDENCE-WEIGHTED IMPACT: HIGH=100%, MEDIUM=50%, LOW=25% of a proposed delta. "
        "Unverified social media = 0% (watchlist only).\n"
        "- RATE LIMITS (non-CRITICAL): max 0.5 per event, 0.25 per rolling 24h, 0.50 per rolling 48h.\n"
        "- 10.0 CAP: at most ~15% of threat indicators may sit at 10.0; excess demoted to 9.5.\n"
        "- EVENT FREQUENCY is a SEPARATE metric (Event Density) and NEVER drives scores."
    )

    # 2) Current category state
    parts.append("\n=== CURRENT CATEGORY STATE (score | peak | confidence | trend | corroboration | last occurrence) ===")
    for c in cats:
        mark = " [AT MAX]" if c.current_score >= 9.99 else ""
        peak_note = ""
        if (c.peak_score or 0) >= 9.99 and c.current_score < 9.99:
            peak_note = f" (peaked at {c.peak_score:.1f}, now brought down)"
        parts.append(
            f"- {c.name} ({c.side}): {c.current_score:.2f}/10{mark} | peak {c.peak_score:.1f}{peak_note} | "
            f"{c.trend} | conf {c.confidence} ({c.confidence_pct:.0f}%) | {c.corroboration_count} sources"
        )

    # 3) Recent score changes with rationale (why scores moved)
    proposals = (await db.execute(
        select(AIProposal)
        .where(AIProposal.status == ProposalStatus.APPROVED.value)
        .order_by(AIProposal.created_at.desc())
        .limit(25)
    )).scalars().all()
    if proposals:
        parts.append("\n=== RECENT SCORE CHANGES (approved, with rationale) ===")
        for p in proposals:
            cat_name = ""
            if p.category_id:
                cat = await db.get(Category, p.category_id)
                cat_name = cat.name if cat else ""
            try:
                ch = json.loads(p.proposed_changes_json or "{}")
            except json.JSONDecodeError:
                ch = {}
            delta = ch.get("impact_delta", ch.get("new_score", ""))
            rat = (p.rationale or ch.get("rationale") or "")[:200]
            parts.append(f"- {cat_name}: change {delta} — {rat}")

    # 4) Activity metrics (for "despite activity increasing")
    from app.services.scoring import event_density_index
    density = await event_density_index(db)
    from app.models import Event
    from sqlalchemy import func
    recent_count = (await db.execute(
        select(func.count(Event.id)).where(
            Event.event_date >= date.today() - timedelta(days=7)
        )
    )).scalar() or 0
    parts.append("\n=== ACTIVITY (frequency — separate from scores) ===")
    parts.append(f"- Event Density: {density}/100 | events in last 7 days: {recent_count}")

    # 5) Current overall state
    parts.append("\n=== CURRENT STATE ===")
    parts.append(
        f"Status {summary.get('overall_status')} | Threat {summary.get('threat_score')}/10 "
        f"({summary.get('threat_trend')}) | Resilience {summary.get('resilience_score')}/10 "
        f"({summary.get('resilience_trend')}) | SFI {sfi['index']}/10 | "
        f"Surprise {summary.get('strategic_surprise_index')}/10"
    )
    return "\n".join(parts)


@router.post("/dashboard-chat", response_model=ChatOut)
async def dashboard_chat(payload: ChatIn, db: AsyncSession = Depends(get_db)):
    """Chat with the Score Analyst: explains why scores rose/feld, grounded in the
    scoring model rules + actual data (incl. 'why down despite more activity')."""
    context = await _dashboard_chat_context(db)
    messages = [{"role": "system", "content": ai_service.DASHBOARD_CHAT_PROMPT}]
    for m in payload.messages[-12:]:
        if m.role in ("user", "assistant"):
            messages.append({"role": m.role, "content": m.content})
    if not any(m["role"] == "user" for m in messages):
        raise HTTPException(status_code=400, detail="At least one user message is required")
    messages.append({"role": "user", "content": "CURRENT ESRD DATA:\n\n" + context})
    try:
        reply = await ai_service.call_llm(messages, temperature=0.4)
    except Exception as e:  # noqa: BLE001
        raise HTTPException(status_code=502, detail=f"LM Studio error: {e}")
    return ChatOut(reply=reply)


@router.get("/proposals", response_model=list[AIProposalOut])
async def list_proposals(db: AsyncSession = Depends(get_db), status: str | None = None):
    q = select(AIProposal).order_by(AIProposal.created_at.desc())
    if status:
        q = q.where(AIProposal.status == status)
    result = await db.execute(q)
    return list(result.scalars().all())


@router.post("/proposals/{proposal_id}/decide", response_model=AIProposalOut)
async def decide_proposal(proposal_id: int, payload: AIProposalDecision, db: AsyncSession = Depends(get_db)):
    if payload.decision not in ("APPROVED", "REJECTED"):
        raise HTTPException(status_code=400, detail="decision must be APPROVED or REJECTED")
    proposal = await db.get(AIProposal, proposal_id)
    if not proposal:
        raise HTTPException(status_code=404, detail="Proposal not found")
    proposal.status = payload.decision
    proposal.reviewed_at = datetime.utcnow()

    if payload.decision == "APPROVED" and proposal.category_id:
        changes = json.loads(proposal.proposed_changes_json)
        cat = await db.get(Category, proposal.category_id)
        if cat:
            if "new_score" in changes:
                cat.current_score = min(max(float(changes["new_score"]), 0.0), 10.0)
            if "confidence" in changes and changes["confidence"] in ("LOW", "MEDIUM", "HIGH"):
                cat.confidence = changes["confidence"]
            if "trend" in changes and changes["trend"] in ("UP", "DOWN", "STABLE"):
                cat.trend = changes["trend"]

    await db.commit()
    await db.refresh(proposal)
    return proposal
