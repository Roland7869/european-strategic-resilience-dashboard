"""Power-outage scraper: fetch location-scoped feeds and classify each item as
SCHEDULED or UNSCHEDULED. Reuses the SSRF-safe fetch from the OSINT scraper."""
from __future__ import annotations

import re
from datetime import datetime, timezone

from sqlalchemy import select

from app.models import PowerOutage, PowerOutageSource
from app.services.scraper import _parse_html, _parse_rss, fetch_source  # reuse parsers + SSRF-safe fetch

# Explicitly scheduled => planned maintenance / pre-announced.
SCHEDULED_KEYWORDS = [
    "planned outage", "planned power", "planned interruption", "planned maintenance",
    "scheduled outage", "scheduled maintenance", "scheduled interruption",
    "maintenance window", "pre-announced", "planned shutdown", "will be disconnected",
    "planned cut", "planned works", "power will be", "planned supply",
]
# Any mention of an outage / power loss. Unscheduled if not explicitly planned.
OUTAGE_KEYWORDS = [
    "outage", "blackout", "power cut", "power out", "power loss", "lost power",
    "without power", "no power", "electricity outage", "power failure", "grid failure",
    "unscheduled", "unplanned", "interruption", "supply disrupted", "power down",
    "electricity cut", "network fault", "fault", "restoration",
]


def classify_outage(text: str) -> str | None:
    """Return 'SCHEDULED' | 'UNSCHEDULED' | None (not an outage item)."""
    t = (text or "").lower()
    is_scheduled = any(k in t for k in SCHEDULED_KEYWORDS)
    is_outage = is_scheduled or any(k in t for k in OUTAGE_KEYWORDS)
    if not is_outage:
        return None
    return "SCHEDULED" if is_scheduled else "UNSCHEDULED"


def _parse_audience(text: str) -> int | None:
    """Best-effort extraction of customers/properties affected."""
    m = re.search(r"([\d,\.]+)\s*(customers|properties|households|premises|people)", text, re.I)
    if not m:
        return None
    digits = re.sub(r"[^\d]", "", m.group(1))
    return int(digits) if digits else None


async def scrape_outages(sources: list[PowerOutageSource], db) -> dict:
    """Scrape enabled outage sources, classify, dedupe and persist."""
    new_count = 0
    errors: list[str] = []
    for src in sources:
        if not src.enabled:
            continue
        try:
            raw_items = await fetch_source(src)  # SSRF-validated fetch + RSS/HTML parse
        except Exception as e:  # noqa: BLE001 - collect per-source errors
            errors.append(f"{src.name}: {e}")
            continue
        for it in raw_items:
            text = f"{it['title']} {it.get('summary') or ''}"
            outage_type = classify_outage(text)
            if outage_type is None:
                continue  # not about a power outage
            exists = (
                await db.execute(
                    select(PowerOutage).where(
                        PowerOutage.source_id == src.id,
                        PowerOutage.title == it["title"],
                    )
                )
            ).scalar_one_or_none()
            if exists:
                continue
            db.add(PowerOutage(
                source_id=src.id,
                country=src.country,
                region=src.region,
                city=src.city,
                outage_type=outage_type,
                title=it["title"][:1000],
                details=(it.get("summary") or "")[:4000] or None,
                url=it.get("url"),
                customers_affected=_parse_audience(text),
            ))
            new_count += 1
        src.last_fetched = datetime.now(timezone.utc).replace(tzinfo=None)
    await db.commit()
    return {"sources": len([s for s in sources if s.enabled]), "new_outages": new_count, "errors": errors}
