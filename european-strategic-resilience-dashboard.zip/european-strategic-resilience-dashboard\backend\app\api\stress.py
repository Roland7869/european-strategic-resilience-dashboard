"""Stress Test: 7-day game-theory scenario runs + self-calibrating weekly post-mortem."""
import json
from datetime import date, datetime

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.preps import get_setting, set_setting
from app.database import get_db
from app.models import (
    CalibrationAudit, CalibrationRule, ScrapedItem, StressSnapshot
)
from app.schemas import (
    AuditScorecard, LearnedRule, PostMortemOut, RulePinnedIn, StressRunIn,
    StressSnapshotOut, StressState
)
from app.services import ai_service

router = APIRouter(prefix="/stress", tags=["stress"])

DEFAULT_VERSION = "v1.0"
MAX_RULES = 10
THEATERS = [
    "Global Multi-Theatre",
    "Middle East / Strait of Hormuz",
    "Ukraine & Eastern Flank",
    "European Grid & Cyber",
]


def _parse(raw: str) -> dict:
    return ai_service.parse_json_object(raw) or {}


def _snapshot_out(s: StressSnapshot) -> StressSnapshotOut:
    def loads(t, default):
        try:
            return json.loads(t) if t else default
        except json.JSONDecodeError:
            return default
    return StressSnapshotOut(
        id=s.id, created_at=s.created_at, theater=s.theater,
        prompt_version=s.prompt_version,
        input_state=loads(s.input_state, {}),
        actor_matrix=loads(s.actor_matrix, []),
        pre_mortem=loads(s.pre_mortem, []),
        tripwires=loads(s.tripwires, []),
    )


def _rule_out(r: CalibrationRule) -> LearnedRule:
    return LearnedRule(
        id=r.id, rule_text=r.rule_text, added_date=r.added_date,
        source_audit_summary=r.source_audit_summary, pinned=r.pinned,
    )


def _audit_out(a: CalibrationAudit) -> AuditScorecard:
    return AuditScorecard(
        id=a.id, prompt_version=a.prompt_version, hits=a.hits,
        false_alarms=a.false_alarms, blind_spots=a.blind_spots,
        timing_errors=a.timing_errors, summary=a.summary, created_at=a.created_at,
    )


async def _get_version(db: AsyncSession) -> str:
    v = await get_setting(db, "stress_prompt_version", DEFAULT_VERSION)
    return v or DEFAULT_VERSION


def _bump_version(v: str) -> str:
    """v1.0 -> v1.1 ... v1.9 -> v2.0"""
    try:
        major, minor = v.lstrip("v").split(".")
        major_i, minor_i = int(major), int(minor)
        minor_i += 1
        if minor_i > 9:
            major_i += 1
            minor_i = 0
        return f"v{major_i}.{minor_i}"
    except Exception:  # noqa: BLE001
        return DEFAULT_VERSION


async def _stress_context(db: AsyncSession, theater: str) -> str:
    """Dashboard state + top OSINT + active preps + learned heuristics."""
    from app.services.scoring import compute_summary
    from app.api.preps import _sorted, compute_readiness

    summary = await compute_summary(db)
    parts = [f"THEATER: {theater}", ""]
    parts.append("=== DASHBOARD STATE ===")
    parts.append(
        f"Status: {summary.get('overall_status')} | Threat: {summary.get('threat_score')}/10 "
        f"({summary.get('threat_trend')}) | Resilience: {summary.get('resilience_score')}/10 "
        f"({summary.get('resilience_trend')}) | SFI: {summary.get('strategic_friction_index')}/10 "
        f"({', '.join(f'{k.replace('_',' ')} {v}' for k, v in (summary.get('friction_signals') or {}).items())})"
    )

    osint = (await db.execute(
        select(ScrapedItem).order_by(ScrapedItem.fetched_at.desc()).limit(12)
    )).scalars().all()
    if osint:
        parts.append("\n=== TOP OSINT (recent) ===")
        for i in osint:
            parts.append(f"- {i.title}")

    preps = await _sorted(db)
    r = await compute_readiness(db)
    parts.append("\n=== ACTIVE PREPS (preparedness status) ===")
    parts.append(
        f"Household {r.household_size} person(s), readiness {r.household_readiness}/10 "
        f"(economic {r.economic}, infrastructure {r.infrastructure}, threat {r.threat_environment})"
    )
    for p in preps:
        flag = " [BELOW MIN]" if p.quantity < p.min_quantity else ""
        parts.append(f"- {p.name} [{p.category}] have {p.quantity} {p.unit} (min {p.min_quantity}) {p.priority}{flag}")

    rules = list((await db.execute(select(CalibrationRule))).scalars().all())
    parts.append("\n=== LEARNED HEURISTICS (take these into account) ===")
    if rules:
        for rr in rules:
            pin = " [PINNED]" if rr.pinned else ""
            parts.append(f"- {rr.rule_text}{pin}")
    else:
        parts.append("- (none yet)")
    return "\n".join(parts)


@router.post("/run")
async def run_stress_test(payload: StressRunIn, db: AsyncSession = Depends(get_db)):
    """Generate and persist a 7-day game-theory stress-test snapshot."""
    theater = payload.theater or THEATERS[0]
    context = await _stress_context(db, theater)
    version = await _get_version(db)
    messages = [
        {"role": "system", "content": ai_service.STRESS_SYSTEM_PROMPT},
        {"role": "user", "content": context},
    ]
    try:
        raw = await ai_service.call_llm(messages, temperature=0.3)
    except Exception as e:  # noqa: BLE001
        raise HTTPException(status_code=502, detail=f"LM Studio error: {e}")
    data = _parse(raw)

    # inputState snapshot
    from app.services.scoring import compute_summary, flashpoints
    summary = await compute_summary(db)
    flash = await flashpoints(db, limit=5)
    input_state = {
        "threat": summary.get("threat_score"),
        "resilience": summary.get("resilience_score"),
        "sfi": summary.get("strategic_friction_index"),
        "status": summary.get("overall_status"),
        "topOsint": [i.title for i in (await db.execute(
            select(ScrapedItem).order_by(ScrapedItem.fetched_at.desc()).limit(5)
        )).scalars().all()],
        "flashpoints": [f["region"] for f in flash],
    }

    snap = StressSnapshot(
        theater=theater,
        prompt_version=version,
        input_state=json.dumps(input_state),
        actor_matrix=json.dumps(data.get("actorMatrix", [])),
        pre_mortem=json.dumps(data.get("preMortemScenarios", [])),
        tripwires=json.dumps(data.get("tripwires", [])),
    )
    db.add(snap)
    await db.commit()
    await db.refresh(snap)
    return _snapshot_out(snap)


@router.post("/postmortem", response_model=PostMortemOut)
async def run_postmortem(db: AsyncSession = Depends(get_db)):
    """Grade the previous snapshot against current reality, learn rules, bump version."""
    latest = (await db.execute(
        select(StressSnapshot).order_by(StressSnapshot.created_at.desc()).limit(1)
    )).scalar_one_or_none()
    if not latest:
        raise HTTPException(status_code=400, detail="No previous stress-test snapshot to grade")

    prev = _snapshot_out(latest)

    # Current reality: summary + recent entries + recent OSINT
    from app.services.scoring import compute_summary
    summary = await compute_summary(db)
    from app.models import Event, EventCategory
    from sqlalchemy.orm import selectinload
    events = (await db.execute(
        select(Event).options(
            selectinload(Event.category_links).selectinload(EventCategory.category)
        ).order_by(Event.event_date.desc()).limit(15)
    )).scalars().unique().all()
    osint = (await db.execute(
        select(ScrapedItem).order_by(ScrapedItem.fetched_at.desc()).limit(15)
    )).scalars().all()

    parts = [
        f"PREVIOUS SNAPSHOT (theater: {prev.theater}, run {prev.created_at.date()}):",
        "ACTOR CLAIMS:",
    ]
    for a in prev.actor_matrix:
        parts.append(f"- {a.actor}: goal {a.primaryGoal7d} | next move {a.rationalNextMove} | risk {a.miscalculationRisk}")
    parts.append("TRIPWIRES FLAGGED:")
    for t in prev.tripwires:
        parts.append(f"- {t.indicator}: ESC if {t.escalationSignal}; DE-ESC if {t.deescalationSignal}")

    parts.append("\nCURRENT STATE (what actually happened since):")
    parts.append(
        f"Status {summary.get('overall_status')} | Threat {summary.get('threat_score')}/10 "
        f"({summary.get('threat_trend')}) | Resilience {summary.get('resilience_score')}/10 "
        f"({summary.get('resilience_trend')}) | SFI {summary.get('strategic_friction_index')}/10"
    )
    parts.append("\nRECENT ENTRIES:")
    for e in events:
        cl = ", ".join(l.category.name for l in e.category_links)
        parts.append(f"- [{e.event_date}] {e.title} ({e.status}) — {cl}")
    parts.append("\nRECENT OSINT:")
    for i in osint:
        parts.append(f"- {i.title}")

    messages = [
        {"role": "system", "content": ai_service.POSTMORTEM_SYSTEM_PROMPT},
        {"role": "user", "content": "\n".join(parts)},
    ]
    try:
        raw = await ai_service.call_llm(messages, temperature=0.2)
    except Exception as e:  # noqa: BLE001
        raise HTTPException(status_code=502, detail=f"LM Studio error: {e}")
    data = _parse(raw)

    # Merge new rules (respect pinned, cap total, prune oldest unpinned)
    existing = list((await db.execute(
        select(CalibrationRule).order_by(CalibrationRule.added_date.asc())
    )).scalars().all())
    new_rules: list[CalibrationRule] = []
    for nr in (data.get("newRules") or [])[:3]:
        if not isinstance(nr, dict) or not nr.get("ruleText"):
            continue
        rule = CalibrationRule(
            rule_text=str(nr["ruleText"])[:500],
            added_date=date.today(),
            source_audit_summary=(nr.get("sourceAuditSummary") or "")[:500] or None,
            pinned=False,
        )
        db.add(rule)
        new_rules.append(rule)
    await db.flush()

    # Enforce cap: prune oldest unpinned until <= MAX_RULES
    all_rules = list((await db.execute(
        select(CalibrationRule).order_by(CalibrationRule.pinned.desc(), CalibrationRule.added_date.asc())
    )).scalars().all())
    if len(all_rules) > MAX_RULES:
        unpinned = [r for r in all_rules if not r.pinned]
        excess = len(all_rules) - MAX_RULES
        for r in unpinned[:excess]:
            await db.delete(r)

    # Bump version + save audit
    old_version = await _get_version(db)
    new_version = _bump_version(old_version)
    await set_setting(db, "stress_prompt_version", new_version)

    audit = CalibrationAudit(
        prompt_version=new_version,
        hits=int(data.get("hits", 0) or 0),
        false_alarms=int(data.get("falseAlarms", 0) or 0),
        blind_spots=int(data.get("blindSpots", 0) or 0),
        timing_errors=int(data.get("timingErrors", 0) or 0),
        summary=(data.get("summary") or "")[:2000] or None,
    )
    db.add(audit)
    await db.commit()
    await db.refresh(audit)

    final_rules = list((await db.execute(
        select(CalibrationRule).order_by(CalibrationRule.pinned.desc(), CalibrationRule.added_date.desc())
    )).scalars().all())
    return PostMortemOut(
        scorecard=_audit_out(audit),
        new_rules=[_rule_out(r) for r in final_rules],
        prompt_version=new_version,
    )


@router.get("/state", response_model=StressState)
async def stress_state(db: AsyncSession = Depends(get_db)):
    latest = (await db.execute(
        select(StressSnapshot).order_by(StressSnapshot.created_at.desc()).limit(1)
    )).scalar_one_or_none()
    rules = list((await db.execute(
        select(CalibrationRule).order_by(CalibrationRule.pinned.desc(), CalibrationRule.added_date.desc())
    )).scalars().all())
    audits = list((await db.execute(
        select(CalibrationAudit).order_by(CalibrationAudit.created_at.desc()).limit(10)
    )).scalars().all())
    version = await _get_version(db)
    return StressState(
        snapshot=_snapshot_out(latest) if latest else None,
        rules=[_rule_out(r) for r in rules],
        audits=[_audit_out(a) for a in audits],
        prompt_version=version,
    )


@router.post("/rules/{rule_id}/pin", response_model=LearnedRule)
async def pin_rule(rule_id: int, payload: RulePinnedIn, db: AsyncSession = Depends(get_db)):
    rule = await db.get(CalibrationRule, rule_id)
    if not rule:
        raise HTTPException(status_code=404, detail="Rule not found")
    rule.pinned = payload.pinned
    await db.commit()
    await db.refresh(rule)
    return _rule_out(rule)


@router.delete("/rules/{rule_id}", status_code=204)
async def delete_rule(rule_id: int, db: AsyncSession = Depends(get_db)):
    rule = await db.get(CalibrationRule, rule_id)
    if not rule:
        raise HTTPException(status_code=404, detail="Rule not found")
    await db.delete(rule)
    await db.commit()
