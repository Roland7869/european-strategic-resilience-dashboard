"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { api } from "@/lib/api";
import { useRefresh } from "@/lib/RefreshContext";
import type { DashboardData, EventItem } from "@/lib/types";
import { StatusBanner } from "@/components/dashboard/StatusBanner";
import { CategoryCard } from "@/components/dashboard/CategoryCard";
import { Heatmap } from "@/components/charts/Heatmap";
import { TimelineChart } from "@/components/charts/Timeline";
import { RadarChartView } from "@/components/charts/Radar";
import { Histogram } from "@/components/charts/Histogram";
import { ConfidenceDistributionChart } from "@/components/charts/ConfidenceDistribution";
import { StatusBadge } from "@/components/ui/Badges";

export default function DashboardPage() {
  const { refreshKey } = useRefresh();
  const [data, setData] = useState<DashboardData | null>(null);
  const [recent, setRecent] = useState<EventItem[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const [dash, events] = await Promise.all([
          api.getDashboard(),
          api.getEvents({ limit: 8 }),
        ]);
        if (!cancelled) {
          setData(dash);
          setRecent(events);
        }
      } catch (e) {
        if (!cancelled) setError(String(e));
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [refreshKey]);

  if (loading) return <Loading />;
  if (error) return <ErrorPanel msg={error} />;
  if (!data) return null;

  return (
    <div className="space-y-4">
      <StatusBanner summary={data.summary} />

      {/* Executive Summary strip */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-4">
        <Panel title="Threat Trend" accent={data.summary.threat_trend === "UP" ? "#ef4444" : data.summary.threat_trend === "DOWN" ? "#22c55e" : "#eab308"}>
          <div className="font-mono text-4xl font-black">{data.summary.threat_trend}</div>
          <p className="mt-2 text-[11px] leading-relaxed text-slate-400">
            Aggregate direction of threat-side categories over the assessment window.
          </p>
        </Panel>
        <Panel title="Resilience Trend" accent={data.summary.resilience_trend === "UP" ? "#22c55e" : data.summary.resilience_trend === "DOWN" ? "#ef4444" : "#eab308"}>
          <div className="font-mono text-4xl font-black">{data.summary.resilience_trend}</div>
          <p className="mt-2 text-[11px] leading-relaxed text-slate-400">
            Aggregate direction of resilience-side adaptation indicators.
          </p>
        </Panel>
        <Panel title="Strategic Surprise Index" accent="#38bdf8">
          <div className="font-mono text-4xl font-black">
            {data.summary.strategic_surprise_index.toFixed(0)}
            <span className="text-sm text-slate-500">/100</span>
          </div>
          <div className="mt-2 h-1.5 w-full rounded-full bg-[#1a2334]">
            <div className="h-full rounded-full bg-sky-400" style={{ width: `${data.summary.strategic_surprise_index}%` }} />
          </div>
        </Panel>
        <Panel title="Event Density Index" accent="#f97316">
          <div className="font-mono text-4xl font-black">
            {data.summary.event_density_index.toFixed(0)}
            <span className="text-sm text-slate-500">/100</span>
          </div>
          <div className="mt-2 h-1.5 w-full rounded-full bg-[#1a2334]">
            <div className="h-full rounded-full bg-orange-400" style={{ width: `${data.summary.event_density_index}%` }} />
          </div>
        </Panel>
      </div>

      {/* Strategic Friction Index */}
      <div className="panel">
        <div className="panel-header">
          <span className="text-[12px] font-bold uppercase tracking-wider">Strategic Friction Index</span>
          <span className="text-[10px] text-slate-500">Simultaneous crises · polarization · economic friction · info warfare · infrastructure stress</span>
        </div>
        <div className="flex flex-wrap items-center gap-6 p-4">
          <div className="text-center">
            <div className="font-mono text-4xl font-black text-orange-400">
              {data.summary.strategic_friction_index.toFixed(1)}
              <span className="text-sm text-slate-500">/10</span>
            </div>
            <div className="label mt-1">Index</div>
          </div>
          <div className="grid flex-1 grid-cols-1 gap-2 sm:grid-cols-5">
            {Object.entries(data.summary.friction_signals || {}).map(([sig, val]) => (
              <div key={sig} className="rounded border border-[#1f2a3d] bg-[#0d1420] px-2 py-1.5">
                <div className="truncate text-[10px] capitalize text-slate-400" title={sig.replace(/_/g, " ")}>
                  {sig.replace(/_/g, " ")}
                </div>
                <div className="font-mono text-lg font-bold text-slate-200">{Number(val).toFixed(1)}</div>
                <div className="mt-1 h-1 w-full rounded-full bg-[#1a2334]">
                  <div
                    className="h-full rounded-full"
                    style={{
                      width: `${(Number(val) / 10) * 100}%`,
                      background: Number(val) >= 8 ? "#ef4444" : Number(val) >= 6 ? "#f97316" : "#eab308",
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Flashpoints */}
      {data.flashpoints?.length > 0 && (
        <Panel title="Flashpoints — Hottest Regions" accent="#ef4444" subtitle="Activity × threat intensity">
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 xl:grid-cols-3">
            {data.flashpoints.map((f) => (
              <div key={f.region} className="rounded border border-[#1f2a3d] bg-[#0d1420] p-3">
                <div className="flex items-center justify-between">
                  <span className="text-[13px] font-bold text-slate-100">{f.region}</span>
                  <span className="font-mono text-[11px] text-orange-400">{f.intensity}</span>
                </div>
                <div className="mt-0.5 text-[10px] text-slate-500">{f.event_count} events (120d)</div>
                <div className="mt-2 flex flex-wrap gap-1">
                  {f.top_categories.map((c) => (
                    <span key={c.name} className="rounded bg-[#1a2334] px-1.5 py-0.5 text-[10px] text-slate-300">
                      {c.name} <span className="text-red-400">{c.score}</span>
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </Panel>
      )}

      {/* Categories: threat + resilience simultaneously */}
      <div className="grid grid-cols-1 gap-4 xl:grid-cols-2">
        <Panel title="Threat Environment" accent="#ef4444" subtitle={`${data.threat_categories.length} categories tracked`}>
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
            {data.threat_categories.map((c) => (
              <CategoryCard key={c.id} cat={c} />
            ))}
          </div>
        </Panel>
        <Panel title="Resilience Environment" accent="#22c55e" subtitle={`${data.resilience_categories.length} indicators tracked`}>
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
            {data.resilience_categories.map((c) => (
              <CategoryCard key={c.id} cat={c} />
            ))}
          </div>
        </Panel>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 gap-4 xl:grid-cols-3">
        <Panel title="Event Density Heatmap" accent="#f97316" wide>
          <Heatmap data={data.heatmap} />
        </Panel>
        <Panel title="Category Radar (Threat vs Resilience)" accent="#38bdf8">
          <RadarChartView data={data.radar} />
        </Panel>
      </div>

      <div className="grid grid-cols-1 gap-4 xl:grid-cols-3">
        <Panel title="Event Timeline (12 weeks)" accent="#f97316">
          <TimelineChart data={data.timeline} />
        </Panel>
        <Panel title="Threat Histogram (score distribution)" accent="#ef4444">
          <Histogram data={data.histogram} />
        </Panel>
        <Panel title="Confidence Distribution" accent="#eab308">
          <ConfidenceDistributionChart data={data.confidence_distribution} />
        </Panel>
      </div>

      {/* Recent feed */}
      <Panel title="Latest Entries" accent="#38bdf8" subtitle="Newest first">
        <div className="divide-y divide-[#1a2334]">
          {recent.map((e) => (
            <Link
              key={e.id}
              href="/entries"
              className="block px-1 py-2 transition hover:bg-[#141d2e]"
            >
              <div className="flex flex-wrap items-center gap-2">
                <span className="font-mono text-[11px] text-sky-400">#{e.entry_number}</span>
                <span className="font-mono text-[11px] text-slate-500">{e.event_date}</span>
                <StatusBadge status={e.status} />
                <span className="text-[13px] font-semibold text-slate-200">{e.title}</span>
              </div>
              <div className="mt-0.5 line-clamp-1 text-[11px] text-slate-500">{e.summary}</div>
            </Link>
          ))}
        </div>
      </Panel>
    </div>
  );
}

function Panel({
  title,
  subtitle,
  accent = "#2a3a55",
  children,
  wide,
}: {
  title: string;
  subtitle?: string;
  accent?: string;
  children: React.ReactNode;
  wide?: boolean;
}) {
  return (
    <div className={`panel ${wide ? "xl:col-span-2" : ""}`}>
      <div className="panel-header">
        <div className="flex items-center gap-2">
          <span className="h-2.5 w-2.5 rounded-sm" style={{ background: accent }} />
          <span className="text-[12px] font-bold uppercase tracking-wider text-slate-200">{title}</span>
        </div>
        {subtitle && <span className="text-[10px] text-slate-500">{subtitle}</span>}
      </div>
      <div className="p-3">{children}</div>
    </div>
  );
}

function Loading() {
  return (
    <div className="flex h-[60vh] items-center justify-center">
      <div className="text-center">
        <div className="mx-auto mb-3 h-8 w-8 animate-spin rounded-full border-2 border-sky-400 border-t-transparent" />
        <div className="label">Loading strategic picture…</div>
      </div>
    </div>
  );
}

function ErrorPanel({ msg }: { msg: string }) {
  return (
    <div className="panel border-red-500/40 p-6">
      <div className="label text-red-400">Backend unreachable</div>
      <p className="mt-2 text-sm text-slate-300">{msg}</p>
      <p className="mt-2 text-xs text-slate-500">
        Start the stack with <code className="rounded bg-[#1a2334] px-1">docker compose up</code> or run the
        backend with <code className="rounded bg-[#1a2334] px-1">uvicorn app.main:app --reload</code>.
      </p>
    </div>
  );
}
