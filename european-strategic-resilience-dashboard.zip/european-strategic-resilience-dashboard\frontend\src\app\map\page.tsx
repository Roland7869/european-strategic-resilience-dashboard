"use client";

import { useEffect, useState } from "react";
import dynamic from "next/dynamic";
import "leaflet/dist/leaflet.css";
import { api } from "@/lib/api";
import { useRefresh } from "@/lib/RefreshContext";
import type { EventItem, Region } from "@/lib/types";
import { StatusBadge } from "@/components/ui/Badges";

const RegionMap = dynamic(() => import("@/components/map/RegionMap"), {
  ssr: false,
  loading: () => (
    <div className="flex h-[520px] items-center justify-center text-sm text-slate-500">
      Loading map…
    </div>
  ),
});

export default function MapPage() {
  const { refreshKey } = useRefresh();
  const [regions, setRegions] = useState<Region[]>([]);
  const [selected, setSelected] = useState<Region | null>(null);
  const [events, setEvents] = useState<EventItem[]>([]);
  const [loadingEvents, setLoadingEvents] = useState(false);
  const [counts, setCounts] = useState<Record<number, number>>({});

  useEffect(() => {
    (async () => {
      try {
        const regs = await api.getRegions();
        setRegions(regs);
        // Fetch counts per region (limit high to aggregate)
        const all = await api.getEvents({ limit: 500 });
        const c: Record<number, number> = {};
        all.forEach((e) => {
          e.region_links.forEach((rl) => {
            c[rl.region_id] = (c[rl.region_id] || 0) + 1;
          });
        });
        setCounts(c);
        // refresh the currently selected region's entries too
        if (selected) {
          setEvents(await api.getEvents({ region_id: selected.id, limit: 100 }));
        }
      } catch {
        /* ignore */
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [refreshKey]);

  const selectRegion = async (r: Region) => {
    setSelected(r);
    setLoadingEvents(true);
    try {
      setEvents(await api.getEvents({ region_id: r.id, limit: 100 }));
    } finally {
      setLoadingEvents(false);
    }
  };

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-lg font-bold tracking-wide">Regional Activity Map</h1>
        <p className="text-xs text-slate-500">
          Click a region to view all associated entries. Activity intensity reflects event density.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-4 xl:grid-cols-3">
        <div className="panel xl:col-span-2">
          <div className="panel-header">
            <span className="text-[12px] font-bold uppercase tracking-wider">Geographic Layer</span>
            <span className="text-[10px] text-slate-500">{regions.length} regions</span>
          </div>
          <div className="h-[520px]">
            <RegionMap regions={regions} counts={counts} onSelect={selectRegion} />
          </div>
        </div>

        <div className="panel">
          <div className="panel-header">
            <span className="text-[12px] font-bold uppercase tracking-wider">
              {selected ? selected.name : "Region Detail"}
            </span>
            {selected && (
              <span className="text-[10px] text-slate-500">{events.length} entries</span>
            )}
          </div>
          {!selected ? (
            <div className="p-6 text-center text-sm text-slate-500">
              Select a region on the map to inspect its entries.
            </div>
          ) : loadingEvents ? (
            <div className="p-6 text-center text-sm text-slate-500">Loading entries…</div>
          ) : events.length === 0 ? (
            <div className="p-6 text-center text-sm text-slate-500">No entries for this region.</div>
          ) : (
            <div className="max-h-[480px] divide-y divide-[#1a2334] overflow-y-auto">
              {events.map((e) => (
                <div key={e.id} className="px-3 py-2">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-mono text-[11px] text-sky-400">#{e.entry_number}</span>
                    <span className="font-mono text-[10px] text-slate-500">{e.event_date}</span>
                    <StatusBadge status={e.status} />
                  </div>
                  <div className="mt-0.5 text-[12px] font-semibold text-slate-200">{e.title}</div>
                  <div className="mt-0.5 line-clamp-2 text-[11px] text-slate-500">{e.summary}</div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
