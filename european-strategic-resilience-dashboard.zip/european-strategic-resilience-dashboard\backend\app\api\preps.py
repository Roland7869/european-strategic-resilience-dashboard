"""Preparedness inventory ('preps') + Run-to-Store AI top-up suggestions."""
import json

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.models import AppSetting, Category, Prep, Side
from app.schemas import (
    HouseholdReadiness, HouseholdSizeIn, PrepChatIn, PrepChatOut, PrepCreate,
    PrepOut, PrepUpdate, RunToStoreRequest, RunToStoreResult
)
from app.services import ai_service
from app.services.scoring import compute_summary

router = APIRouter(prefix="/preps", tags=["preps"])

DEFAULT_THRESHOLD = 7.0
DEFAULT_HOUSEHOLD_SIZE = 2

# Consumables scale with the number of people in the household.
CONSUMABLE_CATEGORIES = {"Water", "Food", "Fuel"}
# Prep category -> readiness dimension(s).
CATEGORY_DIMENSIONS = {
    "Water": ["infrastructure", "threat"],
    "Food": ["economic", "threat"],
    "Power": ["infrastructure"],
    "Medical": ["threat"],
    "Fuel": ["economic", "infrastructure"],
    "Shelter": ["threat", "infrastructure"],
    "Comms": ["infrastructure"],
    "Other": ["economic"],  # e.g. cash
}
PRIORITY_WEIGHT = {"HIGH": 1.0, "MEDIUM": 0.7, "LOW": 0.4}


async def get_setting(db: AsyncSession, key: str, default: str | None = None) -> str | None:
    row = await db.get(AppSetting, key)
    return row.value if row else default


async def set_setting(db: AsyncSession, key: str, value: str) -> None:
    row = await db.get(AppSetting, key)
    if row:
        row.value = value
    else:
        db.add(AppSetting(key=key, value=value))


async def _sorted(db: AsyncSession) -> list[Prep]:
    result = await db.execute(select(Prep).order_by(Prep.stage, Prep.priority, Prep.name))
    return list(result.scalars().all())


@router.get("", response_model=list[PrepOut])
async def list_preps(db: AsyncSession = Depends(get_db)):
    return await _sorted(db)


@router.post("", response_model=PrepOut, status_code=201)
async def create_prep(payload: PrepCreate, db: AsyncSession = Depends(get_db)):
    prep = Prep(**payload.model_dump())
    db.add(prep)
    await db.commit()
    await db.refresh(prep)
    return prep


@router.put("/{prep_id}", response_model=PrepOut)
async def update_prep(prep_id: int, payload: PrepUpdate, db: AsyncSession = Depends(get_db)):
    prep = await db.get(Prep, prep_id)
    if not prep:
        raise HTTPException(status_code=404, detail="Prep not found")
    for k, v in payload.model_dump(exclude_none=True).items():
        setattr(prep, k, v)
    await db.commit()
    await db.refresh(prep)
    return prep


@router.delete("/{prep_id}", status_code=204)
async def delete_prep(prep_id: int, db: AsyncSession = Depends(get_db)):
    prep = await db.get(Prep, prep_id)
    if not prep:
        raise HTTPException(status_code=404, detail="Prep not found")
    await db.delete(prep)
    await db.commit()


def _prep_readiness(prep: Prep, household_size: int) -> float:
    """Coverage ratio 0..1 for one prep, scaled by household size for consumables."""
    min_q = prep.min_quantity
    if prep.category in CONSUMABLE_CATEGORIES:
        min_q = min_q * max(household_size, 1)
    if min_q <= 0:
        return 1.0 if prep.quantity > 0 else 0.5
    return min(prep.quantity / min_q, 1.0)


async def compute_readiness(db: AsyncSession) -> HouseholdReadiness:
    """Household readiness (0-10) split into Economic / Infrastructure / Threat environment."""
    preps = await _sorted(db)
    hs_raw = await get_setting(db, "household_size", str(DEFAULT_HOUSEHOLD_SIZE))
    try:
        hs = max(1, int(float(hs_raw or DEFAULT_HOUSEHOLD_SIZE)))
    except ValueError:
        hs = DEFAULT_HOUSEHOLD_SIZE

    dims: dict[str, list[tuple[float, float]]] = {"economic": [], "infrastructure": [], "threat": []}
    for p in preps:
        r = _prep_readiness(p, hs)
        w = PRIORITY_WEIGHT.get(p.priority, 0.7)
        for d in CATEGORY_DIMENSIONS.get(p.category, ["economic"]):
            dims[d].append((r, w))

    def _score(pairs: list[tuple[float, float]]) -> float | None:
        if not pairs:
            return None
        tw = sum(w for _, w in pairs)
        if tw == 0:
            return None
        return round(sum(r * w for r, w in pairs) / tw * 10, 1)

    economic = _score(dims["economic"])
    infra = _score(dims["infrastructure"])
    threat = _score(dims["threat"])
    vals = [v for v in (economic, infra, threat) if v is not None]
    overall = round(sum(vals) / len(vals), 1) if vals else None
    return HouseholdReadiness(
        household_size=hs, economic=economic, infrastructure=infra,
        threat_environment=threat, household_readiness=overall,
    )


@router.get("/readiness", response_model=HouseholdReadiness)
async def get_readiness(db: AsyncSession = Depends(get_db)):
    return await compute_readiness(db)


@router.post("/household-size", response_model=HouseholdReadiness)
async def set_household_size(payload: HouseholdSizeIn, db: AsyncSession = Depends(get_db)):
    size = max(1, min(20, int(payload.size)))
    await set_setting(db, "household_size", str(size))
    await db.commit()
    return await compute_readiness(db)


# --- Survivalist advisor chat -------------------------------------------------
PREPPER_PERSONA = """You are a SEASONED PREPPER AND SURVIVALIST with decades of hands-on
experience and extensive knowledge of rebuilding after catastrophe. You have managed
household resilience through prolonged grid-down, supply-chain and societal disruptions,
and you coach others to do the same.

Your core doctrine:
- MASTER THE FUNDAMENTALS FIRST: WATER, FOOD, ENERGY. Gadgets come last.
- Work in three stages:
  Stage 1 Immediate Readiness (0-14 days): stockpile to survive short disruptions alone.
  Stage 2 Resilience (14-180 days): function through prolonged shortages.
  Stage 3 Self-Reliance / Rebuilding (180+ days): produce and reduce dependency.
- Rule of thumb: first 14 days = stockpile; 14-180 days = resilience; 180+ days = production.
- A lone household struggles in a long crisis; a capable neighbourhood thrives. Community is
  the most overlooked prep.
- Prefer practical, prioritised, actionable advice over theory. Give concrete quantities,
  brands/types and next actions. Be concise and direct.

You will be given the household's CURRENT INVENTORY (by stage) and READINESS scores.
Reference them: congratulate progress, flag shortfalls, and recommend the single most
valuable next purchase given their gaps and the stage they are on. If asked something
outside preparedness/survival/rebuilding, still answer helpfully but keep the survivalist
lens. Never invent that they own something they do not — use the inventory provided."""


def _inventory_context(preps: list[Prep], readiness: HouseholdReadiness) -> str:
    by_stage: dict[int, list[Prep]] = {}
    for p in preps:
        by_stage.setdefault(p.stage, []).append(p)
    lines = [
        f"Household size: {readiness.household_size} person(s).",
        f"Readiness — overall {readiness.household_readiness}/10 "
        f"(economic {readiness.economic}, infrastructure {readiness.infrastructure}, "
        f"threat {readiness.threat_environment}).",
        "",
    ]
    goals = {1: "Immediate (0-14d)", 2: "Resilience (14-180d)", 3: "Self-Reliance (180d+)"}
    for stage in (1, 2, 3):
        items = by_stage.get(stage, [])
        lines.append(f"STAGE {stage} — {goals[stage]}:")
        for p in items:
            flag = " [BELOW MIN]" if p.quantity < p.min_quantity else ""
            lines.append(f"  - {p.name} [{p.category}] have {p.quantity} {p.unit} "
                         f"(min {p.min_quantity}) {p.priority}{flag}")
        lines.append("")
    return "\n".join(lines)


@router.post("/chat", response_model=PrepChatOut)
async def preps_chat(payload: PrepChatIn, db: AsyncSession = Depends(get_db)):
    """Chat with the survivalist advisor. Injects the household inventory + readiness
    as context so advice is tailored to what the owner actually has."""
    from app.services import ai_service

    preps = await _sorted(db)
    readiness = await compute_readiness(db)
    context = _inventory_context(preps, readiness)

    system = PREPPER_PERSONA + "\n\nCURRENT HOUSEHOLD STATUS:\n" + context
    messages = [{"role": "system", "content": system}]
    for m in payload.messages[-12:]:  # cap history
        if m.role in ("user", "assistant"):
            messages.append({"role": m.role, "content": m.content})
    if not any(m["role"] == "user" for m in messages):
        raise HTTPException(status_code=400, detail="At least one user message is required")

    try:
        reply = await ai_service.call_llm(messages, temperature=0.5)
    except Exception as e:  # noqa: BLE001
        raise HTTPException(status_code=502, detail=f"LM Studio error: {e}")
    return PrepChatOut(reply=reply)


@router.post("/run-to-store", response_model=RunToStoreResult)
async def run_to_store(payload: RunToStoreRequest, db: AsyncSession = Depends(get_db)):
    """When the alert level reaches the owner's threshold, ask the AI to review the
    preparedness inventory and suggest what to top up."""
    summary = await compute_summary(db)
    current_level = summary.get("threat_score", 0.0)
    status = summary.get("overall_status", "GREEN")
    thr_raw = await get_setting(db, "run_to_store_threshold", str(DEFAULT_THRESHOLD))
    try:
        threshold = float(thr_raw or DEFAULT_THRESHOLD)
    except ValueError:
        threshold = DEFAULT_THRESHOLD

    reached = current_level >= threshold
    preps = await _sorted(db)
    low_items = [p for p in preps if p.quantity < p.min_quantity]

    if not reached and not payload.force:
        return RunToStoreResult(
            reached=False, threshold=threshold, current_level=current_level,
            status=status, suggestions="", low_items=[PrepOut.model_validate(p) for p in low_items],
        )

    # Build preps context for the AI
    lines = []
    for p in preps:
        flag = " ⚠️BELOW MIN" if p.quantity < p.min_quantity else ""
        lines.append(
            f"- {p.name} [{p.category}] qty={p.quantity} {p.unit} (min {p.min_quantity}) "
            f"priority={p.priority}{flag}"
        )
    cats = list((await db.execute(select(Category).where(Category.side == Side.threat.value))).scalars())
    top_threats = sorted(cats, key=lambda c: c.current_score, reverse=True)[:5]
    threat_ctx = ", ".join(f"{c.name} {c.current_score}/10" for c in top_threats)

    instruction = (
        "The owner has a preparedness inventory ('preps'). The current alert level has "
        f"reached their Run-to-Store threshold ({current_level}/10, status {status}). "
        "Top threat pressures: " + threat_ctx + ".\n\n"
        "Review the inventory below. For each item BELOW its minimum, and for any item that "
        "should be topped up given the top threat pressures, recommend a concrete top-up "
        "(what to buy/stock and roughly how much). Group by category. Be practical and concise. "
        "Flag the single most urgent item first.\n\nINVENTORY:\n" + "\n".join(lines)
    )
    try:
        suggestions = await ai_service.call_llm(
            [
                {"role": "system", "content": ai_service.SYSTEM_PROMPT},
                {"role": "user", "content": instruction},
            ],
            temperature=0.3,
        )
    except Exception as e:  # noqa: BLE001
        raise HTTPException(status_code=502, detail=f"LM Studio error: {e}")

    return RunToStoreResult(
        reached=reached, threshold=threshold, current_level=current_level,
        status=status, suggestions=suggestions,
        low_items=[PrepOut.model_validate(p) for p in low_items],
    )
