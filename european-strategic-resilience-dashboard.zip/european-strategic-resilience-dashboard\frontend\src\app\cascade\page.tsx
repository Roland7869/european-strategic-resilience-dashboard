"use client";

import { useCallback, useEffect, useState } from "react";
import { api } from "@/lib/api";
import { useRefresh } from "@/lib/RefreshContext";
import { Markdown } from "@/components/ui/Markdown";

export default function CascadePage() {
  const { refreshKey } = useRefresh();
  const [md, setMd] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [raw, setRaw] = useState(false);
  const [auto, setAuto] = useState(true);

  const generate = useCallback(async () => {
    setBusy(true);
    setError(null);
    try {
      const res = await api.generateCascade();
      setMd(res.markdown);
    } catch (e) {
      setError(String(e));
    } finally {
      setBusy(false);
    }
  }, []);

  // Auto-calculate on load and whenever the data refreshes (e.g. after ingests).
  useEffect(() => {
    if (auto) generate();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [refreshKey]);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-lg font-bold tracking-wide">Cascading Risk</h1>
          <p className="text-xs text-slate-500">
            Systemic interaction-risk analysis across all indicators.{" "}
            <span className="text-slate-400">Not a prediction engine — identifies compounding risks.</span>
          </p>
        </div>
        <div className="flex items-center gap-3">
          <label className="flex items-center gap-1.5 text-[11px] text-slate-500" title="Recalculate automatically when data changes">
            <input type="checkbox" checked={auto} onChange={(e) => setAuto(e.target.checked)} />
            auto
          </label>
          <label className="flex items-center gap-1.5 text-[11px] text-slate-500">
            <input type="checkbox" checked={raw} onChange={(e) => setRaw(e.target.checked)} />
            raw
          </label>
          <button className="btn btn-primary" onClick={generate} disabled={busy}>
            {busy ? "Analysing…" : "Recalculate"}
          </button>
        </div>
      </div>

      {error && (
        <div className="panel border-red-500/40 p-4 text-sm text-red-400">
          {error}
          <p className="mt-1 text-xs text-slate-500">Ensure LM Studio is running on port 1234.</p>
        </div>
      )}

      {busy && !md && (
        <div className="panel flex items-center gap-3 p-6 text-sm text-slate-400">
          <span className="inline-block h-4 w-4 animate-spin rounded-full border-2 border-sky-400 border-t-transparent" />
          Cascade Risk Analyst is correlating metrics, categories, flashpoints, OSINT, cyber and outage data…
        </div>
      )}

      {md && (
        <div className="panel">
          <div className="panel-header">
            <span className="text-[12px] font-bold uppercase tracking-wider">Cascade Risk Assessment</span>
            <span className="text-[10px] text-slate-500">
              {busy ? "recalculating…" : "auto-generated from all ingested data"}
            </span>
          </div>
          <div className="p-5">
            {raw ? (
              <pre className="max-h-[1000px] overflow-auto whitespace-pre-wrap font-mono text-[12px] leading-relaxed text-slate-300">
                {md}
              </pre>
            ) : (
              <div className="max-h-[1400px] overflow-auto">
                <Markdown text={md} />
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
