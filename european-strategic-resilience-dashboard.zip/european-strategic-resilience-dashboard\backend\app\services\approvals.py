"""Shared approval helpers for AI proposals.

Auto-approve can be enabled in Settings. When on, score-change proposals are
applied immediately instead of waiting for manual review.

All score application goes through the scoring discipline:
confidence-weighted impact + the 10.0 cap.
"""
import json
from datetime import datetime

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import AIProposal, AppSetting, Category, Event, ProposalStatus
from app.services.scoring_discipline import apply_intelligence_impact, enforce_ten_cap


async def is_auto_approve(db: AsyncSession) -> bool:
    row = await db.get(AppSetting, "auto_approve")
    if row is None:
        return True  # default ON
    return str(row.value).strip().lower() in ("1", "true", "yes", "on")


async def _resolve_confidence(db: AsyncSession, proposal: AIProposal, changes: dict) -> tuple[str, str, str]:
    """Determine (confidence, source_type_name, severity) for weighting a proposal."""
    # suggest_scores proposals carry their own confidence
    if changes.get("confidence") in ("LOW", "MEDIUM", "HIGH"):
        return changes["confidence"], changes.get("source_type", ""), changes.get("severity", "MEDIUM")
    # intake proposals inherit the event's confidence + source type + severity
    if proposal.event_id:
        from app.models import ConfidenceLevel, SourceType
        ev = await db.get(Event, proposal.event_id)
        if ev:
            conf = await db.get(ConfidenceLevel, ev.confidence_level_id)
            st = await db.get(SourceType, ev.source_type_id)
            return (conf.name if conf else "MEDIUM"), (st.name if st else ""), (ev.severity or "MEDIUM")
    return "MEDIUM", "", "MEDIUM"


async def approve_and_apply(db: AsyncSession, proposal: AIProposal) -> None:
    """Mark a proposal APPROVED and apply its confidence-weighted score change."""
    proposal.status = ProposalStatus.APPROVED.value
    proposal.reviewed_at = datetime.utcnow()
    if not proposal.category_id:
        return
    try:
        changes = json.loads(proposal.proposed_changes_json or "{}")
    except json.JSONDecodeError:
        changes = {}

    cat = await db.get(Category, proposal.category_id)
    if not cat:
        return

    confidence, source_type, severity = await _resolve_confidence(db, proposal, changes)

    # Determine the raw delta (impact_delta or new_score - current)
    if "impact_delta" in changes:
        raw_delta = float(changes["impact_delta"])
    elif "new_score" in changes:
        raw_delta = float(changes["new_score"]) - cat.current_score
    else:
        raw_delta = 0.0

    # State-estimation impact: corroboration raises confidence; only a material
    # state change (outside the window / CRITICAL) moves the score, rate-limited.
    apply_intelligence_impact(cat, raw_delta, confidence, source_type, severity)

    # Preserve optional explicit confidence/trend from suggest_scores
    if changes.get("confidence") in ("LOW", "MEDIUM", "HIGH"):
        cat.confidence = changes["confidence"]
    if changes.get("trend") in ("UP", "DOWN", "STABLE"):
        cat.trend = changes["trend"]


async def enforce_cap_for_session(db: AsyncSession) -> list[str]:
    """Re-read categories, enforce the 10.0 cap, and persist. Returns demoted names."""
    cats = list((await db.execute(select(Category))).scalars().all())
    demoted = enforce_ten_cap(cats)
    if demoted:
        await db.commit()
    return demoted
