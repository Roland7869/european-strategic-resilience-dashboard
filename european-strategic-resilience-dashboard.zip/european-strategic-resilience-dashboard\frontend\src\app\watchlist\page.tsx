"use client";

import { useState } from "react";
import { api } from "@/lib/api";
import { Markdown } from "@/components/ui/Markdown";

export default function WatchlistPage() {
  const [md, setMd] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [raw, setRaw] = useState(false);

  const generate = async () => {
    setBusy(true);
    setError(null);
    try {
      const res = await api.generateWatchlist();
      setMd(res.markdown);
    } catch (e) {
      setError(String(e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-lg font-bold tracking-wide">Strategic Watch List</h1>
          <p className="text-xs text-slate-500">
            Senior Strategic Warning Analyst — indicators &amp; trigger conditions to monitor.{" "}
            <span className="text-slate-400">Not a prediction engine.</span>
          </p>
        </div>
        <div className="flex items-center gap-2">
          <label className="flex items-center gap-1.5 text-[11px] text-slate-500">
            <input type="checkbox" checked={raw} onChange={(e) => setRaw(e.target.checked)} />
            raw
          </label>
          <button className="btn btn-primary" onClick={generate} disabled={busy}>
            {busy ? "Generating…" : "Generate Watch List"}
          </button>
        </div>
      </div>

      {error && (
        <div className="panel border-red-500/40 p-4 text-sm text-red-400">
          {error}
          <p className="mt-1 text-xs text-slate-500">
            Ensure LM Studio is running on port 1234 (Settings → AI endpoint).
          </p>
        </div>
      )}

      {busy && (
        <div className="panel flex items-center gap-3 p-6 text-sm text-slate-400">
          <span className="inline-block h-4 w-4 animate-spin rounded-full border-2 border-sky-400 border-t-transparent" />
          Analyst is reviewing category scores, flashpoints and recent events…
        </div>
      )}

      {!busy && !md && !error && (
        <div className="panel p-10 text-center text-sm text-slate-500">
          Click <span className="text-slate-300">Generate Watch List</span> to produce an
          indicator-based watch list from the current dashboard state.
          <div className="mx-auto mt-4 max-w-md text-left text-[12px] text-slate-600">
            <div className="label mb-1">Covers</div>
            Executive Summary · Immediate Watch (24–72h) · Strategic Watch (1–4 weeks) ·
            Resilience Watch · Escalation Thresholds · Confidence Assessment
          </div>
        </div>
      )}

      {md && (
        <div className="panel">
          <div className="panel-header">
            <span className="text-[12px] font-bold uppercase tracking-wider">Watch List</span>
            <span className="text-[10px] text-slate-500">generated from live dashboard data</span>
          </div>
          <div className="p-5">
            {raw ? (
              <pre className="max-h-[800px] overflow-auto whitespace-pre-wrap font-mono text-[12px] leading-relaxed text-slate-300">
                {md}
              </pre>
            ) : (
              <div className="max-h-[1200px] overflow-auto">
                <Markdown text={md} />
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
