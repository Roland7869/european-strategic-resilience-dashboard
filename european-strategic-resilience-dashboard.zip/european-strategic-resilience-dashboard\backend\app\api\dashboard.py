from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.models import Category, Side
from app.schemas import CategoryScore, DashboardData
from app.services import scoring
from app.services.rule_engine import compute_overall_status

router = APIRouter(prefix="/dashboard", tags=["dashboard"])


@router.get("", response_model=DashboardData)
async def get_dashboard(db: AsyncSession = Depends(get_db)):
    summary = await scoring.compute_summary(db)
    cats = await scoring.get_category_scores(db)

    from sqlalchemy import select, func
    from app.models import Event, EventCategory
    from sqlalchemy.orm import selectinload

    # Attach event counts
    counts: dict[int, int] = {}
    result = await db.execute(
        select(EventCategory.category_id, func.count(EventCategory.id))
        .group_by(EventCategory.category_id)
    )
    for cid, cnt in result.all():
        counts[cid] = cnt

    def to_score(c: Category) -> CategoryScore:
        return CategoryScore(
            id=c.id, name=c.name, side=c.side,
            current_score=c.current_score, confidence=c.confidence,
            trend=c.trend, event_count=counts.get(c.id, 0),
            confidence_pct=c.confidence_pct, corroboration_count=c.corroboration_count,
        )

    threat = [to_score(c) for c in cats if c.side == Side.threat.value]
    resilience = [to_score(c) for c in cats if c.side == Side.resilience.value]

    overall = compute_overall_status(cats)
    summary["overall_status"] = overall

    heatmap = await scoring.heatmap_data(db)
    timeline = await scoring.timeline_data(db)
    radar = await scoring.radar_data(db)
    histogram = await scoring.histogram_data(db)
    conf_dist = await scoring.confidence_distribution(db)
    flash = await scoring.flashpoints(db)

    return DashboardData(
        summary=summary,
        threat_categories=threat,
        resilience_categories=resilience,
        heatmap=heatmap,
        timeline=timeline,
        radar=radar,
        histogram=histogram,
        confidence_distribution=conf_dist,
        flashpoints=flash,
    )
