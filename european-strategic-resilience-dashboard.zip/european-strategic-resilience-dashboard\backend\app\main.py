from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from sqlalchemy import text

from app.api import (
    ai, dashboard, events, meta, outages, preps, reports, scrape,
    settings as settings_api, uploads
)
from app.config import settings
from app.database import Base, engine

# Non-destructive column additions for the state-estimation scoring model.
# create_all() only creates missing tables, so existing DBs need these ALTERs.
_SCHEMA_UPGRADES = [
    "ALTER TABLE categories ADD COLUMN IF NOT EXISTS confidence_pct DOUBLE PRECISION DEFAULT 60",
    "ALTER TABLE categories ADD COLUMN IF NOT EXISTS corroboration_count INTEGER DEFAULT 0",
    "ALTER TABLE categories ADD COLUMN IF NOT EXISTS last_state_change_at TIMESTAMP",
    "ALTER TABLE categories ADD COLUMN IF NOT EXISTS move_24h DOUBLE PRECISION DEFAULT 0",
    "ALTER TABLE categories ADD COLUMN IF NOT EXISTS move_24h_start TIMESTAMP",
    "ALTER TABLE categories ADD COLUMN IF NOT EXISTS move_48h DOUBLE PRECISION DEFAULT 0",
    "ALTER TABLE categories ADD COLUMN IF NOT EXISTS move_48h_start TIMESTAMP",
    "ALTER TABLE events ADD COLUMN IF NOT EXISTS severity VARCHAR DEFAULT 'MEDIUM'",
    "ALTER TABLE preps ADD COLUMN IF NOT EXISTS stage INTEGER DEFAULT 1",
    # Backfill intelligence dimensions for any category not yet corroborated:
    # sync numeric confidence from the legacy string, seed a baseline corroboration.
    "UPDATE categories SET "
    "confidence_pct = CASE confidence WHEN 'HIGH' THEN 85 WHEN 'LOW' THEN 35 ELSE 60 END, "
    "corroboration_count = CASE confidence WHEN 'HIGH' THEN 3 WHEN 'MEDIUM' THEN 2 ELSE 1 END "
    "WHERE corroboration_count = 0 OR corroboration_count IS NULL",
    "UPDATE events SET severity = 'MEDIUM' WHERE severity IS NULL",
]


async def _ensure_schema() -> None:
    async with engine.begin() as conn:
        for stmt in _SCHEMA_UPGRADES:
            await conn.execute(text(stmt))


@asynccontextmanager
async def lifespan(app: FastAPI):
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    await _ensure_schema()
    if settings.RUN_SEED:
        from app.seed import run_seed
        await run_seed()
    yield
    await engine.dispose()


app = FastAPI(
    title="European Strategic Resilience Dashboard API",
    description="Strategic early-warning, resilience and geopolitical trend tracking. NOT a prediction engine.",
    version="1.1.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Serve uploaded entry images (read-only)
_UPLOADS = Path(__file__).resolve().parent / "uploads"
_UPLOADS.mkdir(exist_ok=True)
app.mount("/uploads", StaticFiles(directory=str(_UPLOADS)), name="uploads")

app.include_router(dashboard.router)
app.include_router(events.router)
app.include_router(meta.router)
app.include_router(ai.router)
app.include_router(reports.router)
app.include_router(settings_api.router)
app.include_router(preps.router)
app.include_router(scrape.router)
app.include_router(outages.router)
app.include_router(uploads.router)


@app.get("/")
async def root():
    return {"status": "ok", "service": "esrd-backend"}
