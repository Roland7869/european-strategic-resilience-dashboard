"use client";

import React from "react";

// Minimal markdown renderer tuned for the Strategic Watch List output:
// headings (#, ##, ###), bold, unordered lists, checkboxes (□/☑), hr (---),
// blockquotes and paragraphs. No external dependency.

function renderInline(text: string, keyBase: string): React.ReactNode[] {
  // Handle **bold** and `code` inline.
  const parts: React.ReactNode[] = [];
  const regex = /(\*\*[^*]+\*\*|`[^`]+`)/g;
  let last = 0;
  let m: RegExpExecArray | null;
  let i = 0;
  while ((m = regex.exec(text)) !== null) {
    if (m.index > last) parts.push(text.slice(last, m.index));
    const tok = m[0];
    if (tok.startsWith("**")) {
      parts.push(
        <strong key={`${keyBase}-b${i}`} className="font-bold text-slate-100">
          {tok.slice(2, -2)}
        </strong>
      );
    } else {
      parts.push(
        <code key={`${keyBase}-c${i}`} className="rounded bg-[#1a2334] px-1 font-mono text-[11px] text-sky-300">
          {tok.slice(1, -1)}
        </code>
      );
    }
    last = m.index + tok.length;
    i++;
  }
  if (last < text.length) parts.push(text.slice(last));
  return parts;
}

export function Markdown({ text }: { text: string }) {
  const lines = (text || "").replace(/\r\n/g, "\n").split("\n");
  const out: React.ReactNode[] = [];
  let listBuf: string[] = [];
  let paraBuf: string[] = [];

  const flushList = (k: number) => {
    if (!listBuf.length) return;
    out.push(
      <ul key={`ul-${k}`} className="my-2 space-y-1 pl-1">
        {listBuf.map((li, idx) => {
          const check = /^\[[ xX]\]/.test(li) || /^[□☑]/.test(li);
          const body = li.replace(/^\[[ xX]\]\s*/, "").replace(/^[□☑]\s*/, "");
          return (
            <li key={idx} className="flex gap-2 text-[13px] text-slate-300">
              <span className="mt-[2px] text-sky-400">{check ? "□" : "•"}</span>
              <span>{renderInline(body, `li-${k}-${idx}`)}</span>
            </li>
          );
        })}
      </ul>
    );
    listBuf = [];
  };

  const flushPara = (k: number) => {
    if (!paraBuf.length) return;
    const content = paraBuf.join(" ");
    out.push(
      <p key={`p-${k}`} className="my-2 text-[13px] leading-relaxed text-slate-300">
        {renderInline(content, `p-${k}`)}
      </p>
    );
    paraBuf = [];
  };

  lines.forEach((rawLine, idx) => {
    const line = rawLine.trimEnd();
    const trimmed = line.trim();

    if (trimmed === "" || trimmed === "---" || trimmed === "***") {
      flushList(idx);
      flushPara(idx);
      if (trimmed !== "") out.push(<hr key={`hr-${idx}`} className="my-4 border-[#1f2a3d]" />);
      return;
    }

    const h = /^(#{1,4})\s+(.*)$/.exec(trimmed);
    if (h) {
      flushList(idx);
      flushPara(idx);
      const level = h[1].length;
      const content = renderInline(h[2], `h-${idx}`);
      if (level === 1) {
        out.push(
          <h1 key={idx} className="mt-4 mb-2 text-xl font-black tracking-wide text-slate-100">
            {content}
          </h1>
        );
      } else if (level === 2) {
        out.push(
          <h2 key={idx} className="mt-5 mb-2 border-l-2 border-sky-400 pl-2 text-base font-bold uppercase tracking-wide text-sky-300">
            {content}
          </h2>
        );
      } else {
        out.push(
          <h3 key={idx} className="mt-3 mb-1 text-[13px] font-bold text-slate-200">
            {content}
          </h3>
        );
      }
      return;
    }

    if (/^[-*•]\s+/.test(trimmed) || /^[□☑]\s*/.test(trimmed) || /^\[[ xX]\]\s*/.test(trimmed)) {
      flushPara(idx);
      listBuf.push(trimmed.replace(/^([-*•]|\[[ xX]\]|[□☑])\s*/, ""));
      return;
    }

    // Continuation of a list item (indented) — append to last
    if (listBuf.length && /^\s{2,}\S/.test(line)) {
      listBuf[listBuf.length - 1] += " " + trimmed;
      return;
    }

    flushList(idx);
    paraBuf.push(trimmed);
  });

  flushList(9999);
  flushPara(9999);

  return <div className="text-slate-300">{out}</div>;
}
