"use client";

import {
  PolarAngleAxis,
  PolarGrid,
  PolarRadiusAxis,
  Radar,
  RadarChart,
  ResponsiveContainer,
  Tooltip,
} from "recharts";
import type { RadarPoint } from "@/lib/types";

export function RadarChartView({ data }: { data: RadarPoint[] }) {
  const compact = data.map((d) => ({
    ...d,
    name: d.category.length > 16 ? d.category.slice(0, 15) + "…" : d.category,
    threat: d.side === "threat" ? d.score : 0,
    resilience: d.side === "resilience" ? d.score : 0,
  }));
  return (
    <div className="h-[320px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <RadarChart data={compact} outerRadius="72%">
          <PolarGrid stroke="#1a2334" />
          <PolarAngleAxis dataKey="name" tick={{ fill: "#64748b", fontSize: 9 }} />
          <PolarRadiusAxis domain={[0, 10]} tick={{ fill: "#475569", fontSize: 8 }} />
          <Tooltip
            contentStyle={{ background: "#0d1420", border: "1px solid #2a3a55", borderRadius: 4, fontSize: 12 }}
          />
          <Radar name="Threat" dataKey="threat" stroke="#ef4444" fill="#ef4444" fillOpacity={0.35} />
          <Radar name="Resilience" dataKey="resilience" stroke="#22c55e" fill="#22c55e" fillOpacity={0.35} />
        </RadarChart>
      </ResponsiveContainer>
    </div>
  );
}
