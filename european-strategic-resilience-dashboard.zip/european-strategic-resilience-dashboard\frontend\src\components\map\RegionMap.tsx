"use client";

import { useEffect } from "react";
import {
  MapContainer,
  TileLayer,
  CircleMarker,
  Tooltip,
  useMap,
} from "react-leaflet";
import type { LatLngExpression } from "leaflet";
import type { Region } from "@/lib/types";

const CENTER: LatLngExpression = [48.0, 22.0];

function colorFor(count: number): string {
  if (count >= 5) return "#ef4444";
  if (count >= 3) return "#f97316";
  if (count >= 1) return "#eab308";
  return "#22c55e";
}

function radiusFor(count: number): number {
  return 8 + Math.min(count, 10) * 2.2;
}

function ResizeFix() {
  const map = useMap();
  useEffect(() => {
    const t = setTimeout(() => map.invalidateSize(), 200);
    return () => clearTimeout(t);
  }, [map]);
  return null;
}

export default function RegionMap({
  regions,
  counts,
  onSelect,
}: {
  regions: Region[];
  counts: Record<number, number>;
  onSelect: (r: Region) => void;
}) {
  return (
    <MapContainer
      center={CENTER}
      zoom={4}
      minZoom={3}
      maxZoom={8}
      style={{ height: "100%", width: "100%" }}
      attributionControl={true}
    >
      <ResizeFix />
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />
      {regions.map((r) => {
        const c = counts[r.id] || 0;
        return (
          <CircleMarker
            key={r.id}
            center={[r.lat, r.lng]}
            radius={radiusFor(c)}
            pathOptions={{
              color: colorFor(c),
              fillColor: colorFor(c),
              fillOpacity: 0.55,
              weight: 2,
            }}
            eventHandlers={{ click: () => onSelect(r) }}
          >
            <Tooltip direction="top" offset={[0, -8]} opacity={0.95}>
              <div style={{ background: "#0b0f17", color: "#e2e8f0", padding: "4px 6px", borderRadius: 3, fontSize: 11 }}>
                <strong>{r.name}</strong> — {c} events
              </div>
            </Tooltip>
          </CircleMarker>
        );
      })}
    </MapContainer>
  );
}
