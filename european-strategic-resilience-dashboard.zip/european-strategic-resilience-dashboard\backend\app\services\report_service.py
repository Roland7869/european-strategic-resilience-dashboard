"""Report generation: Markdown, DOCX, PDF."""
import json
from datetime import date, datetime

from docx import Document
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer


def build_markdown_report(data: dict) -> str:
    lines = [
        f"# Intelligence Briefing — {data.get('title', 'Report')}",
        f"*Generated: {datetime.utcnow().isoformat()}Z*",
        "",
        "## Executive Summary",
        data.get("executive_summary", "N/A"),
        "",
        "## Major Changes",
    ]
    for c in data.get("major_changes", []):
        lines.append(f"- {c}")
    lines += ["", "## Fastest Rising Risks"]
    for c in data.get("rising_risks", []):
        lines.append(f"- {c}")
    lines += ["", "## Fastest Rising Resilience Indicators"]
    for c in data.get("rising_resilience", []):
        lines.append(f"- {c}")
    lines += ["", "## Watch List"]
    for c in data.get("watch_list", []):
        lines.append(f"- {c}")
    lines += ["", "## Strategic Assessment"]
    lines.append(data.get("strategic_assessment", "N/A"))
    return "\n".join(lines)


def build_docx_report(data: dict) -> bytes:
    doc = Document()
    doc.add_heading(f"Intelligence Briefing — {data.get('title', 'Report')}", level=0)
    doc.add_paragraph(f"Generated: {datetime.utcnow().isoformat()}Z")

    doc.add_heading("Executive Summary", level=1)
    doc.add_paragraph(data.get("executive_summary", "N/A"))

    doc.add_heading("Major Changes", level=1)
    for c in data.get("major_changes", []):
        doc.add_paragraph(c, style="List Bullet")

    doc.add_heading("Fastest Rising Risks", level=1)
    for c in data.get("rising_risks", []):
        doc.add_paragraph(c, style="List Bullet")

    doc.add_heading("Fastest Rising Resilience Indicators", level=1)
    for c in data.get("rising_resilience", []):
        doc.add_paragraph(c, style="List Bullet")

    doc.add_heading("Watch List", level=1)
    for c in data.get("watch_list", []):
        doc.add_paragraph(c, style="List Bullet")

    doc.add_heading("Strategic Assessment", level=1)
    doc.add_paragraph(data.get("strategic_assessment", "N/A"))

    from io import BytesIO
    buf = BytesIO()
    doc.save(buf)
    return buf.getvalue()


def build_pdf_report(data: dict) -> bytes:
    from io import BytesIO
    buf = BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, topMargin=2 * cm, bottomMargin=2 * cm)
    styles = getSampleStyleSheet()
    flow = []
    flow.append(Paragraph(f"Intelligence Briefing — {data.get('title', 'Report')}", styles["Title"]))
    flow.append(Paragraph(f"Generated: {datetime.utcnow().isoformat()}Z", styles["Normal"]))
    flow.append(Spacer(1, 12))

    flow.append(Paragraph("Executive Summary", styles["Heading1"]))
    flow.append(Paragraph(data.get("executive_summary", "N/A"), styles["Normal"]))
    flow.append(Spacer(1, 8))

    flow.append(Paragraph("Major Changes", styles["Heading1"]))
    for c in data.get("major_changes", []):
        flow.append(Paragraph(f"• {c}", styles["Normal"]))
    flow.append(Spacer(1, 8))

    flow.append(Paragraph("Fastest Rising Risks", styles["Heading1"]))
    for c in data.get("rising_risks", []):
        flow.append(Paragraph(f"• {c}", styles["Normal"]))
    flow.append(Spacer(1, 8))

    flow.append(Paragraph("Fastest Rising Resilience Indicators", styles["Heading1"]))
    for c in data.get("rising_resilience", []):
        flow.append(Paragraph(f"• {c}", styles["Normal"]))
    flow.append(Spacer(1, 8))

    flow.append(Paragraph("Watch List", styles["Heading1"]))
    for c in data.get("watch_list", []):
        flow.append(Paragraph(f"• {c}", styles["Normal"]))
    flow.append(Spacer(1, 8))

    flow.append(Paragraph("Strategic Assessment", styles["Heading1"]))
    flow.append(Paragraph(data.get("strategic_assessment", "N/A"), styles["Normal"]))

    doc.build(flow)
    return buf.getvalue()
