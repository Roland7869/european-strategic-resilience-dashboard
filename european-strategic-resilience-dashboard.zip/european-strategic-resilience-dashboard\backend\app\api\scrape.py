"""OSINT scraping: manage sources, run scrapes, review + ingest scraped items."""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.models import ConfidenceLevel, ScrapeSource, ScrapedItem, Source, SourceType
from app.schemas import (
    IngestAllResult, ScrapeRunResult, ScrapeSourceCreate, ScrapeSourceOut, ScrapedItemOut
)
from app.services.scraper import (
    SSRFError, TIER_CONFIDENCE, detect_topics, run_scrape, validate_public_url
)

router = APIRouter(prefix="/scrape", tags=["scrape"])


@router.get("/sources", response_model=list[ScrapeSourceOut])
async def list_sources(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(ScrapeSource).order_by(ScrapeSource.name))
    return list(result.scalars().all())


@router.post("/sources", response_model=ScrapeSourceOut, status_code=201)
async def create_source(payload: ScrapeSourceCreate, db: AsyncSession = Depends(get_db)):
    try:
        validate_public_url(payload.url)
    except SSRFError as e:
        raise HTTPException(status_code=400, detail=f"Invalid URL: {e}")
    if payload.kind not in ("rss", "html"):
        raise HTTPException(status_code=400, detail="kind must be 'rss' or 'html'")
    data = payload.model_dump()
    # Derive base_confidence from the tier so weighting stays consistent
    data["base_confidence"] = TIER_CONFIDENCE.get(payload.tier, payload.base_confidence or "LOW")
    src = ScrapeSource(**data)
    db.add(src)
    await db.commit()
    await db.refresh(src)
    return src


@router.delete("/sources/{source_id}", status_code=204)
async def delete_source(source_id: int, db: AsyncSession = Depends(get_db)):
    src = await db.get(ScrapeSource, source_id)
    if not src:
        raise HTTPException(status_code=404, detail="Source not found")
    await db.delete(src)
    await db.commit()


@router.post("/run", response_model=ScrapeRunResult)
async def scrape_now(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(ScrapeSource))
    sources = list(result.scalars().all())
    if not sources:
        return ScrapeRunResult(sources=0, new_items=0, errors=["No sources configured"])
    out = await run_scrape(sources, db)
    return ScrapeRunResult(**out)


@router.get("/items", response_model=list[ScrapedItemOut])
async def list_items(
    db: AsyncSession = Depends(get_db),
    limit: int = 100,
    uningested_only: bool = False,
    topic: str | None = None,
):
    q = select(ScrapedItem).order_by(ScrapedItem.fetched_at.desc()).limit(limit)
    if uningested_only:
        q = q.where(ScrapedItem.ingested == False)  # noqa: E712
    result = await db.execute(q)
    items = list(result.scalars().all())
    out: list[ScrapedItemOut] = []
    for it in items:
        topics = detect_topics(f"{it.title} {it.summary or ''}")
        if topic and topic not in topics:
            continue
        out.append(
            ScrapedItemOut(
                id=it.id, source_id=it.source_id, title=it.title, url=it.url,
                summary=it.summary, published=it.published, ingested=it.ingested,
                ingested_event_id=it.ingested_event_id, fetched_at=it.fetched_at,
                topics=topics,
            )
        )
    return out


@router.post("/items/{item_id}/ingest")
async def ingest_item(item_id: int, db: AsyncSession = Depends(get_db)):
    """Convert a scraped headline into a fully AI-classified entry via /events/ai logic."""
    from datetime import date as date_cls
    from app.api.events import create_event_with_ai
    from app.schemas import EventCreateMinimal, EventAIOut

    item = await db.get(ScrapedItem, item_id)
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")
    if item.ingested:
        raise HTTPException(status_code=400, detail="Already ingested")

    src = await db.get(ScrapeSource, item.source_id)
    payload = EventCreateMinimal(
        event_date=date_cls.today(),
        title=item.title,
        summary=(item.summary or item.title) + (f"\nSource URL: {item.url}" if item.url else ""),
        source_name=src.name if src else "OSINT",
        min_confidence=src.base_confidence if src else None,
    )
    # Reuse the AI classification endpoint's core logic
    ev_out: EventAIOut = await create_event_with_ai(payload, db)
    item.ingested = True
    item.ingested_event_id = ev_out.event.id
    await db.commit()
    return {
        "ingested": True,
        "event_id": ev_out.event.id,
        "entry_number": ev_out.event.entry_number,
        "ai_confidence": ev_out.ai_confidence,
        "ai_categories": ev_out.ai_categories,
    }


def _build_ingest_payload(item: ScrapedItem, src: ScrapeSource | None):
    from datetime import date as date_cls
    from app.schemas import EventCreateMinimal
    return EventCreateMinimal(
        event_date=date_cls.today(),
        title=item.title,
        summary=(item.summary or item.title) + (f"\nSource URL: {item.url}" if item.url else ""),
        source_name=src.name if src else "OSINT",
        min_confidence=src.base_confidence if src else None,
    )


@router.post("/items/ingest-all", response_model=IngestAllResult)
async def ingest_all(db: AsyncSession = Depends(get_db)):
    """Ingest every uningested headline into an AI-classified entry, one after another."""
    from app.api.events import create_event_with_ai

    result = await db.execute(
        select(ScrapedItem).where(ScrapedItem.ingested == False).order_by(ScrapedItem.fetched_at)  # noqa: E712
    )
    items = list(result.scalars().all())
    succeeded = 0
    failed = 0
    errors: list[str] = []
    for item in items:
        src = await db.get(ScrapeSource, item.source_id)
        try:
            ev_out = await create_event_with_ai(_build_ingest_payload(item, src), db)
            item.ingested = True
            item.ingested_event_id = ev_out.event.id
            await db.commit()
            succeeded += 1
        except Exception as e:  # noqa: BLE001 - continue on per-item failures
            await db.rollback()
            failed += 1
            errors.append(f"{item.title[:60]}: {e}")
    return IngestAllResult(attempted=len(items), succeeded=succeeded, failed=failed, errors=errors)
