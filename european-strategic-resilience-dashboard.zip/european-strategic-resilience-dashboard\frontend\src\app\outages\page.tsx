"use client";

import { useEffect, useMemo, useState } from "react";
import { api } from "@/lib/api";
import { useRefresh } from "@/lib/RefreshContext";
import type { Outage, OutageLocations, OutageScrapeResult, OutageSource } from "@/lib/types";

function typeBadge(t: string) {
  return t === "SCHEDULED"
    ? { color: "#3b82f6", label: "Scheduled" }
    : { color: "#ef4444", label: "Unscheduled" };
}

export default function OutagesPage() {
  const { refreshKey } = useRefresh();
  const [locations, setLocations] = useState<OutageLocations | null>(null);
  const [sources, setSources] = useState<OutageSource[]>([]);
  const [outages, setOutages] = useState<Outage[]>([]);
  const [error, setError] = useState<string | null>(null);

  // Country → State → City selection
  const [country, setCountry] = useState("");
  const [region, setRegion] = useState("");
  const [city, setCity] = useState("");
  const [typeFilter, setTypeFilter] = useState("");

  const [busy, setBusy] = useState(false);
  const [scrapeResult, setScrapeResult] = useState<OutageScrapeResult | null>(null);
  const [ingesting, setIngesting] = useState<number | null>(null);
  const [showSources, setShowSources] = useState(false);
  const [form, setForm] = useState({ name: "", country: "", region: "", city: "", url: "", kind: "rss" });
  const [adding, setAdding] = useState(false);

  const load = async () => {
    try {
      const [locs, srcs, outs] = await Promise.all([
        api.getOutageLocations(),
        api.getOutageSources(),
        api.getOutages({
          country: country || undefined,
          region: region || undefined,
          city: city || undefined,
          outage_type: typeFilter || undefined,
        }),
      ]);
      setLocations(locs);
      setSources(srcs);
      setOutages(outs);
      setError(null);
    } catch (e) {
      setError(String(e));
    }
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [refreshKey, country, region, city, typeFilter]);

  const regions = useMemo(() => (country && locations?.regions[country]) || [], [country, locations]);
  const cities = useMemo(
    () => (country && locations?.cities[`${country}|${region}`]) || [],
    [country, region, locations]
  );

  const scrape = async () => {
    setBusy(true);
    setScrapeResult(null);
    try {
      setScrapeResult(
        await api.scrapeOutages({
          country: country || undefined,
          region: region || undefined,
          city: city || undefined,
        })
      );
      await load();
    } catch (e) {
      alert(String(e));
    } finally {
      setBusy(false);
    }
  };

  const ingest = async (o: Outage) => {
    setIngesting(o.id);
    try {
      const res = await api.ingestOutage(o.id);
      alert(`Ingested as entry #${res.entry_number}\nConfidence: ${res.ai_confidence}\nCategories: ${res.ai_categories.join(", ")}`);
      await load();
    } catch (e) {
      alert(String(e));
    } finally {
      setIngesting(null);
    }
  };

  const addSource = async () => {
    if (!form.name || !form.country || !form.url) return alert("Name, country and URL required");
    setAdding(true);
    try {
      await api.createOutageSource({
        name: form.name, country: form.country,
        region: form.region || undefined, city: form.city || undefined,
        url: form.url, kind: form.kind,
      });
      setForm({ name: "", country: "", region: "", city: "", url: "", kind: "rss" });
      await load();
    } catch (e) {
      alert(String(e));
    } finally {
      setAdding(false);
    }
  };

  const removeSource = async (s: OutageSource) => {
    if (!confirm(`Delete source "${s.name}"?`)) return;
    try {
      await api.deleteOutageSource(s.id);
      await load();
    } catch (e) {
      alert(String(e));
    }
  };

  const scheduled = outages.filter((o) => o.outage_type === "SCHEDULED").length;
  const unscheduled = outages.filter((o) => o.outage_type === "UNSCHEDULED").length;

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-lg font-bold tracking-wide">Power Outages</h1>
          <p className="text-xs text-slate-500">
            Scrape outage feeds by location. Scheduled (planned) vs Unscheduled (fault/blackout) are classified automatically.
          </p>
        </div>
        <button className="btn" onClick={() => setShowSources((s) => !s)}>
          {showSources ? "Hide sources" : `Manage sources (${sources.length})`}
        </button>
      </div>

      {/* Location picker + scrape */}
      <div className="panel">
        <div className="panel-header">
          <span className="text-[12px] font-bold uppercase tracking-wider">Location & Scrape</span>
          <span className="text-[10px] text-slate-500">{scheduled} scheduled · {unscheduled} unscheduled shown</span>
        </div>
        <div className="flex flex-wrap items-end gap-3 p-4">
          <div>
            <label className="label">Country</label>
            <select
              className="mt-1 w-44"
              value={country}
              onChange={(e) => { setCountry(e.target.value); setRegion(""); setCity(""); }}
            >
              <option value="">All countries</option>
              {locations?.countries.map((c) => <option key={c}>{c}</option>)}
            </select>
          </div>
          <div>
            <label className="label">State / Region</label>
            <select
              className="mt-1 w-40"
              value={region}
              onChange={(e) => { setRegion(e.target.value); setCity(""); }}
              disabled={!country || regions.length === 0}
            >
              <option value="">All regions</option>
              {regions.map((r) => <option key={r}>{r}</option>)}
            </select>
          </div>
          <div>
            <label className="label">City</label>
            <select
              className="mt-1 w-40"
              value={city}
              onChange={(e) => setCity(e.target.value)}
              disabled={!region || cities.length === 0}
            >
              <option value="">All cities</option>
              {cities.map((c) => <option key={c}>{c}</option>)}
            </select>
          </div>
          <div>
            <label className="label">Type</label>
            <select className="mt-1 w-36" value={typeFilter} onChange={(e) => setTypeFilter(e.target.value)}>
              <option value="">All types</option>
              <option value="SCHEDULED">Scheduled</option>
              <option value="UNSCHEDULED">Unscheduled</option>
            </select>
          </div>
          <button className="btn btn-primary" onClick={scrape} disabled={busy}>
            {busy ? "Scraping…" : "Scrape outages"}
          </button>
        </div>
        {scrapeResult && (
          <div className="border-t border-[#1f2a3d] px-4 py-2 text-[12px]">
            <span className="text-slate-300">Scraped {scrapeResult.sources} source(s) → {scrapeResult.new_outages} new outage(s).</span>
            {scrapeResult.errors.length > 0 && (
              <div className="mt-1 text-amber-400">Warnings: {scrapeResult.errors.join(" · ")}</div>
            )}
          </div>
        )}
      </div>

      {/* Manage sources */}
      {showSources && (
        <div className="panel">
          <div className="panel-header">
            <span className="text-[12px] font-bold uppercase tracking-wider">Outage Sources</span>
            <span className="text-[10px] text-slate-500">{sources.length} feeds · add your utility's outage feed/map</span>
          </div>
          <div className="divide-y divide-[#1a2334]">
            {sources.map((s) => (
              <div key={s.id} className="flex flex-wrap items-center justify-between gap-2 px-4 py-2">
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="rounded bg-[#1a2334] px-1.5 py-0.5 text-[10px] font-bold uppercase text-sky-400">{s.kind}</span>
                    <span className="text-[13px] font-semibold text-slate-200">{s.name}</span>
                    <span className="text-[11px] text-slate-500">
                      {[s.city, s.region, s.country].filter(Boolean).join(", ")}
                    </span>
                  </div>
                  <div className="truncate text-[11px] text-slate-500">{s.url}</div>
                </div>
                <button className="text-[11px] text-red-400 hover:underline" onClick={() => removeSource(s)}>Delete</button>
              </div>
            ))}
          </div>
          <div className="grid grid-cols-1 gap-2 border-t border-[#1f2a3d] p-3 md:grid-cols-6">
            <input placeholder="Name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            <input placeholder="Country" value={form.country} onChange={(e) => setForm({ ...form, country: e.target.value })} />
            <input placeholder="State/Region" value={form.region} onChange={(e) => setForm({ ...form, region: e.target.value })} />
            <input placeholder="City" value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} />
            <input placeholder="https://… (RSS or page)" value={form.url} onChange={(e) => setForm({ ...form, url: e.target.value })} />
            <div className="flex gap-2">
              <select value={form.kind} onChange={(e) => setForm({ ...form, kind: e.target.value })}>
                <option value="rss">RSS</option>
                <option value="html">HTML</option>
              </select>
              <button className="btn btn-primary" onClick={addSource} disabled={adding}>{adding ? "…" : "Add"}</button>
            </div>
          </div>
        </div>
      )}

      {/* Outage list */}
      <div className="panel">
        <div className="panel-header">
          <span className="text-[12px] font-bold uppercase tracking-wider">Outages</span>
          <span className="text-[10px] text-slate-500">{outages.length} shown · newest first</span>
        </div>
        {error && <div className="p-4 text-sm text-red-400">{error}</div>}
        {outages.length === 0 ? (
          <div className="p-8 text-center text-sm text-slate-500">
            No outages{country ? ` for ${[city, region, country].filter(Boolean).join(", ")}` : ""}. Pick a location and click Scrape.
          </div>
        ) : (
          <div className="max-h-[700px] divide-y divide-[#1a2334] overflow-y-auto">
            {outages.map((o) => {
              const b = typeBadge(o.outage_type);
              return (
                <div key={o.id} className="flex flex-wrap items-start justify-between gap-3 px-4 py-2.5">
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="badge" style={{ color: b.color, borderColor: `${b.color}55`, background: `${b.color}18` }}>
                        {b.label}
                      </span>
                      <a href={o.url || "#"} target="_blank" rel="noopener noreferrer" className="text-[13px] font-semibold text-slate-200 hover:text-sky-400">
                        {o.title}
                      </a>
                    </div>
                    <div className="mt-0.5 text-[11px] text-slate-500">
                      {[o.city, o.region, o.country].filter(Boolean).join(", ")}
                      {o.customers_affected != null && <span> · ~{o.customers_affected.toLocaleString()} affected</span>}
                      {o.ingested && <span className="ml-2 text-emerald-400">· ingested</span>}
                    </div>
                    {o.details && <p className="mt-0.5 line-clamp-2 text-[11px] text-slate-500">{o.details}</p>}
                  </div>
                  {!o.ingested && (
                    <button className="btn !px-2 !py-1 !text-[11px]" disabled={ingesting === o.id} onClick={() => ingest(o)}>
                      {ingesting === o.id ? "AI classifying…" : "Ingest → entry"}
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
