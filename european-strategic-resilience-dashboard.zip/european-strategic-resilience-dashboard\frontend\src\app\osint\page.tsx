"use client";

import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import { useRefresh } from "@/lib/RefreshContext";
import { OSINT_TIERS, TIER_COLORS } from "@/lib/constants";
import type { IngestAllResult, ScrapeRunResult, ScrapeSource, ScrapedItem } from "@/lib/types";

// Collection is restricted to these OSINT topics (see backend TOPIC_KEYWORDS).
const TOPICS = ["Economy", "Flash Points", "Food Shortages", "Supply Chain"] as const;

export default function OsintPage() {
  const { refreshKey } = useRefresh();
  const [sources, setSources] = useState<ScrapeSource[]>([]);
  const [items, setItems] = useState<ScrapedItem[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [runResult, setRunResult] = useState<ScrapeRunResult | null>(null);
  const [ingestAllResult, setIngestAllResult] = useState<IngestAllResult | null>(null);
  const [ingesting, setIngesting] = useState<number | null>(null);
  const [ingestingAll, setIngestingAll] = useState(false);
  const [onlyUningested, setOnlyUningested] = useState(true);
  const [topic, setTopic] = useState<string | null>(null);

  const [form, setForm] = useState({ name: "", url: "", kind: "rss", tier: "Tier 1 - News Wires" });
  const [adding, setAdding] = useState(false);

  const load = async () => {
    try {
      const [s, i] = await Promise.all([
        api.getScrapeSources(),
        api.getScrapedItems(onlyUningested, topic || undefined),
      ]);
      setSources(s);
      setItems(i);
      setError(null);
    } catch (e) {
      setError(String(e));
    }
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [refreshKey, onlyUningested, topic]);

  const runScrape = async () => {
    setBusy(true);
    setRunResult(null);
    try {
      setRunResult(await api.runScrape());
      await load();
    } catch (e) {
      alert(String(e));
    } finally {
      setBusy(false);
    }
  };

  const ingestAll = async () => {
    if (!confirm("Ingest ALL uningested headlines as AI-classified entries? This runs the AI once per item.")) return;
    setIngestingAll(true);
    setIngestAllResult(null);
    try {
      setIngestAllResult(await api.ingestAll());
      await load();
    } catch (e) {
      alert(String(e));
    } finally {
      setIngestingAll(false);
    }
  };

  const addSource = async () => {
    if (!form.name || !form.url) return alert("Name and URL required");
    setAdding(true);
    try {
      await api.createScrapeSource(form);
      setForm({ name: "", url: "", kind: "rss", tier: "Tier 1 - News Wires" });
      await load();
    } catch (e) {
      alert(String(e));
    } finally {
      setAdding(false);
    }
  };

  const removeSource = async (s: ScrapeSource) => {
    if (!confirm(`Delete source "${s.name}"?`)) return;
    try {
      await api.deleteScrapeSource(s.id);
      await load();
    } catch (e) {
      alert(String(e));
    }
  };

  const ingest = async (item: ScrapedItem) => {
    setIngesting(item.id);
    try {
      const res = await api.ingestItem(item.id);
      alert(
        `Ingested as entry #${res.entry_number}\nConfidence: ${res.ai_confidence}\nCategories: ${res.ai_categories.join(", ")}`
      );
      await load();
    } catch (e) {
      alert(String(e));
    } finally {
      setIngesting(null);
    }
  };

  const uningestedCount = items.filter((i) => !i.ingested).length;

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-lg font-bold tracking-wide">OSINT Collection</h1>
          <p className="text-xs text-slate-500">
            Restricted to <span className="text-slate-300">Economy · Flash Points · Food Shortages · Supply Chain</span>.
            Scrape feeds, then ingest headlines as AI-classified entries.
          </p>
        </div>
        <div className="flex gap-2">
          <button className="btn btn-primary" onClick={runScrape} disabled={busy}>
            {busy ? "Scraping…" : "Run scrape"}
          </button>
          <button className="btn" onClick={ingestAll} disabled={ingestingAll || uningestedCount === 0}>
            {ingestingAll ? "Ingesting all…" : `Ingest All (${uningestedCount})`}
          </button>
        </div>
      </div>

      {runResult && (
        <div className="panel px-4 py-3 text-[12px]">
          <span className="text-slate-300">
            Scraped {runResult.sources} source(s) → {runResult.new_items} new relevant item(s).
          </span>
          {runResult.errors.length > 0 && (
            <div className="mt-1 text-amber-400">Warnings: {runResult.errors.join(" · ")}</div>
          )}
        </div>
      )}

      {ingestAllResult && (
        <div className="panel px-4 py-3 text-[12px]">
          <span className="text-slate-300">
            Ingested {ingestAllResult.succeeded}/{ingestAllResult.attempted} item(s)
            {ingestAllResult.failed > 0 && <span className="text-amber-400"> · {ingestAllResult.failed} failed</span>}.
          </span>
          {ingestAllResult.errors.length > 0 && (
            <div className="mt-1 max-h-24 overflow-auto text-amber-400">
              {ingestAllResult.errors.join(" · ")}
            </div>
          )}
        </div>
      )}

      {/* Sources */}
      <div className="panel">
        <div className="panel-header">
          <span className="text-[12px] font-bold uppercase tracking-wider">Sources</span>
          <span className="text-[10px] text-slate-500">{sources.length} feeds</span>
        </div>
        <div className="divide-y divide-[#1a2334]">
          {sources.map((s) => (
            <div key={s.id} className="flex flex-wrap items-center justify-between gap-2 px-4 py-2">
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="rounded bg-[#1a2334] px-1.5 py-0.5 text-[10px] font-bold uppercase text-sky-400">{s.kind}</span>
                  <span
                    className="rounded px-1.5 py-0.5 text-[10px] font-bold"
                    style={{
                      color: TIER_COLORS[s.tier] || "#94a3b8",
                      background: `${TIER_COLORS[s.tier] || "#94a3b8"}18`,
                    }}
                    title={`Score impact weight: ${s.base_confidence}`}
                  >
                    {s.tier} · {s.base_confidence}
                  </span>
                  <span className="text-[13px] font-semibold text-slate-200">{s.name}</span>
                </div>
                <div className="truncate text-[11px] text-slate-500">{s.url}</div>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-[10px] text-slate-500">
                  {s.last_fetched ? `fetched ${new Date(s.last_fetched).toLocaleString()}` : "never"}
                </span>
                <button className="text-[11px] text-red-400 hover:underline" onClick={() => removeSource(s)}>Delete</button>
              </div>
            </div>
          ))}
        </div>
        <div className="grid grid-cols-1 gap-2 border-t border-[#1f2a3d] p-3 md:grid-cols-5">
          <input className="md:col-span-1" placeholder="Name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          <input className="md:col-span-2" placeholder="https://example.com/feed.xml" value={form.url} onChange={(e) => setForm({ ...form, url: e.target.value })} />
          <select value={form.tier} onChange={(e) => setForm({ ...form, tier: e.target.value })} title="Tier (sets confidence weight)">
            {OSINT_TIERS.map((t) => <option key={t}>{t}</option>)}
          </select>
          <div className="flex gap-2">
            <select value={form.kind} onChange={(e) => setForm({ ...form, kind: e.target.value })}>
              <option value="rss">RSS</option>
              <option value="html">HTML</option>
            </select>
            <button className="btn btn-primary" onClick={addSource} disabled={adding}>{adding ? "…" : "Add"}</button>
          </div>
        </div>
      </div>

      {/* Topic filter + scraped items */}
      <div className="panel">
        <div className="panel-header flex-wrap">
          <span className="text-[12px] font-bold uppercase tracking-wider">Scraped Headlines</span>
          <div className="flex flex-wrap items-center gap-1.5">
            <button
              className={`rounded px-2 py-0.5 text-[11px] font-semibold ${topic === null ? "bg-sky-600 text-white" : "bg-[#1a2334] text-slate-400"}`}
              onClick={() => setTopic(null)}
            >
              All topics
            </button>
            {TOPICS.map((t) => (
              <button
                key={t}
                className={`rounded px-2 py-0.5 text-[11px] font-semibold ${topic === t ? "bg-sky-600 text-white" : "bg-[#1a2334] text-slate-400"}`}
                onClick={() => setTopic(t)}
              >
                {t}
              </button>
            ))}
            <label className="ml-2 flex items-center gap-1.5 text-[10px] text-slate-500">
              <input type="checkbox" checked={onlyUningested} onChange={(e) => setOnlyUningested(e.target.checked)} />
              uningested only
            </label>
          </div>
        </div>
        {error && <div className="p-4 text-sm text-red-400">{error}</div>}
        {items.length === 0 ? (
          <div className="p-8 text-center text-sm text-slate-500">
            No items{topic ? ` tagged "${topic}"` : ""}. Run a scrape to pull relevant headlines.
          </div>
        ) : (
          <div className="max-h-[600px] divide-y divide-[#1a2334] overflow-y-auto">
            {items.map((it) => (
              <div key={it.id} className="flex flex-wrap items-start justify-between gap-3 px-4 py-2.5">
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    {it.ingested ? (
                      <span className="badge" style={{ color: "#22c55e", borderColor: "#22c55e55" }}>INGESTED</span>
                    ) : (
                      <span className="badge" style={{ color: "#eab308", borderColor: "#eab30855" }}>NEW</span>
                    )}
                    <a
                      href={it.url || "#"}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-[13px] font-semibold text-slate-200 hover:text-sky-400"
                    >
                      {it.title}
                    </a>
                  </div>
                  <div className="mt-1 flex flex-wrap gap-1">
                    {(it.topics || []).map((t) => (
                      <span key={t} className="rounded bg-[#24324a] px-1.5 py-0.5 text-[10px] text-sky-300">{t}</span>
                    ))}
                  </div>
                  {it.summary && <p className="mt-0.5 line-clamp-2 text-[11px] text-slate-500">{it.summary}</p>}
                </div>
                {!it.ingested && (
                  <button
                    className="btn !px-2 !py-1 !text-[11px]"
                    disabled={ingesting === it.id || ingestingAll}
                    onClick={() => ingest(it)}
                  >
                    {ingesting === it.id ? "AI classifying…" : "Ingest → entry"}
                  </button>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
