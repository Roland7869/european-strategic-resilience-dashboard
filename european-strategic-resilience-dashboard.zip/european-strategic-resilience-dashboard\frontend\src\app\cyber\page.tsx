"use client";

import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import { useRefresh } from "@/lib/RefreshContext";
import type { CyberAttack, CyberScrapeResult, CyberSource } from "@/lib/types";

const SEV_COLORS: Record<string, string> = {
  CRITICAL: "#ef4444",
  HIGH: "#f97316",
  MEDIUM: "#eab308",
  LOW: "#94a3b8",
};

export default function CyberPage() {
  const { refreshKey } = useRefresh();
  const [sources, setSources] = useState<CyberSource[]>([]);
  const [attacks, setAttacks] = useState<CyberAttack[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [scrapeResult, setScrapeResult] = useState<CyberScrapeResult | null>(null);
  const [ingesting, setIngesting] = useState<number | null>(null);
  const [sevFilter, setSevFilter] = useState("");
  const [showSources, setShowSources] = useState(false);
  const [form, setForm] = useState({ name: "", url: "", kind: "rss" });
  const [adding, setAdding] = useState(false);

  const load = async () => {
    try {
      const [srcs, atks] = await Promise.all([
        api.getCyberSources(),
        api.getCyberAttacks({ severity: sevFilter || undefined }),
      ]);
      setSources(srcs);
      setAttacks(atks);
      setError(null);
    } catch (e) {
      setError(String(e));
    }
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [refreshKey, sevFilter]);

  const scrape = async () => {
    setBusy(true);
    setScrapeResult(null);
    try {
      setScrapeResult(await api.scrapeCyber());
      await load();
    } catch (e) {
      alert(String(e));
    } finally {
      setBusy(false);
    }
  };

  const ingest = async (a: CyberAttack) => {
    setIngesting(a.id);
    try {
      const res = await api.ingestCyber(a.id);
      alert(`Ingested as entry #${res.entry_number}\nConfidence: ${res.ai_confidence}\nCategories: ${res.ai_categories.join(", ")}`);
      await load();
    } catch (e) {
      alert(String(e));
    } finally {
      setIngesting(null);
    }
  };

  const addSource = async () => {
    if (!form.name || !form.url) return alert("Name and URL required");
    setAdding(true);
    try {
      await api.createCyberSource(form);
      setForm({ name: "", url: "", kind: "rss" });
      await load();
    } catch (e) {
      alert(String(e));
    } finally {
      setAdding(false);
    }
  };

  const removeSource = async (s: CyberSource) => {
    if (!confirm(`Delete source "${s.name}"?`)) return;
    try {
      await api.deleteCyberSource(s.id);
      await load();
    } catch (e) {
      alert(String(e));
    }
  };

  const counts = attacks.reduce<Record<string, number>>((m, a) => {
    m[a.severity] = (m[a.severity] || 0) + 1;
    return m;
  }, {});

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-lg font-bold tracking-wide">Cyber Attacks</h1>
          <p className="text-xs text-slate-500">
            Threat-intelligence headlines classified by severity &amp; attack type, auto-ingested into entries.
          </p>
        </div>
        <div className="flex gap-2">
          <button className="btn" onClick={() => setShowSources((s) => !s)}>
            {showSources ? "Hide sources" : `Sources (${sources.length})`}
          </button>
          <button className="btn btn-primary" onClick={scrape} disabled={busy}>
            {busy ? "Scraping & ingesting…" : "Run scrape"}
          </button>
        </div>
      </div>

      {scrapeResult && (
        <div className="panel px-4 py-3 text-[12px]">
          <span className="text-slate-300">
            Scraped {scrapeResult.sources} source(s) → {scrapeResult.new_attacks} new · auto-ingested {scrapeResult.ingested}.
          </span>
          {scrapeResult.errors.length > 0 && (
            <div className="mt-1 max-h-20 overflow-auto text-amber-400">{scrapeResult.errors.join(" · ")}</div>
          )}
        </div>
      )}

      {/* Severity filter */}
      <div className="flex flex-wrap items-center gap-2">
        <span className="label">Severity</span>
        {["", "CRITICAL", "HIGH", "MEDIUM", "LOW"].map((s) => (
          <button
            key={s || "all"}
            className={`rounded px-2.5 py-1 text-[11px] font-semibold ${sevFilter === s ? "bg-sky-600 text-white" : "bg-[#1a2334] text-slate-400"}`}
            onClick={() => setSevFilter(s)}
          >
            {s || "All"}
            {s && counts[s] ? ` (${counts[s]})` : ""}
          </button>
        ))}
      </div>

      {/* Sources */}
      {showSources && (
        <div className="panel">
          <div className="panel-header">
            <span className="text-[12px] font-bold uppercase tracking-wider">Cyber Sources</span>
            <span className="text-[10px] text-slate-500">{sources.length} feeds</span>
          </div>
          <div className="divide-y divide-[#1a2334]">
            {sources.map((s) => (
              <div key={s.id} className="flex flex-wrap items-center justify-between gap-2 px-4 py-2">
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="rounded bg-[#1a2334] px-1.5 py-0.5 text-[10px] font-bold uppercase text-sky-400">{s.kind}</span>
                    <span className="text-[13px] font-semibold text-slate-200">{s.name}</span>
                  </div>
                  <div className="truncate text-[11px] text-slate-500">{s.url}</div>
                </div>
                <button className="text-[11px] text-red-400 hover:underline" onClick={() => removeSource(s)}>Delete</button>
              </div>
            ))}
          </div>
          <div className="grid grid-cols-1 gap-2 border-t border-[#1f2a3d] p-3 md:grid-cols-4">
            <input placeholder="Name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            <input className="md:col-span-2" placeholder="https://… (RSS or page)" value={form.url} onChange={(e) => setForm({ ...form, url: e.target.value })} />
            <div className="flex gap-2">
              <select value={form.kind} onChange={(e) => setForm({ ...form, kind: e.target.value })}>
                <option value="rss">RSS</option>
                <option value="html">HTML</option>
              </select>
              <button className="btn btn-primary" onClick={addSource} disabled={adding}>{adding ? "…" : "Add"}</button>
            </div>
          </div>
        </div>
      )}

      {/* Attacks list */}
      <div className="panel">
        <div className="panel-header">
          <span className="text-[12px] font-bold uppercase tracking-wider">Cyber Attacks</span>
          <span className="text-[10px] text-slate-500">{attacks.length} shown · newest first</span>
        </div>
        {error && <div className="p-4 text-sm text-red-400">{error}</div>}
        {attacks.length === 0 ? (
          <div className="p-8 text-center text-sm text-slate-500">
            No attacks{sevFilter ? ` at ${sevFilter} severity` : ""}. Click Run scrape to pull threat intel.
          </div>
        ) : (
          <div className="max-h-[700px] divide-y divide-[#1a2334] overflow-y-auto">
            {attacks.map((a) => {
              const c = SEV_COLORS[a.severity] || "#94a3b8";
              return (
                <div key={a.id} className="flex flex-wrap items-start justify-between gap-3 px-4 py-2.5">
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="badge" style={{ color: c, borderColor: `${c}55`, background: `${c}18` }}>
                        {a.severity}
                      </span>
                      <span className="rounded bg-[#24324a] px-1.5 py-0.5 text-[10px] text-sky-300">{a.attack_type}</span>
                      <a href={a.url || "#"} target="_blank" rel="noopener noreferrer" className="text-[13px] font-semibold text-slate-200 hover:text-sky-400">
                        {a.title}
                      </a>
                    </div>
                    <div className="mt-0.5 text-[11px] text-slate-500">
                      {new Date(a.scraped_at).toLocaleString()}
                      {a.ingested && <span className="ml-2 text-emerald-400">· ingested</span>}
                    </div>
                    {a.summary && <p className="mt-0.5 line-clamp-2 text-[11px] text-slate-500">{a.summary}</p>}
                  </div>
                  {!a.ingested && (
                    <button className="btn !px-2 !py-1 !text-[11px]" disabled={ingesting === a.id} onClick={() => ingest(a)}>
                      {ingesting === a.id ? "AI classifying…" : "Ingest → entry"}
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
