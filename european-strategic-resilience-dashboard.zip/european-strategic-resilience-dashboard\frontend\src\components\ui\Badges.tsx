"use client";

import { CONFIDENCE_COLORS, STATUS_BADGES, TREND_COLORS } from "@/lib/constants";

export function StatusBadge({ status }: { status: string }) {
  const b = STATUS_BADGES[status] || { color: "#94a3b8", label: status };
  return (
    <span
      className="badge"
      style={{ color: b.color, borderColor: `${b.color}55`, background: `${b.color}18` }}
    >
      <span className="h-1.5 w-1.5 rounded-full" style={{ background: b.color }} />
      {b.label}
    </span>
  );
}

export function ConfidenceBadge({ level }: { level: string }) {
  const color = CONFIDENCE_COLORS[level] || "#94a3b8";
  return (
    <span
      className="badge"
      style={{ color, borderColor: `${color}55`, background: `${color}18` }}
    >
      {level}
    </span>
  );
}

export function TrendArrow({ trend }: { trend: string }) {
  const color = TREND_COLORS[trend] || "#8494ab";
  const glyph = trend === "UP" ? "▲" : trend === "DOWN" ? "▼" : "■";
  return (
    <span className="badge" style={{ color, borderColor: `${color}44`, background: "transparent" }}>
      {glyph} {trend}
    </span>
  );
}
