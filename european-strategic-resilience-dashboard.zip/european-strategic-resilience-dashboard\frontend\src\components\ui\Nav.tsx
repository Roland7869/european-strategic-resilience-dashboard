"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useRefresh } from "@/lib/RefreshContext";

const LINKS = [
  { href: "/", label: "Dashboard" },
  { href: "/watchlist", label: "Watch List" },
  { href: "/entries", label: "Entries" },
  { href: "/map", label: "Regions" },
  { href: "/preps", label: "Preps" },
  { href: "/outages", label: "Outages" },
  { href: "/osint", label: "OSINT" },
  { href: "/briefing", label: "Briefing" },
  { href: "/assistant", label: "AI" },
  { href: "/settings", label: "Settings" },
];

export function Nav() {
  const pathname = usePathname();
  const router = useRouter();
  const { refresh } = useRefresh();

  // Global "update everything in one go": bump the refresh key (pages refetch)
  // and re-navigate so the current view reloads fresh.
  const refreshAll = () => {
    refresh();
    router.refresh();
  };

  return (
    <header className="sticky top-0 z-50 border-b border-[#1f2a3d] bg-[#0b0f17]/95 backdrop-blur">
      <div className="mx-auto flex max-w-[1600px] items-center justify-between gap-4 px-4 py-2.5">
        <div className="flex items-center gap-3">
          <div className="flex h-8 w-8 items-center justify-center rounded border border-[#2a3a55] bg-[#111827]">
            <span className="text-[10px] font-black tracking-tight text-sky-400">ESRD</span>
          </div>
          <div className="leading-tight">
            <div className="text-[13px] font-bold tracking-wide text-slate-100">
              European Strategic Resilience Dashboard
            </div>
            <div className="label">Early-Warning · Resilience · Trend Tracking</div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={refreshAll}
            title="Update everything in one go"
            className="flex items-center gap-1.5 rounded border border-[#2a3a55] bg-[#16233a] px-2.5 py-1.5 text-[12px] font-semibold text-slate-200 transition hover:border-sky-400 hover:bg-[#1d2f4d]"
          >
            <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M21 12a9 9 0 1 1-3-6.7" strokeLinecap="round" />
              <path d="M21 3v6h-6" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
            Update All
          </button>
          <nav className="flex flex-wrap items-center gap-1">
            {LINKS.map((l) => {
              const active = pathname === l.href;
              return (
                <Link
                  key={l.href}
                  href={l.href}
                  className={`rounded px-2.5 py-1.5 text-[12px] font-semibold transition ${
                    active
                      ? "bg-[#1d4ed8] text-white"
                      : "text-slate-400 hover:bg-[#16233a] hover:text-slate-100"
                  }`}
                >
                  {l.label}
                </Link>
              );
            })}
          </nav>
        </div>
      </div>
    </header>
  );
}
