"use client";

import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import type { BriefingData, ReportItem } from "@/lib/types";

export default function BriefingPage() {
  const [data, setData] = useState<BriefingData | null>(null);
  const [reports, setReports] = useState<ReportItem[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const load = async () => {
    try {
      setData(await api.getBriefing());
      setReports(await listReports());
    } catch (e) {
      setError(String(e));
    }
  };

  const listReports = async (): Promise<ReportItem[]> => {
    try {
      const r = await fetch(`${api.reportsListUrl()}`);
      return (await r.json()) as ReportItem[];
    } catch {
      return [];
    }
  };

  useEffect(() => {
    load();
  }, []);

  const generate = async (type: string) => {
    setBusy(true);
    try {
      const res = await api.createReport(type, "markdown");
      window.open(api.exportReportUrl(res.id, "markdown"), "_blank");
      setReports(await listReports());
    } catch (e) {
      alert(`Report generation failed: ${e}`);
    } finally {
      setBusy(false);
    }
  };

  const download = async (id: number, format: string) => {
    const url = api.exportReportUrl(id, format);
    const a = document.createElement("a");
    a.href = url;
    a.download = "";
    a.click();
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-lg font-bold tracking-wide">Intelligence Briefing Mode</h1>
          <p className="text-xs text-slate-500">
            Auto-generated printable report. Export as PDF, DOCX or Markdown.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <button className="btn" onClick={() => window.print()}>Print</button>
          <button className="btn" disabled={busy} onClick={() => generate("DAILY")}>Generate Daily</button>
          <button className="btn" disabled={busy} onClick={() => generate("WEEKLY")}>Generate Weekly</button>
          <button className="btn btn-primary" disabled={busy} onClick={() => generate("EXECUTIVE")}>Generate Executive</button>
        </div>
      </div>

      {error && <div className="panel border-red-500/40 p-4 text-sm text-red-400">{error}</div>}

      {data && (
        <div className="panel">
          <div className="panel-header">
            <span className="text-[12px] font-bold uppercase tracking-wider">
              Briefing — {data.title}
            </span>
            <span className="text-[10px] text-slate-500">Auto-generated · human-reviewed</span>
          </div>
          <div className="space-y-5 p-5">
            <Section title="Executive Summary" body={data.executive_summary} />
            {data.flashpoints?.length > 0 && (
              <div>
                <h3 className="text-[12px] font-bold uppercase tracking-wider text-red-400">Flashpoints</h3>
                <ul className="mt-1.5 space-y-1">
                  {data.flashpoints.map((f) => (
                    <li key={f.region} className="text-[13px] text-slate-300">
                      <span className="font-semibold text-red-300">{f.region}</span>
                      {" — "}{f.event_count} events; top:{" "}
                      {f.top_categories.map((c) => `${c.name} ${c.score}/10`).join(", ")}
                    </li>
                  ))}
                </ul>
              </div>
            )}
            <SectionList title="Major Changes" items={data.major_changes} color="#f97316" />
            <SectionList title="Fastest Rising Risks" items={data.rising_risks} color="#ef4444" />
            <SectionList title="Fastest Rising Resilience Indicators" items={data.rising_resilience} color="#22c55e" />
            <SectionList title="Watch List" items={data.watch_list} color="#eab308" />
            <Section title="Strategic Assessment" body={data.strategic_assessment} />
          </div>
        </div>
      )}

      <div className="panel">
        <div className="panel-header">
          <span className="text-[12px] font-bold uppercase tracking-wider">Generated Reports</span>
        </div>
        {reports.length === 0 ? (
          <div className="p-6 text-center text-sm text-slate-500">No reports generated yet.</div>
        ) : (
          <div className="divide-y divide-[#1a2334]">
            {reports.map((r) => (
              <div key={r.id} className="flex flex-wrap items-center justify-between gap-2 px-4 py-2">
                <div className="flex items-center gap-3">
                  <span className="rounded bg-[#1a2334] px-1.5 py-0.5 text-[10px] font-bold text-sky-400">
                    {r.report_type}
                  </span>
                  <span className="font-mono text-[11px] text-slate-500">{r.created_at}</span>
                </div>
                <div className="flex gap-1.5">
                  <button className="btn !px-2 !py-1 !text-[11px]" onClick={() => download(r.id, "pdf")}>PDF</button>
                  <button className="btn !px-2 !py-1 !text-[11px]" onClick={() => download(r.id, "docx")}>DOCX</button>
                  <button className="btn !px-2 !py-1 !text-[11px]" onClick={() => download(r.id, "markdown")}>MD</button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function Section({ title, body }: { title: string; body: string }) {
  return (
    <div>
      <h3 className="text-[12px] font-bold uppercase tracking-wider text-sky-400">{title}</h3>
      <p className="mt-1.5 text-[13px] leading-relaxed text-slate-300">{body}</p>
    </div>
  );
}

function SectionList({ title, items, color }: { title: string; items: string[]; color: string }) {
  return (
    <div>
      <h3 className="text-[12px] font-bold uppercase tracking-wider" style={{ color }}>
        {title}
      </h3>
      <ul className="mt-1.5 space-y-1">
        {items.map((it, i) => (
          <li key={i} className="flex gap-2 text-[13px] text-slate-300">
            <span style={{ color }}>▸</span>
            <span>{it}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}
