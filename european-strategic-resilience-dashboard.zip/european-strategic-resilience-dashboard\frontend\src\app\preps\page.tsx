"use client";

import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import { useRefresh } from "@/lib/RefreshContext";
import { STATUS_COLORS } from "@/lib/constants";
import type {
  ExecutiveSummary, HouseholdReadiness, Prep, PrepChatMessage, PrepInput,
  RunToStoreResult, Settings,
} from "@/lib/types";

const CATEGORIES = ["Water", "Food", "Power", "Medical", "Fuel", "Shelter", "Comms", "Other"];
const PRIORITIES = ["HIGH", "MEDIUM", "LOW"];

const STAGES = [
  { n: 1, title: "Stage 1 — Immediate Readiness", window: "0–14 days", goal: "Survive short disruptions without external assistance.", color: "#22c55e" },
  { n: 2, title: "Stage 2 — Resilience", window: "14–180 days", goal: "Function during prolonged shortages.", color: "#eab308" },
  { n: 3, title: "Stage 3 — Self-Reliance / Rebuilding", window: "180+ days", goal: "Reduce dependency on fragile systems.", color: "#38bdf8" },
] as const;

function readinessColor(v: number | null): string {
  if (v === null) return "#8494ab";
  return v >= 8 ? "#22c55e" : v >= 5 ? "#eab308" : "#ef4444";
}

export default function PrepsPage() {
  const { refreshKey } = useRefresh();
  const [preps, setPreps] = useState<Prep[]>([]);
  const [settings, setSettings] = useState<Settings | null>(null);
  const [summary, setSummary] = useState<ExecutiveSummary | null>(null);
  const [readiness, setReadiness] = useState<HouseholdReadiness | null>(null);
  const [hhSize, setHhSize] = useState<number>(2);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState<PrepInput>({
    name: "", category: "Water", stage: 1, quantity: 0, unit: "units", min_quantity: 0, priority: "MEDIUM", notes: "",
  });
  const [saving, setSaving] = useState(false);

  const [rts, setRts] = useState<RunToStoreResult | null>(null);
  const [rtsBusy, setRtsBusy] = useState(false);

  // Survivalist advisor chat
  const [chat, setChat] = useState<PrepChatMessage[]>([]);
  const [chatInput, setChatInput] = useState("");
  const [chatBusy, setChatBusy] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const [p, s, d, r] = await Promise.all([
        api.getPreps(),
        api.getSettings(),
        api.getDashboard(),
        api.getReadiness(),
      ]);
      setPreps(p);
      setSettings(s);
      setSummary(d.summary);
      setReadiness(r);
      setHhSize(r.household_size);
      setError(null);
    } catch (e) {
      setError(String(e));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [refreshKey]);

  // Lightweight reload: only preps + readiness. Used by quantity edits / delete /
  // household-size so the heavy dashboard fetch never blanks the list mid-interaction.
  const reloadPreps = async () => {
    try {
      const [p, r] = await Promise.all([api.getPreps(), api.getReadiness()]);
      setPreps(p);
      setReadiness(r);
    } catch (e) {
      setError(String(e));
    }
  };

  const submit = async () => {
    if (!form.name) return alert("Name required");
    setSaving(true);
    try {
      await api.createPrep(form);
      setForm({ name: "", category: "Water", stage: 1, quantity: 0, unit: "units", min_quantity: 0, priority: "MEDIUM", notes: "" });
      setShowForm(false);
      await load();
    } catch (e) {
      alert(String(e));
    } finally {
      setSaving(false);
    }
  };

  const sendChat = async () => {
    const text = chatInput.trim();
    if (!text || chatBusy) return;
    const next: PrepChatMessage[] = [...chat, { role: "user", content: text }];
    setChat(next);
    setChatInput("");
    setChatBusy(true);
    try {
      const res = await api.prepChat(next);
      setChat([...next, { role: "assistant", content: res.reply }]);
    } catch (e) {
      setChat([...next, { role: "assistant", content: `⚠ ${e}` }]);
    } finally {
      setChatBusy(false);
    }
  };

  const adjust = async (p: Prep, delta: number) => {
    const base = Number(p.quantity) || 0;
    const q = Math.max(0, Number((base + delta).toFixed(2)));
    try {
      await api.updatePrep(p.id, { quantity: q });
      await reloadPreps();
    } catch (e) {
      alert(String(e));
    }
  };

  // Type a quantity directly and save on blur / Enter.
  const setQuantity = async (p: Prep, value: string) => {
    const q = Math.max(0, Number(value) || 0);
    if (q === (Number(p.quantity) || 0)) return;
    try {
      await api.updatePrep(p.id, { quantity: q });
      await reloadPreps();
    } catch (e) {
      alert(String(e));
    }
  };

  const changeHouseholdSize = async (value: string) => {
    const size = Math.max(1, Math.min(20, Number(value) || 1));
    setHhSize(size);
    try {
      setReadiness(await api.setHouseholdSize(size));
    } catch (e) {
      alert(String(e));
    }
  };

  // Two-step inline delete so a stray click can't remove an entry.
  const [confirmDeleteId, setConfirmDeleteId] = useState<number | null>(null);
  const remove = async (p: Prep) => {
    if (confirmDeleteId !== p.id) {
      setConfirmDeleteId(p.id);
      return; // first click arms the confirmation
    }
    setConfirmDeleteId(null);
    try {
      await api.deletePrep(p.id);
      await reloadPreps();
    } catch (e) {
      alert(String(e));
    }
  };

  const runToStore = async (force: boolean) => {
    setRtsBusy(true);
    setRts(null);
    try {
      setRts(await api.runToStore(force));
      setReadiness(await api.getReadiness());  // refresh readiness after AI analysis
    } catch (e) {
      alert(String(e));
    } finally {
      setRtsBusy(false);
    }
  };

  const threshold = settings?.run_to_store_threshold ?? 7.0;
  const currentLevel = summary?.threat_score ?? rts?.current_level;
  const status = summary?.overall_status ?? rts?.status;
  const statusColor = status ? STATUS_COLORS[status as keyof typeof STATUS_COLORS] || "#8494ab" : "#8494ab";
  const reached = currentLevel !== undefined && currentLevel >= threshold;
  const belowMin = preps.filter((p) => p.quantity < p.min_quantity);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-lg font-bold tracking-wide">Preps — Preparedness Inventory</h1>
          <p className="text-xs text-slate-500">
            Your stockpile. When the alert level reaches your Run-to-Store threshold, the AI suggests what to top up.
          </p>
        </div>
        <button className="btn btn-primary" onClick={() => setShowForm((s) => !s)}>
          {showForm ? "Close" : "+ Add Item"}
        </button>
      </div>

      {/* Run to the Store panel */}
      <div className="panel">
        <div className="panel-header">
          <span className="text-[12px] font-bold uppercase tracking-wider">Run to the Store</span>
          <span className="text-[10px] text-slate-500">
            Threshold {threshold}/10 · {belowMin.length} item(s) below minimum
          </span>
        </div>
        <div className="flex flex-wrap items-center gap-4 p-4">
          <div className="rounded border bg-[#0d1420] px-4 py-3" style={{ borderColor: `${statusColor}55` }}>
            <div className="label">Current alert level</div>
            <div className="flex items-baseline gap-2">
              <span className="font-mono text-3xl font-black" style={{ color: statusColor }}>
                {currentLevel !== undefined ? currentLevel.toFixed(1) : "—"}
                <span className="text-sm text-slate-500">/10</span>
              </span>
              {status && (
                <span
                  className="badge"
                  style={{ color: statusColor, borderColor: `${statusColor}55`, background: `${statusColor}18` }}
                >
                  {status}
                </span>
              )}
            </div>
            {reached && (
              <div className="mt-1 text-[11px] font-semibold text-amber-400">⚠ Threshold reached</div>
            )}
          </div>
          <div className="rounded border border-[#1f2a3d] bg-[#0d1420] px-4 py-3">
            <div className="label">Threshold</div>
            <div className="font-mono text-3xl font-black">{threshold.toFixed(1)}</div>
          </div>
          <div className="rounded border border-[#1f2a3d] bg-[#0d1420] px-4 py-3">
            <div className="label">Persons in household</div>
            <input
              type="number"
              min={1}
              max={20}
              className="mt-1 w-20 text-center font-mono text-2xl font-black"
              value={hhSize}
              onChange={(e) => changeHouseholdSize(e.target.value)}
            />
            <div className="mt-1 text-[10px] text-slate-500">Scales consumable minimums</div>
          </div>
          <div className="flex flex-col gap-2">
            <button className="btn btn-primary" onClick={() => runToStore(true)} disabled={rtsBusy}>
              {rtsBusy ? "AI reviewing preps…" : "Ask AI what to top up"}
            </button>
            <p className="text-[11px] text-slate-500">
              {reached
                ? "Threshold reached — run the AI to get top-up suggestions."
                : "Runs automatically when level ≥ threshold. Force anytime with this button."}
            </p>
          </div>
        </div>
        {rts && (
          <div className="border-t border-[#1f2a3d] bg-[#0d1420] p-4">
            <div className="label mb-2">
              {rts.reached ? "Threshold reached — AI top-up suggestions" : "Below threshold — manual run"}
              {" · "}level {rts.current_level.toFixed(1)} vs {rts.threshold}
            </div>
            <pre className="max-h-[400px] overflow-auto whitespace-pre-wrap rounded border border-[#1f2a3d] bg-[#0b1220] p-3 text-[12px] leading-relaxed text-slate-300">
              {rts.suggestions || "No suggestions."}
            </pre>
          </div>
        )}
      </div>

      {/* Add form */}
      {showForm && (
        <div className="panel">
          <div className="panel-header"><span className="text-[12px] font-bold uppercase tracking-wider">Add Prep Item</span></div>
          <div className="grid grid-cols-1 gap-3 p-4 md:grid-cols-3">
            <div className="md:col-span-2">
              <label className="label">Name</label>
              <input className="mt-1 w-full" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="e.g. Tinned food" />
            </div>
            <div>
              <label className="label">Category</label>
              <select className="mt-1 w-full" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>
                {CATEGORIES.map((c) => <option key={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label className="label">Stage</label>
              <select className="mt-1 w-full" value={form.stage} onChange={(e) => setForm({ ...form, stage: Number(e.target.value) })}>
                {STAGES.map((s) => <option key={s.n} value={s.n}>{s.n} · {s.window}</option>)}
              </select>
            </div>
            <div>
              <label className="label">Quantity</label>
              <input type="number" className="mt-1 w-full" value={form.quantity} onChange={(e) => setForm({ ...form, quantity: Number(e.target.value) })} />
            </div>
            <div>
              <label className="label">Unit</label>
              <input className="mt-1 w-full" value={form.unit} onChange={(e) => setForm({ ...form, unit: e.target.value })} />
            </div>
            <div>
              <label className="label">Min quantity (restock below)</label>
              <input type="number" className="mt-1 w-full" value={form.min_quantity} onChange={(e) => setForm({ ...form, min_quantity: Number(e.target.value) })} />
            </div>
            <div>
              <label className="label">Priority</label>
              <select className="mt-1 w-full" value={form.priority} onChange={(e) => setForm({ ...form, priority: e.target.value })}>
                {PRIORITIES.map((c) => <option key={c}>{c}</option>)}
              </select>
            </div>
            <div className="md:col-span-3">
              <label className="label">Notes</label>
              <input className="mt-1 w-full" value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
            </div>
            <div className="md:col-span-3 flex justify-end gap-2">
              <button className="btn" onClick={() => setShowForm(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={submit} disabled={saving}>{saving ? "Saving…" : "Save"}</button>
            </div>
          </div>
        </div>
      )}

      {/* Inventory — organised as a 3-stage roadmap */}
      <div className="panel">
        <div className="panel-header">
          <span className="text-[12px] font-bold uppercase tracking-wider">Preparedness Roadmap</span>
          <span className="text-[10px] text-slate-500">
            14 days = stockpile · 14–180 = resilience · 180+ = production · {preps.length} items
          </span>
        </div>
        {error && <div className="p-4 text-sm text-red-400">{error}</div>}
        {loading ? (
          <div className="p-8 text-center text-sm text-slate-500">Loading…</div>
        ) : preps.length === 0 ? (
          <div className="p-8 text-center text-sm text-slate-500">No preps yet — add your first item.</div>
        ) : (
          <div className="divide-y divide-[#1f2a3d]">
            {STAGES.map((s) => {
              // Coerce missing/invalid stage to 1 so no entry is ever hidden.
              const items = preps.filter((p) => (p.stage || 1) === s.n);
              if (items.length === 0) return null;
              const stocked = items.filter((p) => p.quantity >= p.min_quantity && p.min_quantity > 0).length;
              const pct = Math.round((stocked / items.length) * 100);
              return (
                <div key={s.n}>
                  {/* Stage header */}
                  <div className="flex flex-wrap items-center justify-between gap-2 bg-[#0d1420] px-4 py-2.5">
                    <div className="flex items-center gap-2">
                      <span className="h-2.5 w-2.5 rounded-sm" style={{ background: s.color }} />
                      <span className="text-[12px] font-bold uppercase tracking-wider" style={{ color: s.color }}>
                        {s.title}
                      </span>
                      <span className="rounded bg-[#1a2334] px-1.5 py-0.5 text-[10px] text-slate-400">{s.window}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] text-slate-500">{stocked}/{items.length} stocked</span>
                      <div className="h-1.5 w-24 rounded-full bg-[#1a2334]">
                        <div className="h-full rounded-full" style={{ width: `${pct}%`, background: s.color }} />
                      </div>
                      <span className="font-mono text-[11px] font-bold" style={{ color: s.color }}>{pct}%</span>
                    </div>
                  </div>
                  <div className="px-4 pb-1 text-[11px] italic text-slate-500">{s.goal}</div>
                  {/* Items table */}
                  <div className="overflow-x-auto">
                    <table className="w-full text-[12px]">
                      <tbody>
                        {items.map((p) => {
                          const low = p.quantity < p.min_quantity;
                          return (
                            <tr key={p.id} className="border-t border-[#1a2334] hover:bg-[#141d2e]">
                              <td className="px-4 py-1.5 font-semibold text-slate-200">{p.name}</td>
                              <td className="px-2 py-1.5 text-slate-400">{p.category}</td>
                              <td className="px-2 py-1.5">
                                <div className="flex items-center gap-1">
                                  <button className="rounded bg-[#1a2334] px-1.5 text-slate-300 hover:bg-[#24324a]" onClick={() => adjust(p, -1)}>−</button>
                                  <input
                                    type="number"
                                    min={0}
                                    step="any"
                                    className={`w-16 text-center font-mono ${low ? "text-red-400" : "text-emerald-400"}`}
                                    defaultValue={p.quantity}
                                    key={`${p.id}-${p.quantity}`}
                                    onBlur={(e) => setQuantity(p, e.target.value)}
                                    onKeyDown={(e) => { if (e.key === "Enter") (e.target as HTMLInputElement).blur(); }}
                                  />
                                  <button className="rounded bg-[#1a2334] px-1.5 text-slate-300 hover:bg-[#24324a]" onClick={() => adjust(p, 1)}>+</button>
                                  <span className="text-[10px] text-slate-500">{p.unit}</span>
                                  {low && <span className="badge ml-1" style={{ color: "#ef4444", borderColor: "#ef444455" }}>LOW</span>}
                                </div>
                              </td>
                              <td className="px-2 py-1.5 text-slate-500">min {p.min_quantity}</td>
                              <td className="px-2 py-1.5">
                                <span className="badge" style={{ color: p.priority === "HIGH" ? "#ef4444" : p.priority === "MEDIUM" ? "#eab308" : "#94a3b8", borderColor: "#2a3a55" }}>{p.priority}</span>
                              </td>
                              <td className="px-4 py-1.5 text-right">
                                {confirmDeleteId === p.id ? (
                                  <span className="inline-flex items-center gap-1">
                                    <button
                                      className="rounded bg-red-600 px-1.5 py-0.5 text-[10px] font-bold text-white"
                                      onClick={() => remove(p)}
                                    >
                                      Confirm delete
                                    </button>
                                    <button
                                      className="text-[11px] text-slate-400 hover:underline"
                                      onClick={() => setConfirmDeleteId(null)}
                                    >
                                      Cancel
                                    </button>
                                  </span>
                                ) : (
                                  <button
                                    className="text-[11px] text-red-400 hover:underline"
                                    onClick={() => remove(p)}
                                  >
                                    Delete
                                  </button>
                                )}
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Household Readiness */}
      <div className="panel">
        <div className="panel-header">
          <span className="text-[12px] font-bold uppercase tracking-wider">Household Readiness</span>
          <span className="text-[10px] text-slate-500">
            {readiness ? `for ${readiness.household_size} person(s) · updated after AI analysis` : "loading…"}
          </span>
        </div>
        {readiness ? (
          <div className="flex flex-wrap items-stretch gap-4 p-4">
            <div className="rounded border bg-[#0d1420] px-5 py-4 text-center" style={{ borderColor: `${readinessColor(readiness.household_readiness)}55` }}>
              <div className="label">Overall readiness</div>
              <div className="font-mono text-4xl font-black" style={{ color: readinessColor(readiness.household_readiness) }}>
                {readiness.household_readiness ?? "—"}
                <span className="text-sm text-slate-500">/10</span>
              </div>
            </div>
            <div className="grid flex-1 grid-cols-1 gap-3 sm:grid-cols-3">
              {[
                { key: "economic" as const, label: "Economic", val: readiness.economic },
                { key: "infrastructure" as const, label: "Infrastructure", val: readiness.infrastructure },
                { key: "threat_environment" as const, label: "Threat Environment", val: readiness.threat_environment },
              ].map((d) => (
                <div key={d.key} className="rounded border border-[#1f2a3d] bg-[#0d1420] px-3 py-3">
                  <div className="text-[11px] uppercase tracking-wide text-slate-400">{d.label}</div>
                  <div className="font-mono text-2xl font-black" style={{ color: readinessColor(d.val) }}>
                    {d.val ?? "—"}<span className="text-xs text-slate-500">/10</span>
                  </div>
                  <div className="mt-2 h-1.5 w-full rounded-full bg-[#1a2334]">
                    <div
                      className="h-full rounded-full transition-all"
                      style={{ width: `${((d.val ?? 0) / 10) * 100}%`, background: readinessColor(d.val) }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="p-6 text-center text-sm text-slate-500">Loading readiness…</div>
        )}
      </div>

      {/* Survivalist Advisor chat */}
      <div className="panel">
        <div className="panel-header">
          <span className="text-[12px] font-bold uppercase tracking-wider">Survivalist Advisor</span>
          <span className="text-[10px] text-slate-500">Seasoned prepper · knows your inventory · rebuilding after catastrophe</span>
        </div>
        <div className="max-h-[420px] space-y-3 overflow-y-auto p-4">
          {chat.length === 0 && (
            <div className="text-[12px] text-slate-500">
              Ask for a prioritised shopping list, what to stock first, how to store water, or how to rebuild after a long crisis.
              The advisor sees your current inventory and readiness.
            </div>
          )}
          {chat.map((m, i) => (
            <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
              <div
                className={`max-w-[85%] whitespace-pre-wrap rounded-lg px-3 py-2 text-[12px] leading-relaxed ${
                  m.role === "user" ? "bg-sky-700 text-white" : "bg-[#141d2e] text-slate-200"
                }`}
              >
                {m.content}
              </div>
            </div>
          ))}
          {chatBusy && (
            <div className="flex justify-start">
              <div className="rounded-lg bg-[#141d2e] px-3 py-2 text-[12px] text-sky-400">
                <span className="mr-2 inline-block h-3 w-3 animate-spin rounded-full border-2 border-sky-400 border-t-transparent align-[-2px]" />
                Advisor is thinking…
              </div>
            </div>
          )}
        </div>
        <div className="flex gap-2 border-t border-[#1f2a3d] p-3">
          <input
            className="flex-1"
            placeholder="e.g. What should I buy first with €100?"
            value={chatInput}
            onChange={(e) => setChatInput(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter") sendChat(); }}
            disabled={chatBusy}
          />
          <button className="btn btn-primary" onClick={sendChat} disabled={chatBusy || !chatInput.trim()}>
            {chatBusy ? "…" : "Ask"}
          </button>
        </div>
      </div>
    </div>
  );
}
