import type {
  AICapabilityResponse,
  AIHealth,
  AIProposal,
  BriefingData,
  Category,
  ConfidenceLevel,
  DashboardData,
  EventAIOut,
  EventCreate,
  EventCreateMinimal,
  EventFilters,
  EventItem,
  HouseholdReadiness,
  IngestAllResult,
  CyberAttack,
  CyberScrapeResult,
  CyberSource,
  Outage,
  OutageLocations,
  OutageScrapeResult,
  OutageSource,
  Prep,
  PrepChatMessage,
  PrepChatOut,
  PrepInput,
  Region,
  RunToStoreResult,
  ScrapeRunResult,
  ScrapeSource,
  ScrapedItem,
  Settings,
  SettingsUpdate,
  Source,
  SourceType,
  CascadeOut,
  WatchlistOut,
} from "./types";
import { API_URL } from "./constants";

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${API_URL}${path}`, {
    headers: { "Content-Type": "application/json" },
    ...init,
    cache: "no-store",
  });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`${res.status} ${res.statusText}: ${text}`);
  }
  const ct = res.headers.get("content-type") || "";
  if (ct.includes("application/json")) return res.json();
  return (await res.text()) as unknown as T;
}

export const api = {
  // Dashboard
  getDashboard: () => request<DashboardData>("/dashboard"),

  // Meta
  getCategories: () => request<Category[]>("/meta/categories"),
  getRegions: () => request<Region[]>("/meta/regions"),
  getConfidenceLevels: () => request<ConfidenceLevel[]>("/meta/confidence-levels"),
  getSourceTypes: () => request<SourceType[]>("/meta/source-types"),

  // Events
  getEvents: (f: EventFilters = {}) => {
    const params = new URLSearchParams();
    Object.entries(f).forEach(([k, v]) => {
      if (v !== undefined && v !== null && v !== "") params.append(k, String(v));
    });
    const qs = params.toString();
    return request<EventItem[]>(`/events${qs ? `?${qs}` : ""}`);
  },
  getEvent: (id: number) => request<EventItem>(`/events/${id}`),
  createEvent: (payload: EventCreate) =>
    request<EventItem>("/events", {
      method: "POST",
      body: JSON.stringify(payload),
    }),
  createEventAI: (payload: EventCreateMinimal) =>
    request<EventAIOut>("/events/ai", {
      method: "POST",
      body: JSON.stringify(payload),
    }),
  deleteEvent: (id: number) =>
    request<void>(`/events/${id}`, { method: "DELETE" }),

  // Sources
  getSources: () => request<Source[]>("/meta/sources"),

  // AI
  aiHealth: () => request<AIHealth>("/ai/health"),
  aiRun: (capability: string, context?: string) =>
    request<AICapabilityResponse>("/ai/run", {
      method: "POST",
      body: JSON.stringify({ capability, context }),
    }),
  generateWatchlist: () => request<WatchlistOut>("/ai/watchlist", { method: "POST" }),
  generateCascade: () => request<CascadeOut>("/ai/cascade", { method: "POST" }),
  getProposals: (status?: string) =>
    request<AIProposal[]>(`/ai/proposals${status ? `?status=${status}` : ""}`),
  decideProposal: (id: number, decision: "APPROVED" | "REJECTED") =>
    request<AIProposal>(`/ai/proposals/${id}/decide`, {
      method: "POST",
      body: JSON.stringify({ decision }),
    }),

  // Reports
  getBriefing: () => request<BriefingData>("/reports/briefing"),
  listReports: () => request<{ id: number; report_type: string; created_at: string; format: string; content_json: string }[]>("/reports"),
  reportsListUrl: () => `${API_URL}/reports`,
  createReport: (report_type: string, format = "markdown") =>
    request<{ id: number }>("/reports", {
      method: "POST",
      body: JSON.stringify({ report_type, format }),
    }),
  exportReportUrl: (id: number, format: string) =>
    `${API_URL}/reports/export/${id}?format=${format}`,

  // Settings
  getSettings: () => request<Settings>("/settings"),
  updateSettings: (payload: SettingsUpdate) =>
    request<Settings>("/settings", {
      method: "POST",
      body: JSON.stringify(payload),
    }),

  // Preps (owner's inventory)
  getPreps: () => request<Prep[]>("/preps"),
  createPrep: (p: PrepInput) =>
    request<Prep>("/preps", { method: "POST", body: JSON.stringify(p) }),
  updatePrep: (id: number, p: Partial<PrepInput>) =>
    request<Prep>(`/preps/${id}`, { method: "PUT", body: JSON.stringify(p) }),
  deletePrep: (id: number) =>
    request<void>(`/preps/${id}`, { method: "DELETE" }),
  runToStore: (force = false) =>
    request<RunToStoreResult>("/preps/run-to-store", {
      method: "POST",
      body: JSON.stringify({ force }),
    }),
  getReadiness: () => request<HouseholdReadiness>("/preps/readiness"),
  setHouseholdSize: (size: number) =>
    request<HouseholdReadiness>("/preps/household-size", {
      method: "POST",
      body: JSON.stringify({ size }),
    }),
  prepChat: (messages: PrepChatMessage[]) =>
    request<PrepChatOut>("/preps/chat", {
      method: "POST",
      body: JSON.stringify({ messages }),
    }),

  // OSINT scraping
  getScrapeSources: () => request<ScrapeSource[]>("/scrape/sources"),
  createScrapeSource: (s: { name: string; url: string; kind: string; tier?: string }) =>
    request<ScrapeSource>("/scrape/sources", { method: "POST", body: JSON.stringify(s) }),
  deleteScrapeSource: (id: number) =>
    request<void>(`/scrape/sources/${id}`, { method: "DELETE" }),
  runScrape: () => request<ScrapeRunResult>("/scrape/run", { method: "POST" }),
  getScrapedItems: (uningestedOnly = false, topic?: string) => {
    const params = new URLSearchParams();
    if (uningestedOnly) params.append("uningested_only", "true");
    if (topic) params.append("topic", topic);
    const qs = params.toString();
    return request<ScrapedItem[]>(`/scrape/items${qs ? `?${qs}` : ""}`);
  },
  ingestItem: (id: number) =>
    request<{ ingested: boolean; event_id: number; entry_number: number; ai_confidence: string; ai_categories: string[] }>(
      `/scrape/items/${id}/ingest`,
      { method: "POST" }
    ),
  ingestAll: () => request<IngestAllResult>("/scrape/items/ingest-all", { method: "POST" }),

  // Power outages
  getOutageSources: (country?: string) =>
    request<OutageSource[]>(`/outages/sources${country ? `?country=${encodeURIComponent(country)}` : ""}`),
  createOutageSource: (s: { name: string; country: string; region?: string; city?: string; url: string; kind?: string }) =>
    request<OutageSource>("/outages/sources", { method: "POST", body: JSON.stringify(s) }),
  deleteOutageSource: (id: number) =>
    request<void>(`/outages/sources/${id}`, { method: "DELETE" }),
  getOutageLocations: () => request<OutageLocations>("/outages/sources/locations"),
  scrapeOutages: (sel: { country?: string; region?: string; city?: string }) =>
    request<OutageScrapeResult>("/outages/scrape", { method: "POST", body: JSON.stringify(sel) }),
  getOutages: (f: { country?: string; region?: string; city?: string; outage_type?: string } = {}) => {
    const params = new URLSearchParams();
    Object.entries(f).forEach(([k, v]) => { if (v) params.append(k, String(v)); });
    const qs = params.toString();
    return request<Outage[]>(`/outages${qs ? `?${qs}` : ""}`);
  },
  ingestOutage: (id: number) =>
    request<{ ingested: boolean; event_id: number; entry_number: number; ai_confidence: string; ai_categories: string[] }>(
      `/outages/${id}/ingest`, { method: "POST" }),

  // Cyber attacks
  getCyberSources: () => request<CyberSource[]>("/cyber/sources"),
  createCyberSource: (s: { name: string; url: string; kind?: string }) =>
    request<CyberSource>("/cyber/sources", { method: "POST", body: JSON.stringify(s) }),
  deleteCyberSource: (id: number) => request<void>(`/cyber/sources/${id}`, { method: "DELETE" }),
  scrapeCyber: () => request<CyberScrapeResult>("/cyber/scrape", { method: "POST" }),
  getCyberAttacks: (f: { severity?: string } = {}) => {
    const qs = f.severity ? `?severity=${f.severity}` : "";
    return request<CyberAttack[]>(`/cyber${qs}`);
  },
  ingestCyber: (id: number) =>
    request<{ event_id: number; entry_number: number; ai_confidence: string; ai_categories: string[] }>(
      `/cyber/${id}/ingest`, { method: "POST" }),

  // Attachments
  uploadAttachment: async (eventId: number, file: File) => {
    const fd = new FormData();
    fd.append("file", file);
    const res = await fetch(`${API_URL}/events/${eventId}/attachments`, {
      method: "POST",
      body: fd,
      cache: "no-store",
    });
    if (!res.ok) {
      const t = await res.text().catch(() => "");
      throw new Error(`${res.status}: ${t}`);
    }
    return res.json();
  },
  deleteAttachment: (eventId: number, attId: number) =>
    request<void>(`/events/${eventId}/attachments/${attId}`, { method: "DELETE" }),
};
