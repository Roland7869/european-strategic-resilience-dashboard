"""Cyber attacks: manage sources, scrape + classify severity/type, list, auto-ingest."""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.database import get_db
from app.models import CyberAttack, CyberAttackSource
from app.schemas import (
    CyberAttackOut, CyberScrapeResult, CyberSourceCreate, CyberSourceOut
)
from app.services.cyber_scraper import scrape_cyber
from app.services.scraper import SSRFError, validate_public_url

router = APIRouter(prefix="/cyber", tags=["cyber"])


@router.get("/sources", response_model=list[CyberSourceOut])
async def list_sources(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(CyberAttackSource).order_by(CyberAttackSource.name))
    return list(result.scalars().all())


@router.post("/sources", response_model=CyberSourceOut, status_code=201)
async def create_source(payload: CyberSourceCreate, db: AsyncSession = Depends(get_db)):
    try:
        validate_public_url(payload.url)
    except SSRFError as e:
        raise HTTPException(status_code=400, detail=f"Invalid URL: {e}")
    if payload.kind not in ("rss", "html"):
        raise HTTPException(status_code=400, detail="kind must be 'rss' or 'html'")
    src = CyberAttackSource(**payload.model_dump())
    db.add(src)
    await db.commit()
    await db.refresh(src)
    return src


@router.delete("/sources/{source_id}", status_code=204)
async def delete_source(source_id: int, db: AsyncSession = Depends(get_db)):
    src = await db.get(CyberAttackSource, source_id)
    if not src:
        raise HTTPException(status_code=404, detail="Source not found")
    await db.delete(src)
    await db.commit()


async def _ingest_attack(db: AsyncSession, attack_id: int) -> dict:
    from datetime import date as date_cls
    from app.api.events import create_event_with_ai
    from app.schemas import EventCreateMinimal

    result = await db.execute(
        select(CyberAttack).options(selectinload(CyberAttack.source)).where(CyberAttack.id == attack_id)
    )
    attack = result.scalar_one_or_none()
    if not attack:
        raise HTTPException(status_code=404, detail="Attack not found")
    if attack.ingested:
        raise HTTPException(status_code=400, detail="Already ingested")

    summary = f"[{attack.severity}/{attack.attack_type}] {attack.title}."
    if attack.summary:
        summary += f" {attack.summary}"
    if attack.url:
        summary += f"\nSource URL: {attack.url}"

    payload = EventCreateMinimal(
        event_date=date_cls.today(),
        title=f"Cyber: {attack.title[:80]}",
        summary=summary,
        source_name=attack.source.name if attack.source else "Cyber Threat Feed",
        min_confidence="MEDIUM",
    )
    ev_out = await create_event_with_ai(payload, db)
    attack.ingested = True
    attack.ingested_event_id = ev_out.event.id
    await db.commit()
    return {"event_id": ev_out.event.id, "entry_number": ev_out.event.entry_number,
            "ai_confidence": ev_out.ai_confidence, "ai_categories": ev_out.ai_categories}


async def _recent_attack_ids(db: AsyncSession, limit: int = 8) -> list[int]:
    result = await db.execute(
        select(CyberAttack.id)
        .where(CyberAttack.ingested == False)  # noqa: E712
        .order_by(CyberAttack.scraped_at.desc())
        .limit(limit)
    )
    return [row[0] for row in result.all()]


@router.post("/scrape", response_model=CyberScrapeResult)
async def scrape(db: AsyncSession = Depends(get_db)):
    """Scrape all enabled cyber sources, classify, and auto-ingest new items (bounded)."""
    result = await db.execute(select(CyberAttackSource).where(CyberAttackSource.enabled == True))  # noqa: E712
    sources = list(result.scalars().all())
    if not sources:
        return CyberScrapeResult(sources=0, new_attacks=0, errors=["No cyber sources configured"])
    out = await scrape_cyber(sources, db)

    AUTO_INGEST_CAP = 8
    ids = await _recent_attack_ids(db, limit=AUTO_INGEST_CAP)
    ingested = 0
    ingest_errors: list[str] = []
    for aid in ids:
        try:
            await _ingest_attack(db, aid)
            ingested += 1
        except Exception as e:  # noqa: BLE001
            ingest_errors.append(f"ingest #{aid}: {e}")
            await db.rollback()
    out["errors"] = list(out.get("errors", [])) + ingest_errors
    return CyberScrapeResult(
        sources=out["sources"], new_attacks=out["new_attacks"],
        errors=out["errors"], ingested=ingested,
    )


@router.get("", response_model=list[CyberAttackOut])
async def list_attacks(db: AsyncSession = Depends(get_db), severity: str | None = None,
                       ingested_only: bool = False, limit: int = 100):
    q = select(CyberAttack).order_by(CyberAttack.scraped_at.desc()).limit(limit)
    if severity and severity in ("CRITICAL", "HIGH", "MEDIUM", "LOW"):
        q = q.where(CyberAttack.severity == severity)
    if ingested_only:
        q = q.where(CyberAttack.ingested == True)  # noqa: E712
    result = await db.execute(q)
    return list(result.scalars().all())


@router.post("/{attack_id}/ingest")
async def ingest(attack_id: int, db: AsyncSession = Depends(get_db)):
    return await _ingest_attack(db, attack_id)
