"use client";

import { useCallback, useEffect, useState } from "react";
import { api } from "@/lib/api";
import { useRefresh } from "@/lib/RefreshContext";
import type { PreMortem, StressState } from "@/lib/types";

const THEATERS = [
  "Global Multi-Theatre",
  "Middle East / Strait of Hormuz",
  "Ukraine & Eastern Flank",
  "European Grid & Cyber",
];

const SEV: Record<string, string> = {
  GREEN: "#22c55e",
  YELLOW: "#eab308",
  ORANGE: "#f97316",
  RED: "#ef4444",
  BLACK: "#000000",
};

function sevColor(c: string): string {
  return SEV[(c || "").toUpperCase()] || "#94a3b8";
}

function severityBadge(c: string) {
  const key = (c || "").toUpperCase();
  const color = sevColor(key);
  const isBlack = key === "BLACK";
  return (
    <span
      className="badge"
      style={{
        color: isBlack ? "#ffffff" : color,
        borderColor: isBlack ? "#ffffff55" : `${color}55`,
        background: isBlack ? "#000000" : `${color}18`,
      }}
    >
      {isBlack ? "BLACK · MAX" : key}
    </span>
  );
}

export default function StressPage() {
  const { refreshKey } = useRefresh();
  const [state, setState] = useState<StressState | null>(null);
  const [theater, setTheater] = useState(THEATERS[0]);
  const [busy, setBusy] = useState<"run" | "pm" | null>(null);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      setState(await api.getStressState());
      setError(null);
    } catch (e) {
      setError(String(e));
    }
  }, []);

  useEffect(() => {
    load();
  }, [refreshKey, load]);

  const runTest = async () => {
    setBusy("run");
    setError(null);
    try {
      await api.runStressTest(theater);
      await load();
    } catch (e) {
      setError(String(e));
    } finally {
      setBusy(null);
    }
  };

  const runPostMortem = async () => {
    setBusy("pm");
    setError(null);
    try {
      await api.runPostMortem();
      await load();
    } catch (e) {
      setError(String(e));
    } finally {
      setBusy(null);
    }
  };

  const togglePin = async (id: number, pinned: boolean) => {
    try {
      await api.pinRule(id, pinned);
      await load();
    } catch (e) {
      alert(String(e));
    }
  };

  const removeRule = async (id: number) => {
    if (!confirm("Delete this learned rule?")) return;
    try {
      await api.deleteRule(id);
      await load();
    } catch (e) {
      alert(String(e));
    }
  };

  const snap = state?.snapshot;
  const rules = state?.rules ?? [];
  const latestAudit = state?.audits?.[0];
  const hasSnapshot = !!snap;

  return (
    <div className="space-y-4">
      {/* Control bar */}
      <div className="panel">
        <div className="flex flex-wrap items-center gap-3 p-4">
          <div>
            <label className="label">Theater</label>
            <select
              className="mt-1 w-64"
              value={theater}
              onChange={(e) => setTheater(e.target.value)}
            >
              {THEATERS.map((t) => <option key={t}>{t}</option>)}
            </select>
          </div>
          <div className="flex flex-col gap-2 pt-4">
            <button className="btn btn-primary" onClick={runTest} disabled={busy !== null}>
              {busy === "run" ? "Running stress test…" : "Run 7-Day Stress Test"}
            </button>
            <button
              className="btn"
              onClick={runPostMortem}
              disabled={busy !== null || !hasSnapshot}
              title={hasSnapshot ? "Grade the previous snapshot against reality" : "Run a stress test first"}
            >
              {busy === "pm" ? "Running post-mortem…" : "Run Weekly Post-Mortem"}
            </button>
          </div>
          <div className="ml-auto pt-4">
            <span
              className="badge"
              style={{ color: "#38bdf8", borderColor: "#38bdf855", background: "#38bdf818" }}
            >
              Engine {state?.prompt_version ?? "v1.0"} · {rules.length} Learned Rule{rules.length === 1 ? "" : "s"}
            </span>
          </div>
        </div>
        {error && (
          <div className="border-t border-[#1f2a3d] px-4 py-2 text-[12px] text-red-400">
            {error}
            <span className="ml-2 text-slate-500">Ensure LM Studio is running on port 1234.</span>
          </div>
        )}
      </div>

      {!snap && !busy && (
        <div className="panel p-10 text-center text-sm text-slate-500">
          No stress test yet. Choose a theater and click{" "}
          <span className="text-slate-300">Run 7-Day Stress Test</span> to model rational-actor
          incentives, pre-mortem shocks and falsifiable tripwires.
        </div>
      )}

      {busy && !snap && (
        <div className="panel flex items-center gap-3 p-6 text-sm text-slate-400">
          <span className="inline-block h-4 w-4 animate-spin rounded-full border-2 border-sky-400 border-t-transparent" />
          Modelling actor payoffs, constraints and red-line collisions…
        </div>
      )}

      {snap && (
        <>
          {/* Snapshot header */}
          <div className="flex flex-wrap items-center justify-between gap-2 px-1">
            <div className="text-[12px] text-slate-400">
              <span className="label mr-2">Latest run</span>
              {snap.theater} · {new Date(snap.created_at).toLocaleString()}
            </div>
            <div className="text-[11px] text-slate-500">
              threat {(snap.input_state?.threat as number)?.toFixed?.(1) ?? "—"} · resilience{" "}
              {(snap.input_state?.resilience as number)?.toFixed?.(1) ?? "—"} · SFI{" "}
              {(snap.input_state?.sfi as number)?.toFixed?.(1) ?? "—"}
            </div>
          </div>

          {/* Panel 1 — Actor Incentive Matrix */}
          <div className="panel">
            <div className="panel-header">
              <span className="text-[12px] font-bold uppercase tracking-wider">Panel 1 · Actor Incentive Matrix</span>
              <span className="text-[10px] text-slate-500">7-day rational-actor model</span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-[12px]">
                <thead>
                  <tr className="border-b border-[#1f2a3d]">
                    <th className="label px-3 py-2 text-left">Actor</th>
                    <th className="label px-3 py-2 text-left">7-Day Goal</th>
                    <th className="label px-3 py-2 text-left">Constraint / Fear</th>
                    <th className="label px-3 py-2 text-left">Rational Next Move</th>
                    <th className="label px-3 py-2 text-left">Miscalculation Risk</th>
                  </tr>
                </thead>
                <tbody>
                  {snap.actor_matrix.map((a, i) => (
                    <tr key={i} className="border-t border-[#1a2334] hover:bg-[#141d2e]">
                      <td className="px-3 py-2 font-semibold text-slate-100">{a.actor}</td>
                      <td className="px-3 py-2 text-slate-300">{a.primaryGoal7d}</td>
                      <td className="px-3 py-2 text-slate-400">{a.biggestConstraint}</td>
                      <td className="px-3 py-2 text-slate-300">{a.rationalNextMove}</td>
                      <td className="px-3 py-2 text-slate-400">{a.miscalculationRisk}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Panel 2 — Pre-Mortem cards */}
          <div className="panel">
            <div className="panel-header">
              <span className="text-[12px] font-bold uppercase tracking-wider">Panel 2 · 7-Day What-If Pre-Mortem</span>
              <span className="text-[10px] text-slate-500">conditional shocks · not forecasts</span>
            </div>
            <div className="grid grid-cols-1 gap-3 p-4 md:grid-cols-3">
              {snap.pre_mortem.map((p, i) => (
                <PreMortemCard key={i} p={p} />
              ))}
            </div>
          </div>

          {/* Panel 3 — Tripwires */}
          <div className="panel">
            <div className="panel-header">
              <span className="text-[12px] font-bold uppercase tracking-wider">Panel 3 · Falsifiable Watchlist (Tripwires)</span>
              <span className="text-[10px] text-slate-500">escalation vs de-escalation</span>
            </div>
            <div className="divide-y divide-[#1a2334]">
              {snap.tripwires.map((t, i) => (
                <div key={i} className="grid grid-cols-1 gap-3 px-4 py-3 md:grid-cols-3">
                  <div className="text-[12px] font-semibold text-slate-200">{t.indicator}</div>
                  <div className="flex gap-2 text-[12px]">
                    <span className="badge" style={{ color: "#ef4444", borderColor: "#ef444455", background: "#ef444418" }}>▲ ESC</span>
                    <span className="text-slate-300">{t.escalationSignal}</span>
                  </div>
                  <div className="flex gap-2 text-[12px]">
                    <span className="badge" style={{ color: "#22c55e", borderColor: "#22c55e55", background: "#22c55e18" }}>▼ DE-ESC</span>
                    <span className="text-slate-300">{t.deescalationSignal}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Panel 4 — Self-Calibration */}
          <div className="panel">
            <div className="panel-header">
              <span className="text-[12px] font-bold uppercase tracking-wider">Panel 4 · Self-Calibration &amp; Post-Mortem</span>
              <span className="text-[10px] text-slate-500">you stay in control of what the AI learns</span>
            </div>
            <div className="p-4">
              {/* Scorecard */}
              {latestAudit ? (
                <div className="mb-4 rounded border border-[#1f2a3d] bg-[#0d1420] p-3">
                  <div className="label mb-2">
                    Latest Retrospective Scorecard · {latestAudit.prompt_version} ·{" "}
                    {new Date(latestAudit.created_at).toLocaleDateString()}
                  </div>
                  <div className="flex flex-wrap gap-4">
                    <Metric label="Hits" value={latestAudit.hits} color="#22c55e" />
                    <Metric label="False Alarms" value={latestAudit.false_alarms} color="#eab308" />
                    <Metric label="Blind Spots" value={latestAudit.blind_spots} color="#ef4444" />
                    <Metric label="Timing Errors" value={latestAudit.timing_errors} color="#f97316" />
                  </div>
                  {latestAudit.summary && (
                    <p className="mt-2 text-[12px] leading-relaxed text-slate-400">{latestAudit.summary}</p>
                  )}
                </div>
              ) : (
                <div className="mb-4 text-[12px] text-slate-500">
                  No post-mortem yet — run one after a week of data to calibrate the engine.
                </div>
              )}

              {/* Learned heuristics */}
              <div className="label mb-2">Learned Heuristics ({rules.length}/{10})</div>
              {rules.length === 0 ? (
                <div className="text-[12px] text-slate-500">No learned rules yet.</div>
              ) : (
                <div className="space-y-2">
                  {rules.map((r) => (
                    <div key={r.id} className="flex items-start justify-between gap-3 rounded border border-[#1f2a3d] bg-[#0d1420] px-3 py-2">
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          {r.pinned && (
                            <span className="badge" style={{ color: "#38bdf8", borderColor: "#38bdf855" }}>PINNED</span>
                          )}
                          <span className="text-[12px] text-slate-200">{r.rule_text}</span>
                        </div>
                        <div className="mt-0.5 text-[10px] text-slate-500">
                          added {r.added_date}
                          {r.source_audit_summary ? ` · ${r.source_audit_summary}` : ""}
                        </div>
                      </div>
                      <div className="flex shrink-0 gap-1.5">
                        <button
                          className="btn !px-2 !py-1 !text-[11px]"
                          onClick={() => togglePin(r.id, !r.pinned)}
                          title={r.pinned ? "Unpin" : "Pin (protected from pruning)"}
                        >
                          {r.pinned ? "Unpin" : "Pin"}
                        </button>
                        <button
                          className="btn !px-2 !py-1 !text-[11px] !text-red-400"
                          onClick={() => removeRule(r.id)}
                        >
                          Delete
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
}

function PreMortemCard({ p }: { p: PreMortem }) {
  const color = sevColor(p.severityColor);
  const isBlack = (p.severityColor || "").toUpperCase() === "BLACK";
  return (
    <div
      className="rounded border bg-[#0d1420] p-3"
      style={{ borderColor: isBlack ? "#ffffff33" : `${color}55` }}
    >
      <div className="flex items-start justify-between gap-2">
        <div className="text-[13px] font-bold text-slate-100">{p.title}</div>
        {severityBadge(p.severityColor)}
      </div>
      <div className="mt-2 space-y-2 text-[12px]">
        <Row label="Trigger" text={p.trigger} />
        <Row label="72h Domino Chain" text={p.dominoChain72h} />
        <div>
          <div className="label mb-0.5">Prep Gap Warning</div>
          <span
            className="inline-flex items-center gap-1 rounded px-1.5 py-0.5 text-[11px] font-semibold"
            style={{ color: "#eab308", background: "#eab30818", border: "1px solid #eab30855" }}
            title="Cross-reference: Preps tab"
          >
            ⚠ {p.prepGapWarning}
          </span>
        </div>
      </div>
    </div>
  );
}

function Row({ label, text }: { label: string; text: string }) {
  return (
    <div>
      <div className="label mb-0.5">{label}</div>
      <div className="text-slate-300">{text}</div>
    </div>
  );
}

function Metric({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <div className="text-center">
      <div className="font-mono text-2xl font-black" style={{ color }}>{value}</div>
      <div className="text-[10px] uppercase tracking-wide text-slate-500">{label}</div>
    </div>
  );
}
