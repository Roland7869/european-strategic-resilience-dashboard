"use client";

import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import type { AIHealth, AIProposal } from "@/lib/types";
import { AI_CAPABILITIES } from "@/lib/constants";

export default function AssistantPage() {
  const [health, setHealth] = useState<AIHealth | null>(null);
  const [capability, setCapability] = useState<string>("summarize");
  const [context, setContext] = useState("");
  const [output, setOutput] = useState("");
  const [proposals, setProposals] = useState<AIProposal[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const refresh = async () => {
    try {
      setHealth(await api.aiHealth());
      setProposals(await api.getProposals());
    } catch (e) {
      setError(String(e));
    }
  };

  useEffect(() => {
    refresh();
  }, []);

  const run = async () => {
    setBusy(true);
    setError(null);
    setOutput("");
    try {
      const res = await api.aiRun(capability, context || undefined);
      setOutput(res.raw);
      if (res.proposals?.length) {
        setProposals(await api.getProposals());
      }
    } catch (e) {
      setError(String(e));
    } finally {
      setBusy(false);
    }
  };

  const [runAllBusy, setRunAllBusy] = useState(false);
  const [runAllLog, setRunAllLog] = useState<string[]>([]);

  // Run every capability one after another, collecting each output.
  const runAll = async () => {
    setRunAllBusy(true);
    setError(null);
    setOutput("");
    const log: string[] = [];
    setRunAllLog(["Starting…"]);
    try {
      const caps: { key: string; label: string }[] = [...AI_CAPABILITIES];
      const sections: string[] = [];
      for (const c of caps) {
        setRunAllLog([...log, `Running: ${c.label}…`]);
        log.push(`Running: ${c.label}`);
        try {
          const res = await api.aiRun(c.key, context || undefined);
          sections.push(`## ${c.label}\n\n${res.raw}`);
          log.push(`✓ ${c.label}`);
        } catch (e) {
          sections.push(`## ${c.label}\n\n_(failed: ${e})_`);
          log.push(`✗ ${c.label} — ${e}`);
        }
        setRunAllLog([...log]);
      }
      setOutput(sections.join("\n\n---\n\n"));
      setProposals(await api.getProposals());
    } finally {
      setRunAllBusy(false);
      setRunAllLog([...log, "Done."]);
    }
  };

  const decide = async (id: number, decision: "APPROVED" | "REJECTED") => {
    try {
      await api.decideProposal(id, decision);
      setProposals(await api.getProposals());
    } catch (e) {
      alert(String(e));
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-lg font-bold tracking-wide">AI Analysis Module</h1>
          <p className="text-xs text-slate-500">
            AI proposes · human approves. Powered by LM Studio (OpenAI-compatible).
          </p>
        </div>
        <div className="flex items-center gap-2 text-[11px]">
          <span
            className="h-2 w-2 rounded-full"
            style={{ background: health?.connected ? "#22c55e" : "#ef4444" }}
          />
          <span className="text-slate-400">
            {health?.connected
              ? `LM Studio connected · ${health.models.length} models`
              : "LM Studio offline"}
          </span>
          <button className="btn !px-2 !py-1 !text-[11px]" onClick={refresh}>Recheck</button>
        </div>
      </div>

      {health && health.models.length > 0 && (
        <div className="panel px-3 py-2 text-[11px] text-slate-400">
          Available models: {health.models.join(" · ")}
        </div>
      )}

      <div className="grid grid-cols-1 gap-4 xl:grid-cols-3">
        <div className="panel">
          <div className="panel-header">
            <span className="text-[12px] font-bold uppercase tracking-wider">Capability</span>
          </div>
          <div className="space-y-1.5 p-3">
            {AI_CAPABILITIES.map((c) => (
              <button
                key={c.key}
                onClick={() => setCapability(c.key)}
                className={`w-full rounded px-2.5 py-1.5 text-left text-[12px] font-semibold transition ${
                  capability === c.key
                    ? "bg-sky-600 text-white"
                    : "bg-[#1a2334] text-slate-300 hover:bg-[#24324a]"
                }`}
              >
                {c.label}
              </button>
            ))}
          </div>
          <div className="border-t border-[#1f2a3d] p-3">
            <label className="label">Optional extra context</label>
            <textarea
              rows={4}
              className="mt-1 w-full"
              placeholder="Leave blank to auto-load recent events + category scores"
              value={context}
              onChange={(e) => setContext(e.target.value)}
            />
            <button className="btn btn-primary mt-2 w-full" onClick={run} disabled={busy || runAllBusy}>
              {busy ? "Running analysis…" : "Run"}
            </button>
            <button
              className="btn mt-2 w-full"
              onClick={runAll}
              disabled={busy || runAllBusy}
              title="Run every capability one after another"
            >
              {runAllBusy ? "Running all…" : "▶ Run All reports"}
            </button>
            {runAllLog.length > 0 && (
              <div className="mt-2 max-h-32 overflow-auto rounded border border-[#1f2a3d] bg-[#0b1220] p-2 text-[10px] text-slate-400">
                {runAllLog.map((l, i) => <div key={i}>{l}</div>)}
              </div>
            )}
          </div>
        </div>

        <div className="panel xl:col-span-2">
          <div className="panel-header">
            <span className="text-[12px] font-bold uppercase tracking-wider">Analysis Output</span>
          </div>
          {error && <div className="p-3 text-sm text-red-400">{error}</div>}
          {output ? (
            <pre className="max-h-[520px] overflow-auto whitespace-pre-wrap p-4 text-[12px] leading-relaxed text-slate-300">
              {output}
            </pre>
          ) : (
            <div className="p-8 text-center text-sm text-slate-500">
              Select a capability and run. The model will separate Event · Evidence · Interpretation · Dashboard Impact.
            </div>
          )}
        </div>
      </div>

      <div className="panel">
        <div className="panel-header">
          <span className="text-[12px] font-bold uppercase tracking-wider">Proposed Changes (Human Approval Required)</span>
          <span className="text-[10px] text-slate-500">{proposals.length} proposals</span>
        </div>
        {proposals.length === 0 ? (
          <div className="p-6 text-center text-sm text-slate-500">
            No proposals yet. Run <em>Suggest Score Adjustments</em> to generate some.
          </div>
        ) : (
          <div className="divide-y divide-[#1a2334]">
            {proposals.map((p) => (
              <div key={p.id} className="flex flex-wrap items-start justify-between gap-3 px-4 py-3">
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span
                      className="badge"
                      style={{
                        color:
                          p.status === "APPROVED" ? "#22c55e" : p.status === "REJECTED" ? "#ef4444" : "#eab308",
                        borderColor: "#2a3a55",
                      }}
                    >
                      {p.status}
                    </span>
                    <span className="font-mono text-[11px] text-slate-500">#{p.id}</span>
                  </div>
                  <pre className="mt-1 max-w-[600px] overflow-auto whitespace-pre-wrap text-[11px] text-slate-300">
                    {p.proposed_changes_json}
                  </pre>
                  {p.rationale && (
                    <p className="mt-1 text-[11px] text-slate-500">{p.rationale}</p>
                  )}
                </div>
                {p.status === "PENDING" && (
                  <div className="flex gap-1.5">
                    <button className="btn !px-2 !py-1 !text-[11px]" onClick={() => decide(p.id, "APPROVED")}>
                      Approve
                    </button>
                    <button className="btn !px-2 !py-1 !text-[11px]" onClick={() => decide(p.id, "REJECTED")}>
                      Reject
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
