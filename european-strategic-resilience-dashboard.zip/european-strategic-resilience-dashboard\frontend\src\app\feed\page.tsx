"use client";

import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import { useRefresh } from "@/lib/RefreshContext";
import type { FeedItem, FeedScrapeResult, FeedSource } from "@/lib/types";

const CATEGORIES = ["Mainstream", "Fringe", "OSINT", "Iran", "Cyber"];
const FRINGE_LEVELS = ["Extreme", "Moderate", "Low-moderate", "Low"];

const CAT_COLORS: Record<string, string> = {
  Mainstream: "#22c55e",
  Fringe: "#f97316",
  OSINT: "#38bdf8",
  Iran: "#eab308",
  Cyber: "#a855f7",
};

const FRINGE_COLORS: Record<string, string> = {
  Extreme: "#ef4444",
  Moderate: "#f97316",
  "Low-moderate": "#eab308",
  Low: "#94a3b8",
};

function catBadge(c: string) {
  const color = CAT_COLORS[c] || "#94a3b8";
  return (
    <span className="badge" style={{ color, borderColor: `${color}55`, background: `${color}18` }}>
      {c}
    </span>
  );
}

function fringeBadge(f: string | null) {
  if (!f) return null;
  const color = FRINGE_COLORS[f] || "#94a3b8";
  return (
    <span className="badge" style={{ color, borderColor: `${color}55`, background: `${color}18` }}>
      {f} fringe
    </span>
  );
}

export default function FeedPage() {
  const { refreshKey } = useRefresh();
  const [sources, setSources] = useState<FeedSource[]>([]);
  const [items, setItems] = useState<FeedItem[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [scrapeResult, setScrapeResult] = useState<FeedScrapeResult | null>(null);
  const [category, setCategory] = useState("");
  const [fringe, setFringe] = useState("");
  const [showSources, setShowSources] = useState(false);

  const load = async () => {
    try {
      const [srcs, its] = await Promise.all([
        api.getFeedSources(),
        api.getFeedItems({ category: category || undefined, fringe_level: fringe || undefined }),
      ]);
      setSources(srcs);
      setItems(its);
      setError(null);
    } catch (e) {
      setError(String(e));
    }
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [refreshKey, category, fringe]);

  const scrape = async () => {
    setBusy(true);
    setScrapeResult(null);
    try {
      setScrapeResult(await api.scrapeFeed());
      await load();
    } catch (e) {
      alert(String(e));
    } finally {
      setBusy(false);
    }
  };

  const counts = sources.reduce<Record<string, number>>((m, s) => {
    m[s.category] = (m[s.category] || 0) + 1;
    return m;
  }, {});

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-lg font-bold tracking-wide">Feed — Speculation &amp; OSINT</h1>
          <p className="text-xs text-slate-500">
            Curated mainstream, fringe, OSINT, Iran and cyber feeds.{" "}
            <span className="text-slate-400">Read-only — speculations never drive dashboard scores.</span>
          </p>
        </div>
        <div className="flex gap-2">
          <button className="btn" onClick={() => setShowSources((s) => !s)}>
            {showSources ? "Hide sources" : `Sources (${sources.length})`}
          </button>
          <button className="btn btn-primary" onClick={scrape} disabled={busy}>
            {busy ? "Scraping…" : "Run scrape"}
          </button>
        </div>
      </div>

      {scrapeResult && (
        <div className="panel px-4 py-3 text-[12px]">
          <span className="text-slate-300">
            Scraped {scrapeResult.sources} source(s) → {scrapeResult.new_items} new item(s).
          </span>
          {scrapeResult.errors.length > 0 && (
            <div className="mt-1 max-h-20 overflow-auto text-amber-400">{scrapeResult.errors.join(" · ")}</div>
          )}
        </div>
      )}

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-2">
        <span className="label">Category</span>
        <button
          className={`rounded px-2.5 py-1 text-[11px] font-semibold ${category === "" ? "bg-sky-600 text-white" : "bg-[#1a2334] text-slate-400"}`}
          onClick={() => setCategory("")}
        >
          All ({sources.length})
        </button>
        {CATEGORIES.map((c) => (
          <button
            key={c}
            className={`rounded px-2.5 py-1 text-[11px] font-semibold ${category === c ? "bg-sky-600 text-white" : "bg-[#1a2334] text-slate-400"}`}
            onClick={() => setCategory(category === c ? "" : c)}
            style={category === c ? {} : { color: CAT_COLORS[c] }}
          >
            {c} ({counts[c] || 0})
          </button>
        ))}
        <span className="label ml-3">Fringe</span>
        <select
          className="w-40"
          value={fringe}
          onChange={(e) => setFringe(e.target.value)}
        >
          <option value="">All levels</option>
          {FRINGE_LEVELS.map((f) => <option key={f}>{f}</option>)}
        </select>
      </div>

      {/* Sources */}
      {showSources && (
        <div className="panel">
          <div className="panel-header">
            <span className="text-[12px] font-bold uppercase tracking-wider">Feed Sources</span>
            <span className="text-[10px] text-slate-500">{sources.length} feeds</span>
          </div>
          <div className="max-h-[400px] divide-y divide-[#1a2334] overflow-y-auto">
            {sources.map((s) => (
              <div key={s.id} className="flex flex-wrap items-center justify-between gap-2 px-4 py-2">
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    {catBadge(s.category)}
                    {fringeBadge(s.fringe_level)}
                    <span className="text-[13px] font-semibold text-slate-200">{s.name}</span>
                    {s.topic && <span className="text-[11px] text-slate-500">· {s.topic}</span>}
                  </div>
                  <div className="truncate text-[11px] text-slate-500">{s.url}</div>
                </div>
                <span className="text-[10px] text-slate-500">
                  {s.last_fetched ? `fetched ${new Date(s.last_fetched).toLocaleString()}` : "never"}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Items */}
      <div className="panel">
        <div className="panel-header">
          <span className="text-[12px] font-bold uppercase tracking-wider">Headlines</span>
          <span className="text-[10px] text-slate-500">{items.length} shown · newest first</span>
        </div>
        {error && <div className="p-4 text-sm text-red-400">{error}</div>}
        {items.length === 0 ? (
          <div className="p-8 text-center text-sm text-slate-500">
            No items{category ? ` for ${category}` : ""}. Click Run scrape to pull headlines.
          </div>
        ) : (
          <div className="max-h-[800px] divide-y divide-[#1a2334] overflow-y-auto">
            {items.map((it) => (
              <div key={it.id} className="px-4 py-2.5">
                <div className="flex flex-wrap items-center gap-2">
                  {catBadge(it.category)}
                  {fringeBadge(it.fringe_level)}
                  <a
                    href={it.url || "#"}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[13px] font-semibold text-slate-200 hover:text-sky-400"
                  >
                    {it.title}
                  </a>
                </div>
                <div className="mt-0.5 text-[11px] text-slate-500">
                  {it.topic && <span>{it.topic} · </span>}
                  {new Date(it.fetched_at).toLocaleString()}
                </div>
                {it.summary && <p className="mt-0.5 line-clamp-2 text-[11px] text-slate-500">{it.summary}</p>}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
