from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.database import get_db
from app.models import Category, ConfidenceLevel, Region, Source, SourceType
from app.schemas import CategoryOut, ConfidenceLevelOut, RegionOut, SourceOut, SourceTypeOut

router = APIRouter(prefix="/meta", tags=["meta"])


@router.get("/categories", response_model=list[CategoryOut])
async def list_categories(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Category).order_by(Category.side, Category.current_score.desc()))
    return list(result.scalars().all())


@router.get("/regions", response_model=list[RegionOut])
async def list_regions(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Region).order_by(Region.name))
    return list(result.scalars().all())


@router.get("/confidence-levels", response_model=list[ConfidenceLevelOut])
async def list_confidence_levels(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(ConfidenceLevel).order_by(ConfidenceLevel.rank.desc()))
    return list(result.scalars().all())


@router.get("/source-types", response_model=list[SourceTypeOut])
async def list_source_types(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(SourceType).order_by(SourceType.id))
    return list(result.scalars().all())


@router.get("/sources", response_model=list[SourceOut])
async def list_sources(db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(Source).options(selectinload(Source.source_type)).order_by(Source.name)
    )
    return list(result.scalars().all())
