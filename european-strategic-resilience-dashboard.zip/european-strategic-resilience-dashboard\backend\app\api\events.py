from datetime import date
import json

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.database import get_db
from app.models import (
    AIProposal, Attachment, Category, ConfidenceLevel, Event, EventCategory, EventRegion,
    ProposalStatus, Region, Source, SourceType
)
from app.schemas import EventAIOut, EventCreate, EventCreateMinimal, EventOut
from app.services import ai_service
from app.services import approvals
from app.services.rule_engine import refresh_event_status

router = APIRouter(prefix="/events", tags=["events"])


def _event_query():
    return (
        select(Event)
        .options(
            selectinload(Event.source).selectinload(Source.source_type),
            selectinload(Event.source_type),
            selectinload(Event.confidence_level),
            selectinload(Event.category_links).selectinload(EventCategory.category),
            selectinload(Event.region_links).selectinload(EventRegion.region),
            selectinload(Event.attachments),
        )
    )


@router.get("", response_model=list[EventOut])
async def list_events(
    db: AsyncSession = Depends(get_db),
    category_id: int | None = None,
    region_id: int | None = None,
    confidence: str | None = None,
    source_type_id: int | None = None,
    date_from: date | None = None,
    date_to: date | None = None,
    limit: int = 100,
    offset: int = 0,
):
    q = _event_query().order_by(Event.event_date.desc(), Event.id.desc()).limit(limit).offset(offset)
    if category_id:
        q = q.join(Event.category_links).where(EventCategory.category_id == category_id)
    if region_id:
        q = q.join(Event.region_links).where(EventRegion.region_id == region_id)
    if confidence:
        q = q.join(Event.confidence_level).where(ConfidenceLevel.name == confidence)
    if source_type_id:
        q = q.where(Event.source_type_id == source_type_id)
    if date_from:
        q = q.where(Event.event_date >= date_from)
    if date_to:
        q = q.where(Event.event_date <= date_to)
    result = await db.execute(q)
    return list(result.scalars().unique().all())


@router.get("/{event_id}", response_model=EventOut)
async def get_event(event_id: int, db: AsyncSession = Depends(get_db)):
    result = await db.execute(_event_query().where(Event.id == event_id))
    ev = result.scalar_one_or_none()
    if not ev:
        raise HTTPException(status_code=404, detail="Event not found")
    return ev


@router.post("", response_model=EventOut, status_code=201)
async def create_event(payload: EventCreate, db: AsyncSession = Depends(get_db)):
    max_entry = await db.execute(select(func.max(Event.entry_number)))
    next_entry = (max_entry.scalar() or 0) + 1

    event = Event(
        entry_number=next_entry,
        title=payload.title,
        event_date=payload.event_date,
        source_id=payload.source_id,
        source_type_id=payload.source_type_id,
        confidence_level_id=payload.confidence_level_id,
        summary=payload.summary,
        evidence_notes=payload.evidence_notes,
        analyst_notes=payload.analyst_notes,
        status=payload.status,
    )
    db.add(event)
    await db.flush()

    for cid in payload.category_ids:
        delta = payload.impact_deltas.get(str(cid), payload.impact_deltas.get(cid, 0.0))
        db.add(EventCategory(event_id=event.id, category_id=cid, impact_delta=float(delta)))
    for rid in payload.region_ids:
        db.add(EventRegion(event_id=event.id, region_id=rid))

    await db.flush()
    await refresh_event_status(db, event)

    # Apply impact deltas to category scores
    for cid in payload.category_ids:
        delta = payload.impact_deltas.get(str(cid), payload.impact_deltas.get(cid, 0.0))
        cat = await db.get(Category, cid)
        if cat:
            cat.current_score = min(max(cat.current_score + float(delta), 0.0), 10.0)
            if delta > 0:
                cat.trend = "UP"
            elif delta < 0:
                cat.trend = "DOWN"

    await db.commit()
    await db.refresh(event)
    result = await db.execute(_event_query().where(Event.id == event.id))
    return result.scalar_one()


@router.post("/ai", response_model=EventAIOut, status_code=201)
async def create_event_with_ai(payload: EventCreateMinimal, db: AsyncSession = Depends(get_db)):
    """Minimal intake: the analyst supplies raw data, the AI classifies it.

    Categories, regions, confidence, source type and notes are derived by the model.
    Suggested score impacts are queued as a PENDING AI proposal (human approval required),
    so classification is automatic while dashboard score changes stay human-approved.
    """
    # Load reference data for the model to choose from
    cats = list((await db.execute(select(Category))).scalars().all())
    regs = list((await db.execute(select(Region))).scalars().all())
    stypes = list((await db.execute(select(SourceType))).scalars().all())
    cl_by_name = {c.name: c for c in (await db.execute(select(ConfidenceLevel))).scalars()}

    raw_text = f"Title: {payload.title}\nDate: {payload.event_date}\nDescription: {payload.summary}"
    if payload.source_name:
        raw_text += f"\nSource: {payload.source_name}"

    ai: dict = {}
    ai_available = False
    try:
        ai = await ai_service.extract_event(
            raw_text,
            categories=[c.name for c in cats],
            regions=[r.name for r in regs],
            source_types=[s.name for s in stypes],
        )
        ai_available = bool(ai)
    except Exception:  # noqa: BLE001
        ai = {}

    # --- Resolve source (create-by-name if needed; never null — source_id is required) ---
    source_name = (payload.source_name or "").strip() or "Unspecified"
    source = (await db.execute(
        select(Source).where(Source.name == source_name)
    )).scalar_one_or_none()
    if source is None:
        st_name = ai.get("source_type") if ai else None
        st = (await db.execute(
            select(SourceType).where(SourceType.name == str(st_name))
        )).scalar_one_or_none() if st_name else None
        st = st or stypes[0]
        source = Source(name=source_name, source_type_id=st.id)
        db.add(source)
        await db.flush()

    # --- Resolve source type ---
    source_type_id = source.source_type_id

    # --- Resolve confidence (AI-derived, floored by any min_confidence, else MEDIUM) ---
    conf_name = (ai.get("confidence") or "MEDIUM").upper()
    if conf_name not in cl_by_name:
        conf_name = "MEDIUM"
    # Apply a confidence floor (e.g. an OSINT source's tier) — never score below it.
    _rank = {"LOW": 1, "MEDIUM": 2, "HIGH": 3}
    if payload.min_confidence and payload.min_confidence.upper() in _rank:
        floor = payload.min_confidence.upper()
        if _rank.get(floor, 0) > _rank.get(conf_name, 0):
            conf_name = floor
    confidence_level_id = cl_by_name[conf_name].id

    # --- Resolve AI-chosen categories/regions ---
    cat_names = {c["name"] for c in ai.get("categories", []) if isinstance(c, dict) and c.get("name")}
    chosen_cats = [c for c in cats if c.name in cat_names]
    reg_names = set(ai.get("regions", []) or [])
    chosen_regs = [r for r in regs if r.name in reg_names]

    # --- Create the event ---
    _sev = (payload.severity or (ai.get("severity") if ai else None) or "MEDIUM").upper()
    if _sev not in ("LOW", "MEDIUM", "HIGH", "CRITICAL"):
        _sev = "MEDIUM"
    max_entry = await db.execute(select(func.max(Event.entry_number)))
    event = Event(
        entry_number=(max_entry.scalar() or 0) + 1,
        title=payload.title,
        event_date=payload.event_date,
        source_id=source.id,
        source_type_id=source_type_id,
        confidence_level_id=confidence_level_id,
        summary=payload.summary,
        evidence_notes=(ai.get("evidence_notes") if ai else None) or f"Raw intake; source: {payload.source_name or 'not specified'}.",
        analyst_notes=(ai.get("analyst_notes") if ai else None) or None,
        status="REPORTED",
        severity=_sev,
    )
    db.add(event)
    await db.flush()

    proposals_created = 0
    impact_payload: dict[int, float] = {}
    for c in ai.get("categories", []) if ai else []:
        if not isinstance(c, dict):
            continue
        cat = next((x for x in cats if x.name == c.get("name")), None)
        if not cat:
            continue
        delta = float(c.get("impact_delta", 0.0) or 0.0)
        delta = max(-2.0, min(2.0, delta))
        db.add(EventCategory(event_id=event.id, category_id=cat.id, impact_delta=delta))
        if delta != 0.0:
            impact_payload[cat.id] = delta
    for r in chosen_regs:
        db.add(EventRegion(event_id=event.id, region_id=r.id))

    await db.flush()
    await refresh_event_status(db, event)

    # Score impacts → auto-approve (apply) if enabled, else queue for human approval.
    auto = await approvals.is_auto_approve(db)
    if impact_payload:
        for cat_id, delta in impact_payload.items():
            cat = next((x for x in cats if x.id == cat_id), None)
            proposal = AIProposal(
                event_id=event.id,
                category_id=cat_id,
                proposed_changes_json=json.dumps({
                    "category": cat.name if cat else str(cat_id),
                    "impact_delta": delta,
                    "new_score": round(min(max((cat.current_score if cat else 0) + delta, 0.0), 10.0), 2),
                    "source": "auto_intake",
                }),
                rationale=f"Score impact {'auto-applied' if auto else 'proposed'} by AI intake for entry #{event.entry_number}.",
                status=ProposalStatus.PENDING.value,
            )
            db.add(proposal)
            if auto:
                await db.flush()
                await approvals.approve_and_apply(db, proposal)
            proposals_created += 1
        # Enforce the 10.0 cap after applying any auto-approved impacts
        if auto and impact_payload:
            await approvals.enforce_cap_for_session(db)

    await db.commit()

    result = await db.execute(_event_query().where(Event.id == event.id))
    ev = result.scalar_one()
    st_obj = next((s for s in stypes if s.id == source_type_id), None)
    return EventAIOut(
        event=ev,
        ai_confidence=conf_name,
        ai_categories=[c.name for c in chosen_cats],
        ai_regions=[r.name for r in chosen_regs],
        ai_source_type=st_obj.name if st_obj else "",
        proposals_created=proposals_created,
        ai_available=ai_available,
    )


@router.delete("/{event_id}", status_code=204)
async def delete_event(event_id: int, db: AsyncSession = Depends(get_db)):
    ev = await db.get(Event, event_id)
    if not ev:
        raise HTTPException(status_code=404, detail="Event not found")
    # Clear related AI proposals (FK on event_id) before removing the event
    await db.execute(
        AIProposal.__table__.delete().where(AIProposal.event_id == event_id)
    )
    # Clear scraped-item references (FK on ingested_event_id)
    from app.models import ScrapedItem
    await db.execute(
        ScrapedItem.__table__.update()
        .where(ScrapedItem.ingested_event_id == event_id)
        .values(ingested_event_id=None, ingested=False)
    )
    await db.delete(ev)
    await db.commit()
