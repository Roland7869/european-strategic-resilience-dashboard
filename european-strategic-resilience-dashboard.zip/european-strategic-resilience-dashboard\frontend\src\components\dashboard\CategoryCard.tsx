"use client";

import type { CategoryScore } from "@/lib/types";
import { TrendArrow } from "@/components/ui/Badges";
import { SIDE_COLORS } from "@/lib/constants";

// State colour replaces the score number:
//   black = maximum reached, red = critical, orange = elevated, yellow = watch, green = baseline
function stateColor(score: number): string {
  if (score >= 9.99) return "#000000"; // maximum
  if (score >= 9) return "#ef4444";
  if (score >= 7) return "#f97316";
  if (score >= 5) return "#eab308";
  return "#22c55e";
}

function fmtDate(iso: string | null): string {
  if (!iso) return "—";
  const d = new Date(iso);
  return isNaN(d.getTime()) ? "—" : d.toLocaleDateString(undefined, { month: "short", day: "numeric" });
}

export function CategoryCard({ cat }: { cat: CategoryScore }) {
  const accent = SIDE_COLORS[cat.side];
  const color = stateColor(cat.current_score);
  const isMax = cat.current_score >= 9.99;
  const peak = cat.peak_score ?? cat.current_score;
  // Was at maximum, but a later occurrence brought the rating back down.
  const broughtDown = peak >= 9.99 && cat.current_score < 9.99;
  const conf = Math.round(cat.confidence_pct ?? 0);

  return (
    <div className="panel group relative overflow-hidden transition hover:border-[#2a3a55]">
      <div className="absolute left-0 top-0 h-full w-[3px]" style={{ background: accent }} />
      <div className="px-3 py-2.5 pl-4">
        <div className="text-[12px] font-semibold leading-tight text-slate-200">
          {cat.name}
        </div>

        {/* State colour — the score is shown as colour only (black = maximum) */}
        <div
          className="mt-2 flex h-7 items-center justify-center rounded"
          style={{
            background: color,
            border: isMax ? "1px solid rgba(255,255,255,0.28)" : "1px solid transparent",
            boxShadow: isMax ? "inset 0 0 0 1px rgba(0,0,0,0.6)" : "none",
          }}
          title={`State: ${isMax ? "MAXIMUM" : color}`}
        >
          <span
            className="text-[10px] font-black tracking-widest"
            style={{ color: isMax ? "#ffffff" : "#0b0f17" }}
          >
            {isMax ? "MAX" : ""}
          </span>
        </div>

        {/* Last occurrence + trend */}
        <div className="mt-2 flex items-center justify-between gap-2">
          <TrendArrow trend={cat.trend} />
          <span className="text-[10px] text-slate-500" title="Last occurrence">
            last {fmtDate(cat.last_occurrence)}
          </span>
        </div>

        {/* Brought down from maximum by a newer occurrence */}
        {broughtDown && (
          <div className="mt-1">
            <span
              className="badge"
              style={{ color: "#94a3b8", borderColor: "#94a3b855", background: "#94a3b818" }}
              title={`Peaked at ${peak.toFixed(1)} — a newer occurrence lowered the rating`}
            >
              ▼ from max
            </span>
          </div>
        )}

        <div className="mt-2 flex items-center justify-between gap-2 text-[10px] text-slate-500">
          <span style={{ color: conf >= 80 ? "#22c55e" : conf >= 55 ? "#eab308" : "#94a3b8" }}>
            {conf}% conf
          </span>
          <span>{cat.corroboration_count ?? 0} src</span>
        </div>
      </div>
    </div>
  );
}
