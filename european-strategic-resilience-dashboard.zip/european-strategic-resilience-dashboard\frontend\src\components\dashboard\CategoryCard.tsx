"use client";

import type { CategoryScore } from "@/lib/types";
import { TrendArrow } from "@/components/ui/Badges";
import { SIDE_COLORS } from "@/lib/constants";

function pctColor(pct: number): string {
  return pct >= 80 ? "#22c55e" : pct >= 55 ? "#eab308" : "#94a3b8";
}

export function CategoryCard({ cat }: { cat: CategoryScore }) {
  const accent = SIDE_COLORS[cat.side];
  const scorePct = (cat.current_score / 10) * 100;
  const barColor =
    cat.current_score >= 8.5
      ? "#ef4444"
      : cat.current_score >= 7
        ? "#f97316"
        : cat.current_score >= 5
          ? "#eab308"
          : "#22c55e";
  const conf = Math.round(cat.confidence_pct ?? 0);
  return (
    <div className="panel group relative overflow-hidden transition hover:border-[#2a3a55]">
      <div className="absolute left-0 top-0 h-full w-[3px]" style={{ background: accent }} />
      <div className="px-3 py-2.5 pl-4">
        <div className="flex items-start justify-between gap-2">
          <div className="text-[12px] font-semibold leading-tight text-slate-200">
            {cat.name}
          </div>
          {/* Score — the state estimate */}
          <div className="text-right">
            <div className="font-mono text-lg font-black leading-none" style={{ color: barColor }}>
              {cat.current_score.toFixed(1)}
            </div>
            <div className="text-[9px] uppercase tracking-wide text-slate-500">score</div>
          </div>
        </div>
        <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-[#1a2334]">
          <div
            className="h-full rounded-full transition-all"
            style={{ width: `${scorePct}%`, background: barColor }}
          />
        </div>

        {/* Confidence — how certain we are (rises with corroboration, not score) */}
        <div className="mt-2 flex items-center justify-between text-[10px]">
          <span className="text-slate-500">Confidence</span>
          <span className="font-mono font-bold" style={{ color: pctColor(conf) }}>{conf}%</span>
        </div>
        <div className="mt-0.5 h-1 w-full overflow-hidden rounded-full bg-[#1a2334]">
          <div className="h-full rounded-full" style={{ width: `${conf}%`, background: pctColor(conf) }} />
        </div>

        <div className="mt-2 flex items-center justify-between gap-2">
          <TrendArrow trend={cat.trend} />
          {/* Corroboration — supporting sources (signals, not escalation) */}
          <span className="text-[10px] text-slate-500" title="Corroborating sources/events">
            {cat.corroboration_count ?? 0} src
          </span>
        </div>
      </div>
    </div>
  );
}
