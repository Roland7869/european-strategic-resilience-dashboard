"use client";

import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import type { ConfidenceDistribution } from "@/lib/types";

const LEVEL_COLORS: Record<string, string> = {
  HIGH: "#22c55e",
  MEDIUM: "#eab308",
  LOW: "#94a3b8",
};

export function ConfidenceDistributionChart({ data }: { data: ConfidenceDistribution[] }) {
  return (
    <div className="h-[200px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
          <CartesianGrid stroke="#1a2334" strokeDasharray="3 3" />
          <XAxis dataKey="level" tick={{ fill: "#64748b", fontSize: 11 }} />
          <YAxis tick={{ fill: "#64748b", fontSize: 10 }} allowDecimals={false} />
          <Tooltip
            contentStyle={{ background: "#0d1420", border: "1px solid #2a3a55", borderRadius: 4, fontSize: 12 }}
          />
          <Bar dataKey="count" radius={[3, 3, 0, 0]}>
            {data.map((d) => (
              <Cell key={d.level} fill={LEVEL_COLORS[d.level] || "#38bdf8"} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
