import type { Metadata } from "next";
import "./globals.css";
import { Nav } from "@/components/ui/Nav";
import { RefreshProvider } from "@/lib/RefreshContext";

export const metadata: Metadata = {
  title: "European Strategic Resilience Dashboard",
  description:
    "Strategic early-warning, resilience and geopolitical trend tracking system. Not a prediction engine.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-[#0b0f17] text-slate-200 antialiased">
        <RefreshProvider>
          <Nav />
          <main className="mx-auto max-w-[1600px] px-4 py-4">{children}</main>
        </RefreshProvider>
      </body>
    </html>
  );
}
