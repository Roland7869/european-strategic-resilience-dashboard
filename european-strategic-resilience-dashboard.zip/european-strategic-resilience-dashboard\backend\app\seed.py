"""Seed the database with categories, regions, confidence levels, source types, sources, and sample events."""
import random
from datetime import date, timedelta

from sqlalchemy import select
from sqlalchemy.orm import selectinload

from app.constants import CATEGORIES, CONFIDENCE_LEVELS, REGIONS, SOURCE_TYPES
from app.database import AsyncSessionLocal
from app.models import (
    Category, ConfidenceLevel, Event, EventCategory, EventRegion,
    Prep, Region, ScrapeSource, Source, SourceType, Side
)
from app.services.rule_engine import derive_status, refresh_event_status
from app.services.scraper import TIER_CONFIDENCE
from app.models import PowerOutageSource
from app.models import CyberAttackSource
from app.models import SpeculationSource


# OSINT scrape sources grouped by tier. base_confidence drives the score-impact weight:
#   HIGH -> 100%, MEDIUM -> 50%, LOW -> 25% (detection only). See scoring_discipline.
# (name, url, kind, tier)
SAMPLE_SOURCES_FEED = [
    # Tier 1 - High Confidence News Wires (highest weighting)
    # (Reuters + AP removed: public feeds discontinued / DNS dead)
    ("BBC World", "https://feeds.bbci.co.uk/news/world/rss.xml", "rss", "Tier 1 - News Wires"),
    ("Financial Times World", "https://www.ft.com/world?format=rss", "rss", "Tier 1 - News Wires"),
    ("Al Jazeera", "https://www.aljazeera.com/xml/rss/all.xml", "rss", "Tier 1 - News Wires"),
    ("Deutsche Welle", "https://rss.dw.com/xml/rss-en-all", "rss", "Tier 1 - News Wires"),
    # Tier 2 - Geopolitical & Security Intelligence
    # (RAND + Chatham House removed: anti-bot / URL changed)
    ("ISW Ukraine", "https://www.understandingwar.org/feeds/all", "rss", "Tier 2 - Geopolitical Intel"),
    ("CSIS", "https://www.csis.org/rss.xml", "rss", "Tier 2 - Geopolitical Intel"),
    ("RUSI", "https://rusi.org/rss/latest-publications.xml", "rss", "Tier 2 - Geopolitical Intel"),
    ("Atlantic Council", "https://www.atlanticcouncil.org/feed/", "rss", "Tier 2 - Geopolitical Intel"),
    # NATO / Defence
    # (NATO removed: historical RSS endpoint no longer responds)
    ("US DoD", "https://www.defense.gov/DesktopModules/ArticleCS/RSS.ashx?ContentType=1&Site=945&Category=789", "rss", "NATO / Defence"),
    ("UK Ministry of Defence", "https://www.gov.uk/government/organisations/ministry-of-defence.atom", "rss", "NATO / Defence"),
    ("Polish Defence Ministry", "https://www.gov.pl/rss/mon", "rss", "NATO / Defence"),
    # Cyber Threat Intelligence (drives Cyber Operations)
    ("CISA Advisories", "https://www.cisa.gov/cybersecurity-advisories/cybersecurity-advisories.xml", "rss", "Cyber Threat Intelligence"),
    ("US-CERT NCAS", "https://us-cert.cisa.gov/ncas/alerts.xml", "rss", "Cyber Threat Intelligence"),
    ("Bleeping Computer", "https://www.bleepingcomputer.com/feed/", "rss", "Cyber Threat Intelligence"),
    ("Krebs on Security", "https://krebsonsecurity.com/feed/", "rss", "Cyber Threat Intelligence"),
    ("The Record", "https://therecord.media/feed", "rss", "Cyber Threat Intelligence"),
    ("SANS Internet Storm Center", "https://isc.sans.edu/rssfeed.xml", "rss", "Cyber Threat Intelligence"),
    # Maritime / Shipping (Hormuz, Red Sea, shipping)
    # (Lloyd's List + TradeWinds removed: feed URLs 404)
    ("MarineLink", "https://www.marinelink.com/rss", "rss", "Maritime / Shipping"),
    ("gCaptain", "https://gcaptain.com/feed/", "rss", "Maritime / Shipping"),
    # Energy Security (Dependency Risk)
    # (IEA + EIA + Energy Intelligence removed: feed URLs 404)
    ("OilPrice", "https://oilprice.com/rss/main", "rss", "Energy Security"),
    # Infrastructure & Resilience
    # (OECD removed: 403 bot protection)
    ("EU Civil Protection", "https://civil-protection-humanitarian-aid.ec.europa.eu/news-stories/news_en?format=rss", "rss", "Infrastructure & Resilience"),
    ("European Commission", "https://ec.europa.eu/commission/presscorner/api/rss", "rss", "Infrastructure & Resilience"),
    # Sanctions / Financial Warfare
    # (IMF + World Bank + BIS + OFAC Treasury removed: 404 / 403)
    # OSINT / Early Warning (detection only — never directly drive scores)
    # (Army Recognition removed: 404)
    ("Bellingcat", "https://www.bellingcat.com/feed/", "rss", "OSINT / Early Warning"),
    ("Oryx", "https://www.oryxspioenkop.com/feeds/posts/default", "rss", "OSINT / Early Warning"),
    ("Defence Blog", "https://defence-blog.com/feed/", "rss", "OSINT / Early Warning"),
    ("Military Times", "https://www.militarytimes.com/arc/outboundfeeds/rss/", "rss", "OSINT / Early Warning"),
    # Space & Satellite Domain
    ("SpaceNews", "https://spacenews.com/feed/", "rss", "Space & Satellite"),
    ("ESA", "https://www.esa.int/rssfeed/Our_Activities", "rss", "Space & Satellite"),
    ("NASA", "https://www.nasa.gov/rss/dyn/breaking_news.rss", "rss", "Space & Satellite"),
]

# Sample preparedness inventory — a 3-STAGE household roadmap. Quantity starts at 0
# (from scratch); the owner stocks each item up. min_quantity drives the shortfall flag.
# Format: (name, category, quantity, unit, min_quantity, priority, notes, stage)
STAGE_GOALS = {
    1: "Immediate Readiness (0-14 days) — survive short disruptions without external help.",
    2: "Resilience (14-180 days) — function during prolonged shortages.",
    3: "Self-Reliance / Rebuilding (180+ days) — reduce dependency on fragile systems.",
}
SAMPLE_PREPS = [
    # ---- STAGE 1: Immediate Readiness (0-14 days) ----
    ("Drinking water (14 days)", "Water", 0, "litres", 42, "HIGH", "3-5 L/person/day; min scaled by household size", 1),
    ("Water purification tablets", "Water", 0, "tablets", 20, "HIGH", "", 1),
    ("Portable water filter", "Water", 0, "units", 1, "HIGH", "Sawyer Mini or similar", 1),
    ("Water collection containers", "Water", 0, "units", 2, "MEDIUM", "", 1),
    ("Tinned food", "Food", 0, "cans", 24, "HIGH", "Veg, meat, fish", 1),
    ("Rice", "Food", 0, "kg", 10, "HIGH", "", 1),
    ("Pasta", "Food", 0, "kg", 5, "HIGH", "", 1),
    ("Oats", "Food", 0, "kg", 3, "MEDIUM", "", 1),
    ("Dried beans / lentils", "Food", 0, "kg", 5, "MEDIUM", "", 1),
    ("UHT milk", "Food", 0, "litres", 6, "MEDIUM", "", 1),
    ("Cooking oil", "Food", 0, "litres", 2, "MEDIUM", "", 1),
    ("Salt / sugar", "Food", 0, "kg", 2, "LOW", "", 1),
    ("Coffee / tea", "Food", 0, "units", 1, "LOW", "", 1),
    ("Camping stove", "Fuel", 0, "units", 1, "HIGH", "", 1),
    ("Stove fuel (10-14 days)", "Fuel", 0, "days", 10, "HIGH", "", 1),
    ("Manual can opener", "Other", 0, "units", 1, "MEDIUM", "", 1),
    ("Fire-starting supplies", "Other", 0, "units", 1, "MEDIUM", "", 1),
    ("LED torches", "Power", 0, "units", 3, "HIGH", "", 1),
    ("Rechargeable lantern", "Power", 0, "units", 1, "MEDIUM", "", 1),
    ("Head torch", "Power", 0, "units", 2, "MEDIUM", "", 1),
    ("Spare batteries", "Power", 0, "units", 20, "HIGH", "", 1),
    ("Battery radio", "Comms", 0, "units", 1, "HIGH", "", 1),
    ("Crank radio", "Comms", 0, "units", 1, "MEDIUM", "", 1),
    ("Offline maps (loaded)", "Comms", 0, "units", 1, "LOW", "", 1),
    ("Printed emergency contacts", "Comms", 0, "units", 1, "LOW", "", 1),
    ("First aid kit", "Medical", 0, "kits", 1, "HIGH", "", 1),
    ("Prescription meds (2 weeks)", "Medical", 0, "supplies", 1, "HIGH", "", 1),
    ("Painkillers", "Medical", 0, "units", 1, "MEDIUM", "", 1),
    ("Antihistamines", "Medical", 0, "units", 1, "MEDIUM", "", 1),
    ("Anti-diarrhoeal medication", "Medical", 0, "units", 1, "MEDIUM", "", 1),
    ("Bandages / dressings", "Medical", 0, "units", 5, "MEDIUM", "", 1),
    ("Disinfectant", "Medical", 0, "units", 1, "MEDIUM", "", 1),
    ("Cash (small notes)", "Other", 0, "EUR", 200, "HIGH", "Several hundred euro physical", 1),
    ("Important documents (copies)", "Other", 0, "sets", 1, "HIGH", "Passports, insurance, deeds, vehicle, USB backup", 1),

    # ---- STAGE 2: Resilience (14-180 days) ----
    ("Large water storage", "Water", 0, "litres", 500, "MEDIUM", "500-1000 L", 2),
    ("Rainwater harvesting kit", "Water", 0, "units", 1, "MEDIUM", "Gutters, filters, barrels", 2),
    ("Gravity water filter", "Water", 0, "units", 1, "MEDIUM", "", 2),
    ("Spare filter cartridges", "Water", 0, "units", 2, "MEDIUM", "", 2),
    ("Bleach (purification)", "Water", 0, "litres", 2, "LOW", "", 2),
    ("Long-term food reserve (3-6 mo)", "Food", 0, "months", 3, "HIGH", "Rotate: eat oldest first", 2),
    ("Portable power station", "Power", 0, "units", 1, "HIGH", "", 2),
    ("Solar panels (portable)", "Power", 0, "units", 1, "MEDIUM", "", 2),
    ("Deep cycle batteries", "Power", 0, "units", 2, "MEDIUM", "", 2),
    ("Secondary heat source", "Shelter", 0, "units", 1, "MEDIUM", "", 2),
    ("Wood fuel store", "Fuel", 0, "units", 1, "MEDIUM", "", 2),
    ("Thermal blankets", "Shelter", 0, "units", 4, "MEDIUM", "", 2),
    ("Reinforced locks", "Shelter", 0, "units", 1, "MEDIUM", "", 2),
    ("Outdoor lighting", "Power", 0, "units", 2, "LOW", "", 2),
    ("Window security film", "Shelter", 0, "units", 1, "LOW", "", 2),
    ("Security cameras (battery-backed)", "Shelter", 0, "units", 2, "LOW", "", 2),
    ("Toiletries (6-month)", "Other", 0, "months", 6, "MEDIUM", "Soap, toothpaste, TP, detergent, hygiene", 2),

    # ---- STAGE 3: Self-Reliance / Rebuilding (180+ days) ----
    ("Permanent rainwater system", "Water", 0, "units", 1, "MEDIUM", "Cisterns, sustainable purification", 3),
    ("Large cistern", "Water", 0, "litres", 2000, "LOW", "", 3),
    ("Garden (potatoes, onions, carrots, cabbage, beans)", "Food", 0, "m2", 10, "MEDIUM", "", 3),
    ("Greenhouse", "Food", 0, "units", 1, "LOW", "Extend growing season", 3),
    ("Fruit trees / berry bushes", "Food", 0, "units", 3, "LOW", "", 3),
    ("Heirloom seed store", "Food", 0, "varieties", 10, "MEDIUM", "Multi-year reserve", 3),
    ("Roof solar array", "Power", 0, "kW", 2, "LOW", "", 3),
    ("Home battery storage", "Power", 0, "kWh", 5, "LOW", "", 3),
    ("Wood stove", "Shelter", 0, "units", 1, "MEDIUM", "", 3),
    ("Insulation upgrades", "Shelter", 0, "units", 1, "LOW", "", 3),
    ("Workshop tool set", "Other", 0, "sets", 1, "MEDIUM", "Woodworking, repairs, gardening, vehicle", 3),
    ("Spare parts (fasteners, wire, fuses)", "Other", 0, "sets", 1, "MEDIUM", "", 3),
]


# Power-outage sources (Google News RSS search — SSRF-safe, returns outage news per
# location). Country/region/city drive the cascading picker + scrape filter.
# (name, country, region, city, url, kind)
def _gnews(q: str, hl: str, gl: str) -> str:
    return f"https://news.google.com/rss/search?q={q}&hl={hl}&gl={gl}&ceid={gl}:{hl.split('-')[0]}"

SAMPLE_OUTAGE_SOURCES = [
    ("Power outages — United Kingdom", "United Kingdom", None, None,
     _gnews("power+outage+united+kingdom", "en-GB", "GB"), "rss"),
    ("Power outages — England / London", "United Kingdom", "England", "London",
     _gnews("power+outage+london", "en-GB", "GB"), "rss"),
    ("Power outages — Scotland", "United Kingdom", "Scotland", None,
     _gnews("power+outage+scotland", "en-GB", "GB"), "rss"),
    ("Power outages — Germany", "Germany", None, None,
     _gnews("Stromausfall+Deutschland", "de-DE", "DE"), "rss"),
    ("Power outages — Bavaria / Munich", "Germany", "Bavaria", "Munich",
     _gnews("Stromausfall+M%C3%BCnchen", "de-DE", "DE"), "rss"),
    ("Power outages — France", "France", None, None,
     _gnews("coupure+electricite+France", "fr-FR", "FR"), "rss"),
    ("Power outages — Poland", "Poland", None, None,
     _gnews("przerwa+dost%C4%99pu+pr%C4%85du+Polska", "pl-PL", "PL"), "rss"),
    ("Power outages — Ukraine", "Ukraine", None, None,
     _gnews("відключення+електроенергії+Україна", "uk-UA", "UA"), "rss"),
    ("Power outages — United States", "United States", None, None,
     _gnews("power+outage+united+states", "en-US", "US"), "rss"),
    ("Power outages — Texas", "United States", "Texas", None,
     _gnews("power+outage+texas", "en-US", "US"), "rss"),
]

# All EU countries (country-level outage news feeds) so the picker covers the EU.
EU_COUNTRIES = [
    ("Austria", "AT"), ("Belgium", "BE"), ("Bulgaria", "BG"), ("Croatia", "HR"),
    ("Cyprus", "CY"), ("Czechia", "CZ"), ("Denmark", "DK"), ("Estonia", "EE"),
    ("Finland", "FI"), ("France", "FR"), ("Germany", "DE"), ("Greece", "GR"),
    ("Hungary", "HU"), ("Ireland", "IE"), ("Italy", "IT"), ("Latvia", "LV"),
    ("Lithuania", "LT"), ("Luxembourg", "LU"), ("Malta", "MT"),
    ("Netherlands", "NL"), ("Poland", "PL"), ("Portugal", "PT"),
    ("Romania", "RO"), ("Slovakia", "SK"), ("Slovenia", "SI"),
    ("Spain", "ES"), ("Sweden", "SE"),
]
for _name, _cc in EU_COUNTRIES:
    SAMPLE_OUTAGE_SOURCES.append(
        (f"Power outages — {_name}", _name, None, None,
         _gnews(f"power+outage+{_name.replace(' ', '+')}", f"en-{_cc}", _cc), "rss")
    )

# Cyber attack / threat-intelligence feeds (name, url, kind)
SAMPLE_CYBER_SOURCES = [
    ("CISA Advisories", "https://www.cisa.gov/cybersecurity-advisories/cybersecurity-advisories.xml", "rss"),
    ("US-CERT NCAS", "https://us-cert.cisa.gov/ncas/alerts.xml", "rss"),
    ("Krebs on Security", "https://krebsonsecurity.com/feed/", "rss"),
    ("The Record", "https://therecord.media/feed", "rss"),
    ("Bleeping Computer", "https://www.bleepingcomputer.com/feed/", "rss"),
    ("SANS Internet Storm Center", "https://isc.sans.edu/rssfeed.xml", "rss"),
    ("Wired Security", "https://www.wired.com/feed/tag/security/latest/rss", "rss"),
    ("Dark Reading", "https://www.darkreading.com/rss.xml", "rss"),
]

# Feed tab — speculation / OSINT feeds (read-only, never drives scores).
# (name, url, kind, category, topic, fringe_level)
# Categories: Mainstream | Fringe | OSINT | Iran | Cyber
SAMPLE_FEED_SOURCES = [
    # --- Mainstream / verified ---
    ("Critical Threats (Iran)", "https://www.criticalthreats.org/iran-updates/feed", "rss", "Mainstream", "Iran", None),
    ("Small Wars Journal", "https://smallwarsjournal.com/feed", "rss", "Mainstream", "Geopolitics", None),
    ("Understanding War", "https://understandingwar.org/feed", "rss", "Mainstream", "Geopolitics", None),
    ("Dallas Fed Research", "https://www.dallasfed.org/research/rss.aspx", "rss", "Mainstream", "Economics", None),
    ("IEA Oil Market", "https://www.iea.org/rss-feed.xml", "rss", "Mainstream", "Energy", None),
    ("Bloomberg Markets", "https://feeds.bloomberg.com/markets/news.rss", "rss", "Mainstream", "Markets", None),
    ("Capital Economics", "https://www.capitaleconomics.com/rss/", "rss", "Mainstream", "Economics", None),
    ("Fortune", "https://fortune.com/feed/", "rss", "Mainstream", "Markets/AI", None),
    ("Forbes Markets", "https://www.forbes.com/feeds/index.xml", "rss", "Mainstream", "Markets", None),
    ("Business Insider Markets", "https://markets.businessinsider.com/rss", "rss", "Mainstream", "Markets", None),
    ("CNN Business", "https://rss.cnn.com/rss/cnn_business.rss", "rss", "Mainstream", "General", None),
    ("NYT Business", "https://rss.nytimes.com/services/xml/rss/nyt/Business.xml", "rss", "Mainstream", "General", None),
    ("Guardian Tech (AI)", "https://www.theguardian.com/technology/aiartificialintelligence/rss", "rss", "Mainstream", "AI", None),
    ("Guardian Business", "https://www.theguardian.com/business/rss", "rss", "Mainstream", "General", None),
    ("CNBC Top Stories", "https://search.cnbc.com/rs/search/combinedcms/view.xml?path%2Fcms%2Fcontent%2Fxml%2Fcnbc%2Ftopstories&site=cnbc", "rss", "Mainstream", "Markets", None),
    ("MIT Tech Review", "https://www.technologyreview.com/feed/", "rss", "Mainstream", "AI/Tech", None),
    ("OilPrice.com", "https://oilprice.com/rss/main", "rss", "Mainstream", "Energy", None),
    ("The Crude Oil Trader", "https://feeds.feedburner.com/TheCrudeOilTrader", "rss", "Mainstream", "Energy", None),
    ("Oil & Gas Investments", "https://oilandgas-investments.com/feed/", "rss", "Mainstream", "Energy", None),
    ("Global Market Updates", "https://globalmarketupdates.com/feed.xml", "rss", "Mainstream", "Energy/Markets", None),
    ("SCMP", "https://www.scmp.com/rss/12/feed", "rss", "Mainstream", "Geopolitics", None),
    # --- Fringe / speculative ---
    ("SHTF Plan", "http://feeds.feedburner.com/SHTFplan?format=xml", "rss", "Fringe", "Iran war / collapse", "Extreme"),
    ("The Economic Collapse Blog", "https://theeconomiccollapseblog.com/feed", "rss", "Fringe", "Iran war / economic collapse", "Extreme"),
    ("Natural News", "https://www.naturalnews.com/rss", "rss", "Fringe", "Iran war / health / collapse", "Extreme"),
    ("Drop Site News", "https://dropsitenews.com/feed", "rss", "Fringe", "Iran war / energy", "Moderate"),
    ("Kardamow Substack", "https://kardamow.substack.com/feed", "rss", "Fringe", "Energy geopolitics", "Low-moderate"),
    ("Energy Geopolitics & Statecraft", "https://energygeopoliticsandstatecraft.substack.com/feed", "rss", "Fringe", "Energy geopolitics", "Low-moderate"),
    ("JKempEnergy", "https://jkempenergy.com/feed", "rss", "Fringe", "Energy research", "Low"),
    ("Ed Zitron", "https://edzitron.com/feed", "rss", "Fringe", "AI bubble", "Moderate"),
    ("Luminix AI Cycle Monitor", "https://useluminix.com/feed", "rss", "Fringe", "AI bubble", "Low-moderate"),
    ("Culper Research", "https://culperresearch.com/feed", "rss", "Fringe", "AI short thesis", "Moderate"),
    ("Organized Money Podcast", "https://organizedmoney.fm/feed", "rss", "Fringe", "AI bubble", "Moderate"),
    ("CounterPunch", "https://counterpunch.org/feed", "rss", "Fringe", "AI bubble / economics", "Moderate"),
    ("The Blaze", "https://theblaze.com/feed", "rss", "Fringe", "AI bubble", "Moderate"),
    ("Common Dreams", "https://commondreams.org/feed", "rss", "Fringe", "AI bubble", "Moderate"),
    # --- OSINT / live trackers ---
    ("Straits.live (Hormuz)", "https://straits.live/feed.xml", "rss", "OSINT", "Hormuz", None),
    ("Chokepoint Data", "https://chokepointdata.com/feed", "rss", "OSINT", "Hormuz", None),
    ("Crude Signal Oil Wire", "https://crudesignal.io/feed", "rss", "OSINT", "Hormuz", None),
    ("Eagle Intelligence", "https://eagleintelmari.com/feed", "rss", "OSINT", "Hormuz", None),
    ("World Monitor", "https://worldmonitor.app/feed", "rss", "OSINT", "Military", None),
    ("USvsIRAN.com", "https://usvsiran.com/feed", "rss", "OSINT", "Iran", None),
    ("SignalCockpit", "https://signalcockpit.com/feed", "rss", "OSINT", "Iran", None),
    ("Iran Monitor", "https://iranmonitor.org/feed", "rss", "OSINT", "Iran", None),
    ("LiveUAMap", "https://liveuamap.com/feed", "rss", "OSINT", "Conflict", None),
    ("Global Conflict Awareness", "https://globalconflictawareness.com/feed", "rss", "OSINT", "Iran", None),
    ("Conflicts.app", "https://conflicts.app/feed", "rss", "OSINT", "Conflict", None),
    ("Factline Events", "https://factline.io/feed", "rss", "OSINT", "OSINT", None),
    # --- Iran state / semi-state ---
    ("IRNA English", "https://en.irna.ir/rss", "rss", "Iran", "Iran state", None),
    ("Tasnim News", "https://tasnimnews.com/fa/rss/feed/0/8/0/", "rss", "Iran", "Iran state", None),
    ("Mehr News", "https://mehrnews.com/rss", "rss", "Iran", "Iran state", None),
    ("Tehran Times", "https://tehrantimes.com/rss", "rss", "Iran", "Iran state", None),
    ("Press TV Politics", "https://presstv.ir/Section/10101", "rss", "Iran", "Iran state", None),
    ("ISNA", "https://isna.ir/rss", "rss", "Iran", "Iran state", None),
    ("Khabaronline", "https://khabaronline.ir/rss", "rss", "Iran", "Iran state", None),
    ("Financial Tribune", "https://financialtribune.com/national", "rss", "Iran", "Iran economy", None),
    ("Iran Front Page", "https://ifpnews.com/feed", "rss", "Iran", "Iran independent", None),
    ("Iran Primer (USIP)", "https://iranprimer.usip.org/rss.xml", "rss", "Iran", "Iran analysis", None),
    # --- Cyber ---
    ("CrowdStrike Blog", "https://www.crowdstrike.com/blog/feed/", "rss", "Cyber", "Cyber", None),
    ("Krebs on Security", "https://krebsonsecurity.com/feed/", "rss", "Cyber", "Cyber", None),
    ("The Hacker News", "https://feeds.feedburner.com/TheHackerNews", "rss", "Cyber", "Cyber", None),
    ("Ars Technica Security", "https://feeds.arstechnica.com/arstechnica/index", "rss", "Cyber", "Cyber", None),
    ("TechCrunch Security", "https://techcrunch.com/category/security/feed/", "rss", "Cyber", "Cyber", None),
    ("Group-IB Blog", "https://www.group-ib.com/blog/rss/", "rss", "Cyber", "Cyber", None),
]

SAMPLE_SOURCES = [
    ("NATO Official Statement", "Government Statement"),
    ("EU Council Publication", "Official Publication"),
    ("Reuters", "Major Media"),
    ("AP News", "Major Media"),
    ("BBC News", "Major Media"),
    ("Jane's Defence", "Expert Analysis"),
    ("IISS Analysis", "Expert Analysis"),
    ("OSINT Aggregate", "Open-Source Intelligence"),
    ("Defense One", "Major Media"),
    ("Ministry of Defence", "Military Report"),
    ("Social Monitoring", "Social Media"),
    ("Forum Rumor Mill", "Rumour"),
]

SAMPLE_EVENTS = [
    ("Undersea cable security concerns raised in North Sea", "Critical Infrastructure Vulnerability", ["Baltics", "Finland"], "HIGH", "Major Media",
     "Officials warn that undersea communications cables in the Baltic and North Sea remain vulnerable to deliberate interference.",
     "Evidence: Multiple government statements over past quarter. Analyst note: correlation with prior ship-anchoring incidents."),
    ("Large-scale cyber exercise conducted across Eastern Flank", "Cyber Operations", ["Poland", "Baltics"], "HIGH", "Military Report",
     "NATO allies completed a coordinated cyber defence exercise simulating attacks on critical infrastructure.",
     "Evidence: Official military publication. Analyst note: indicates growing attention to cyber resilience."),
    ("Energy supply route diversification accelerates", "Dependency Risk", ["Finland", "Romania"], "MEDIUM", "Expert Analysis",
     "States accelerate efforts to diversify energy supply routes away from single-source dependency.",
     "Evidence: Expert analysis. Analyst note: resilience-building, but dependency risk remains elevated."),
    ("Air defence ammunition production targets raised", "Air Defence Scarcity", ["Poland"], "HIGH", "Official Publication",
     "Allied defence ministries announce increased air defence ammunition production targets for next fiscal year.",
     "Evidence: Official publication. Analyst note: counters air defence scarcity trend."),
    ("Multi-theatre readiness posture reviewed", "Multi-Theatre Stress", ["Ukraine", "Middle East"], "HIGH", "Intelligence Assessment",
     "Senior commanders review force readiness posture across multiple concurrent theatres.",
     "Evidence: Intelligence assessment. Analyst note: indicates recognition of multi-theatre strain."),
    ("Naval activity observed in Black Sea approaches", "Eastern Flank Pressure", ["Black Sea", "Ukraine"], "MEDIUM", "Open-Source Intelligence",
     "Open-source trackers report increased naval movement in Black Sea approaches.",
     "Evidence: OSINT imagery. Analyst note: moderate confidence, corroborating watch."),
    ("Information operation targeting allied cohesion detected", "Information Warfare", ["Baltics", "Poland"], "MEDIUM", "Intelligence Assessment",
     "Coordinated inauthentic amplification detected targeting allied cohesion narratives.",
     "Evidence: Intelligence assessment. Analyst note: classic information warfare pattern."),
    ("Regional diplomatic consultations on escalation management", "Middle East Escalation", ["Middle East", "Persian Gulf"], "HIGH", "Government Statement",
     "Senior officials hold consultations focused on escalation management frameworks.",
     "Evidence: Government statement. Analyst note: de-escalatory signal."),
    ("Strategic autonomy industrial base investment announced", "Strategic Autonomy", ["Poland", "Finland"], "HIGH", "Official Publication",
     "Major investment package announced to expand domestic defence industrial base capacity.",
     "Evidence: Official publication. Analyst note: strengthens resilience side."),
    ("Financial sanctions enforcement review completed", "Financial Resilience", ["Russia"], "MEDIUM", "Major Media",
     "Review of financial sanctions enforcement pathways and residual leakages published.",
     "Evidence: Major media. Analyst note: financial resilience dimension."),
    ("Territorial defence exercise completed in Finland", "Territorial Defence", ["Finland"], "HIGH", "Military Report",
     "Large-scale territorial defence exercise concluded, validating mobilisation procedures.",
     "Evidence: Military report. Analyst note: territorial defence resilience."),
    ("NATO force model adaptation progress reported", "NATO Adaptation", ["Baltics", "Poland"], "HIGH", "Official Publication",
     "Progress reported on adaptation of NATO force model to higher readiness requirements.",
     "Evidence: Official publication. Analyst note: institutional adaptation."),
    ("Indo-Pacific maritime exercise participation announced", "Indo-Pacific Competition", ["South China Sea"], "MEDIUM", "Government Statement",
     "European partners announce participation in Indo-Pacific maritime presence exercise.",
     "Evidence: Government statement. Analyst note: strategic signalling."),
    ("Korean Peninsula missile activity monitored", "Korean Peninsula Tension", ["Korean Peninsula"], "MEDIUM", "Open-Source Intelligence",
     "Launch activity monitored; assessment focuses on pattern rather than single event.",
     "Evidence: OSINT. Analyst note: watch item."),
    ("Arctic infrastructure hardening programme extended", "Critical Infrastructure Vulnerability", ["Arctic"], "MEDIUM", "Official Publication",
     "Arctic infrastructure hardening programme extended for another funding cycle.",
     "Evidence: Official publication. Analyst note: resilience counter-measure."),
    ("Strategic overstretch indicators assessed in defence planning", "Strategic Overstretch", ["Ukraine"], "MEDIUM", "Expert Analysis",
     "Analysts assess indicators of strategic overstretch across concurrent commitments.",
     "Evidence: Expert analysis. Analyst note: early-warning indicator."),
    ("Trust architecture survey shows variance across allies", "Trust Architecture", ["Baltics", "Poland"], "MEDIUM", "Expert Analysis",
     "Survey data shows variance in public trust architecture across allied populations.",
     "Evidence: Expert analysis. Analyst note: societal resilience dimension."),
    ("East median sea corridor security enhanced", "Eastern Flank Pressure", ["Black Sea"], "HIGH", "Military Report",
     "Enhanced security measures announced for eastern median sea corridor traffic.",
     "Evidence: Military report. Analyst note: direct flank pressure indicator."),
]


async def run_seed():
    async with AsyncSessionLocal() as db:
        # Confidence levels
        existing_cl = await db.execute(select(ConfidenceLevel).limit(1))
        if existing_cl.scalar_one_or_none() is None:
            for name, rank, desc in CONFIDENCE_LEVELS:
                db.add(ConfidenceLevel(name=name, rank=rank, description=desc))
            await db.flush()

        # Source types
        existing_st = await db.execute(select(SourceType).limit(1))
        if existing_st.scalar_one_or_none() is None:
            type_map = {}
            for name, conf in SOURCE_TYPES:
                st = SourceType(name=name, default_confidence=conf)
                db.add(st)
                await db.flush()
                type_map[name] = st
        else:
            st_result = await db.execute(select(SourceType))
            type_map = {s.name: s for s in st_result.scalars()}

        # Sources
        existing_src = await db.execute(select(Source).limit(1))
        if existing_src.scalar_one_or_none() is None:
            for name, st_name in SAMPLE_SOURCES:
                st = type_map.get(st_name)
                if st:
                    db.add(Source(name=name, source_type_id=st.id))
            await db.flush()

        # Categories
        existing_cat = await db.execute(select(Category).limit(1))
        if existing_cat.scalar_one_or_none() is None:
            _pct = {"HIGH": 85.0, "MEDIUM": 60.0, "LOW": 35.0}
            cat_map = {}
            for name, side, score, conf, trend in CATEGORIES:
                c = Category(
                    name=name, side=side, current_score=score, confidence=conf, trend=trend,
                    description=f"Tracks {name} indicators.",
                    confidence_pct=_pct.get(conf, 60.0),
                    corroboration_count=3 if conf == "HIGH" else (2 if conf == "MEDIUM" else 1),
                )
                db.add(c)
                await db.flush()
                cat_map[name] = c
        else:
            cat_result = await db.execute(select(Category))
            cat_map = {c.name: c for c in cat_result.scalars()}

        # Regions
        existing_reg = await db.execute(select(Region).limit(1))
        if existing_reg.scalar_one_or_none() is None:
            reg_map = {}
            for name, lat, lng in REGIONS:
                r = Region(name=name, lat=lat, lng=lng)
                db.add(r)
                await db.flush()
                reg_map[name] = r
        else:
            reg_result = await db.execute(select(Region))
            reg_map = {r.name: r for r in reg_result.scalars()}

        # Confidence level lookup by name
        cl_result = await db.execute(select(ConfidenceLevel))
        cl_map = {c.name: c for c in cl_result.scalars()}

        # Source lookup
        src_result = await db.execute(select(Source).options(selectinload(Source.source_type)))
        src_by_type: dict[str, list] = {}
        for s in src_result.scalars():
            src_by_type.setdefault(s.source_type.name, []).append(s)

        # Events
        existing_ev = await db.execute(select(Event).limit(1))
        if existing_ev.scalar_one_or_none() is None:
            today = date(2026, 10, 21)
            for i, (title, cat_name, reg_names, conf_name, st_name, summary, notes) in enumerate(SAMPLE_EVENTS):
                cl = cl_map.get(conf_name, cl_map.get("MEDIUM"))
                candidates = src_by_type.get(st_name) or src_by_type.get("Major Media") or list(src_by_type.values())[0]
                source = random.choice(candidates)
                st = source.source_type
                event = Event(
                    entry_number=i + 1,
                    title=title,
                    event_date=today - timedelta(days=i * 3),
                    source_id=source.id,
                    source_type_id=st.id,
                    confidence_level_id=cl.id,
                    summary=summary,
                    evidence_notes=notes,
                    analyst_notes="",
                    status=derive_status(st.name, cl.name),
                    severity="HIGH" if cl.name == "HIGH" else ("LOW" if cl.name == "LOW" else "MEDIUM"),
                )
                db.add(event)
                await db.flush()

                cat = cat_map.get(cat_name)
                if cat:
                    db.add(EventCategory(event_id=event.id, category_id=cat.id, impact_delta=0.3))
                for rn in reg_names:
                    r = reg_map.get(rn)
                    if r:
                        db.add(EventRegion(event_id=event.id, region_id=r.id))

            await db.flush()

        # Preps (owner's inventory — 3-stage roadmap)
        existing_prep = await db.execute(select(Prep).limit(1))
        if existing_prep.scalar_one_or_none() is None:
            for name, cat, qty, unit, minq, prio, notes, stage in SAMPLE_PREPS:
                db.add(Prep(name=name, category=cat, quantity=qty, unit=unit,
                            min_quantity=minq, priority=prio, notes=notes, stage=stage))
            await db.flush()

        # OSINT scrape sources
        existing_scrape = await db.execute(select(ScrapeSource).limit(1))
        if existing_scrape.scalar_one_or_none() is None:
            for name, url, kind, tier in SAMPLE_SOURCES_FEED:
                db.add(ScrapeSource(
                    name=name, url=url, kind=kind, tier=tier,
                    base_confidence=TIER_CONFIDENCE.get(tier, "LOW"), enabled=True,
                ))
            await db.flush()

        # Power-outage sources — incremental: add any not already present (preserves
        # existing rows / data; only new sources such as the EU list are inserted).
        existing_names = {
            s.name for s in (await db.execute(select(PowerOutageSource))).scalars()
        }
        for name, country, region, city, url, kind in SAMPLE_OUTAGE_SOURCES:
            if name in existing_names:
                continue
            db.add(PowerOutageSource(
                name=name, country=country, region=region, city=city,
                url=url, kind=kind, enabled=True,
            ))
        await db.flush()

        # Cyber attack sources — incremental
        existing_cyber = {
            s.name for s in (await db.execute(select(CyberAttackSource))).scalars()
        }
        for name, url, kind in SAMPLE_CYBER_SOURCES:
            if name in existing_cyber:
                continue
            db.add(CyberAttackSource(name=name, url=url, kind=kind, enabled=True))
        await db.flush()

        # Feed tab speculation sources — incremental
        existing_feed = {
            s.name for s in (await db.execute(select(SpeculationSource))).scalars()
        }
        for name, url, kind, category, topic, fringe in SAMPLE_FEED_SOURCES:
            if name in existing_feed:
                continue
            db.add(SpeculationSource(
                name=name, url=url, kind=kind, category=category,
                topic=topic, fringe_level=fringe, enabled=True,
            ))
        await db.flush()

        await db.commit()
        print("Seed complete.")
