// Complete TypeScript interfaces mirroring the backend Pydantic schemas.

export type Side = "threat" | "resilience";
export type Trend = "UP" | "DOWN" | "STABLE";
export type Confidence = "LOW" | "MEDIUM" | "HIGH";
export type EventStatus =
  | "CONFIRMED"
  | "REPORTED"
  | "CLAIMED"
  | "SPECULATED"
  | "UNVERIFIED";
export type OverallStatus = "GREEN" | "YELLOW" | "ORANGE" | "RED";
export type ProposalStatus = "PENDING" | "APPROVED" | "REJECTED";

export interface Category {
  id: number;
  name: string;
  description: string | null;
  side: Side;
  current_score: number;
  confidence: Confidence;
  trend: Trend;
  confidence_pct: number;
  corroboration_count: number;
  updated_at: string;
}

export interface Region {
  id: number;
  name: string;
  lat: number;
  lng: number;
}

export interface ConfidenceLevel {
  id: number;
  name: Confidence;
  rank: number;
  description: string | null;
}

export interface SourceType {
  id: number;
  name: string;
  default_confidence: Confidence;
}

export interface Source {
  id: number;
  name: string;
  source_type_id: number;
  url: string | null;
  reliability_note: string | null;
  source_type?: SourceType;
}

export interface EventCategory {
  category_id: number;
  impact_delta: number;
  category: Category;
}

export interface EventRegion {
  region_id: number;
  region: Region;
}

export interface EventItem {
  id: number;
  entry_number: number;
  title: string;
  event_date: string;
  summary: string;
  evidence_notes: string | null;
  analyst_notes: string | null;
  status: EventStatus;
  severity: string;
  created_at: string;
  source: Source;
  source_type: SourceType;
  confidence_level: ConfidenceLevel;
  category_links: EventCategory[];
  region_links: EventRegion[];
  attachments: Attachment[];
}

export interface EventCreate {
  title: string;
  event_date: string;
  source_id: number;
  source_type_id: number;
  confidence_level_id: number;
  summary: string;
  evidence_notes?: string;
  analyst_notes?: string;
  status?: EventStatus;
  category_ids: number[];
  region_ids: number[];
  impact_deltas?: Record<string, number>;
}

export interface EventCreateMinimal {
  event_date: string;
  title: string;
  summary: string;
  source_name?: string;
}

export interface EventAIOut {
  event: EventItem;
  ai_confidence: Confidence;
  ai_categories: string[];
  ai_regions: string[];
  ai_source_type: string;
  proposals_created: number;
  ai_available: boolean;
}

export interface ExecutiveSummary {
  threat_score: number;
  resilience_score: number;
  threat_trend: Trend;
  resilience_trend: Trend;
  strategic_surprise_index: number;
  event_density_index: number;
  strategic_friction_index: number;
  friction_signals: Record<string, number>;
  overall_status: OverallStatus;
}

export interface CategoryScore {
  id: number;
  name: string;
  side: Side;
  current_score: number;
  peak_score: number;
  confidence: Confidence;
  trend: Trend;
  event_count: number;
  confidence_pct: number;
  corroboration_count: number;
  last_occurrence: string | null;
}

export interface HeatmapCell {
  category: string;
  side: Side;
  weeks: { week: string; count: number }[];
}

export interface TimelinePoint {
  date: string;
  events: number;
}

export interface RadarPoint {
  category: string;
  side: Side;
  score: number;
}

export interface HistogramBucket {
  bucket: string;
  count: number;
  threat: number;
  resilience: number;
}

export interface ConfidenceDistribution {
  level: string;
  count: number;
}

export interface DashboardData {
  summary: ExecutiveSummary;
  threat_categories: CategoryScore[];
  resilience_categories: CategoryScore[];
  heatmap: HeatmapCell[];
  timeline: TimelinePoint[];
  radar: RadarPoint[];
  histogram: HistogramBucket[];
  confidence_distribution: ConfidenceDistribution[];
  flashpoints: Flashpoint[];
}

export interface Flashpoint {
  region: string;
  event_count: number;
  top_categories: { name: string; score: number }[];
  intensity: number;
}

export interface Attachment {
  id: number;
  filename: string;
  content_type: string;
  path: string;
  uploaded_at: string;
}

export interface AIProposal {
  id: number;
  event_id: number | null;
  category_id: number | null;
  proposed_changes_json: string;
  rationale: string | null;
  status: ProposalStatus;
  created_at: string;
}

export interface AICapabilityResponse {
  raw: string;
  proposals: Record<string, unknown>[];
}

export interface WatchlistOut {
  markdown: string;
}

export interface CascadeOut {
  markdown: string;
}

export interface Settings {
  lmstudio_base_url: string;
  lmstudio_model: string;
  run_to_store_threshold: number;
  auto_approve: boolean;
}

export interface SettingsUpdate {
  lmstudio_base_url?: string;
  lmstudio_model?: string;
  run_to_store_threshold?: number;
  auto_approve?: boolean;
}

export interface Prep {
  id: number;
  name: string;
  category: string;
  stage: number;
  quantity: number;
  unit: string;
  min_quantity: number;
  priority: string;
  notes: string | null;
  updated_at: string;
}

export interface PrepInput {
  name: string;
  category: string;
  stage: number;
  quantity: number;
  unit: string;
  min_quantity: number;
  priority: string;
  notes?: string;
}

export interface PrepChatMessage {
  role: "user" | "assistant";
  content: string;
}

export interface PrepChatOut {
  reply: string;
}

export interface RunToStoreResult {
  reached: boolean;
  threshold: number;
  current_level: number;
  status: string;
  suggestions: string;
  low_items: Prep[];
}

export interface HouseholdReadiness {
  household_size: number;
  economic: number | null;
  infrastructure: number | null;
  threat_environment: number | null;
  household_readiness: number | null;
}

export interface ScrapeSource {
  id: number;
  name: string;
  url: string;
  kind: string;
  tier: string;
  base_confidence: string;
  enabled: boolean;
  last_fetched: string | null;
}

export interface ScrapedItem {
  id: number;
  source_id: number;
  title: string;
  url: string | null;
  summary: string | null;
  published: string | null;
  ingested: boolean;
  ingested_event_id: number | null;
  fetched_at: string;
  topics: string[];
}

export interface ScrapeRunResult {
  sources: number;
  new_items: number;
  errors: string[];
}

export interface IngestAllResult {
  attempted: number;
  succeeded: number;
  failed: number;
  errors: string[];
}

export interface OutageSource {
  id: number;
  name: string;
  country: string;
  region: string | null;
  city: string | null;
  url: string;
  kind: string;
  enabled: boolean;
  last_fetched: string | null;
}

export interface Outage {
  id: number;
  source_id: number;
  country: string;
  region: string | null;
  city: string | null;
  outage_type: "SCHEDULED" | "UNSCHEDULED";
  title: string;
  details: string | null;
  url: string | null;
  customers_affected: number | null;
  ingested: boolean;
  ingested_event_id: number | null;
  scraped_at: string;
}

export interface OutageLocations {
  countries: string[];
  regions: Record<string, string[]>;
  cities: Record<string, string[]>;
}

export interface OutageScrapeResult {
  sources: number;
  new_outages: number;
  errors: string[];
  ingested: number;
}

export interface CyberSource {
  id: number;
  name: string;
  url: string;
  kind: string;
  enabled: boolean;
  last_fetched: string | null;
}

export interface CyberAttack {
  id: number;
  source_id: number;
  title: string;
  summary: string | null;
  url: string | null;
  severity: "CRITICAL" | "HIGH" | "MEDIUM" | "LOW";
  attack_type: string;
  ingested: boolean;
  ingested_event_id: number | null;
  scraped_at: string;
}

export interface CyberScrapeResult {
  sources: number;
  new_attacks: number;
  errors: string[];
  ingested: number;
}

export interface BriefingData {
  title: string;
  executive_summary: string;
  major_changes: string[];
  rising_risks: string[];
  rising_resilience: string[];
  watch_list: string[];
  strategic_assessment: string;
  flashpoints: Flashpoint[];
  events: { title: string; date: string; status: string }[];
}

export interface ReportItem {
  id: number;
  report_type: string;
  content_json: string;
  format: string;
  created_at: string;
}

export interface AIHealth {
  connected: boolean;
  models: string[];
  error?: string;
}

export interface EventFilters {
  category_id?: number;
  region_id?: number;
  confidence?: string;
  source_type_id?: number;
  date_from?: string;
  date_to?: string;
  limit?: number;
  offset?: number;
}
