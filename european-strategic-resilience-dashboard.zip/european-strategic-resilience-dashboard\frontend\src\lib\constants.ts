import type { OverallStatus, Side } from "./types";

export const API_URL =
  process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

export const STATUS_COLORS: Record<OverallStatus, string> = {
  GREEN: "#22c55e",
  YELLOW: "#eab308",
  ORANGE: "#f97316",
  RED: "#ef4444",
};

export const STATUS_LABELS: Record<OverallStatus, string> = {
  GREEN: "Green — Baseline",
  YELLOW: "Yellow — Watch",
  ORANGE: "Orange — Elevated Concern",
  RED: "Red — Critical",
};

export const CONFIDENCE_COLORS: Record<string, string> = {
  HIGH: "#22c55e",
  MEDIUM: "#eab308",
  LOW: "#94a3b8",
};

export const TREND_COLORS: Record<string, string> = {
  UP: "#ef4444",
  DOWN: "#22c55e",
  STABLE: "#8494ab",
};

export const STATUS_BADGES: Record<string, { color: string; label: string }> = {
  CONFIRMED: { color: "#22c55e", label: "Confirmed" },
  REPORTED: { color: "#3b82f6", label: "Reported" },
  CLAIMED: { color: "#eab308", label: "Claimed" },
  SPECULATED: { color: "#f97316", label: "Speculated" },
  UNVERIFIED: { color: "#94a3b8", label: "Unverified" },
};

export const SIDE_COLORS: Record<Side, string> = {
  threat: "#ef4444",
  resilience: "#22c55e",
};

export const CONFIDENCE_SCALE = [
  {
    level: "HIGH",
    sources: "Government statements, military reports, intelligence assessments, official publications",
  },
  {
    level: "MEDIUM",
    sources: "Major media, expert analysis, open-source intelligence",
  },
  {
    level: "LOW",
    sources: "Social media, rumours, unverified claims",
  },
];

export const AI_CAPABILITIES = [
  { key: "summarize", label: "Summarize All Events" },
  { key: "trend_changes", label: "Identify Trend Changes" },
  { key: "suggest_scores", label: "Suggest Score Adjustments" },
  { key: "contradictions", label: "Highlight Contradictory Evidence" },
  { key: "daily", label: "Generate Daily Briefing" },
  { key: "weekly", label: "Generate Weekly Report" },
  { key: "executive", label: "Generate Executive Assessment" },
] as const;

// OSINT source tiers -> base confidence (score-impact weight: HIGH 100% / MED 50% / LOW 25%).
export const OSINT_TIERS = [
  "Tier 1 - News Wires",
  "Tier 2 - Geopolitical Intel",
  "NATO / Defence",
  "Sanctions / Financial Warfare",
  "Cyber Threat Intelligence",
  "Maritime / Shipping",
  "Energy Security",
  "Infrastructure & Resilience",
  "Space & Satellite",
  "OSINT / Early Warning",
] as const;

export const TIER_COLORS: Record<string, string> = {
  "Tier 1 - News Wires": "#22c55e",
  "Tier 2 - Geopolitical Intel": "#22c55e",
  "NATO / Defence": "#22c55e",
  "Sanctions / Financial Warfare": "#22c55e",
  "Cyber Threat Intelligence": "#eab308",
  "Maritime / Shipping": "#eab308",
  "Energy Security": "#eab308",
  "Infrastructure & Resilience": "#eab308",
  "Space & Satellite": "#eab308",
  "OSINT / Early Warning": "#94a3b8",
};
