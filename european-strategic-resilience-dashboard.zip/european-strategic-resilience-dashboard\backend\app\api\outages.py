"""Power outages: manage location-scoped sources, scrape, classify scheduled vs
unscheduled, list, and ingest an outage as an entry."""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.database import get_db
from app.models import PowerOutage, PowerOutageSource
from app.schemas import (
    OutageLocations, OutageOut, OutageScrapeRequest, OutageScrapeResult,
    OutageSourceCreate, OutageSourceOut
)
from app.services.outage_scraper import scrape_outages
from app.services.scraper import SSRFError, validate_public_url

router = APIRouter(prefix="/outages", tags=["outages"])


@router.get("/sources", response_model=list[OutageSourceOut])
async def list_sources(db: AsyncSession = Depends(get_db), country: str | None = None):
    q = select(PowerOutageSource).order_by(PowerOutageSource.country, PowerOutageSource.region, PowerOutageSource.city)
    if country:
        q = q.where(PowerOutageSource.country == country)
    result = await db.execute(q)
    return list(result.scalars().all())


@router.post("/sources", response_model=OutageSourceOut, status_code=201)
async def create_source(payload: OutageSourceCreate, db: AsyncSession = Depends(get_db)):
    try:
        validate_public_url(payload.url)
    except SSRFError as e:
        raise HTTPException(status_code=400, detail=f"Invalid URL: {e}")
    if payload.kind not in ("rss", "html"):
        raise HTTPException(status_code=400, detail="kind must be 'rss' or 'html'")
    src = PowerOutageSource(**payload.model_dump())
    db.add(src)
    await db.commit()
    await db.refresh(src)
    return src


@router.delete("/sources/{source_id}", status_code=204)
async def delete_source(source_id: int, db: AsyncSession = Depends(get_db)):
    src = await db.get(PowerOutageSource, source_id)
    if not src:
        raise HTTPException(status_code=404, detail="Source not found")
    await db.delete(src)
    await db.commit()


@router.get("/sources/locations", response_model=OutageLocations)
async def locations(db: AsyncSession = Depends(get_db)):
    """Distinct countries/regions/cities for the cascading Country→State→City picker."""
    result = await db.execute(select(PowerOutageSource))
    rows = list(result.scalars().all())
    countries = sorted({r.country for r in rows})
    regions: dict[str, set[str]] = {}
    cities: dict[str, set[str]] = {}
    for r in rows:
        if r.region:
            regions.setdefault(r.country, set()).add(r.region)
        key = f"{r.country}|{r.region or ''}"
        if r.city:
            cities.setdefault(key, set()).add(r.city)
    return OutageLocations(
        countries=countries,
        regions={k: sorted(v) for k, v in regions.items()},
        cities={k: sorted(v) for k, v in cities.items()},
    )


@router.post("/scrape", response_model=OutageScrapeResult)
async def scrape(payload: OutageScrapeRequest, db: AsyncSession = Depends(get_db)):
    """Scrape outage sources for a chosen Country / State / City (or all if blank)."""
    q = select(PowerOutageSource).where(PowerOutageSource.enabled == True)  # noqa: E712
    if payload.country:
        q = q.where(PowerOutageSource.country == payload.country)
    if payload.region:
        q = q.where(PowerOutageSource.region == payload.region)
    if payload.city:
        q = q.where(PowerOutageSource.city == payload.city)
    result = await db.execute(q)
    sources = list(result.scalars().all())
    if not sources:
        return OutageScrapeResult(sources=0, new_outages=0, errors=["No sources match that location"])
    out = await scrape_outages(sources, db)

    # Auto-ingest newly discovered outages (bounded so one request can't run away).
    AUTO_INGEST_CAP = 12
    new_ids = await _recent_outage_ids(db, limit=AUTO_INGEST_CAP)
    ingested = 0
    ingest_errors: list[str] = []
    for oid in new_ids:
        try:
            await _ingest_outage(db, oid)
            ingested += 1
        except Exception as e:  # noqa: BLE001 - continue per item
            ingest_errors.append(f"ingest #{oid}: {e}")
            await db.rollback()
    out["errors"] = list(out.get("errors", [])) + ingest_errors
    return OutageScrapeResult(
        sources=out["sources"], new_outages=out["new_outages"],
        errors=out["errors"], ingested=ingested,
    )


@router.get("", response_model=list[OutageOut])
async def list_outages(
    db: AsyncSession = Depends(get_db),
    country: str | None = None,
    region: str | None = None,
    city: str | None = None,
    outage_type: str | None = None,
    limit: int = 100,
):
    q = select(PowerOutage).order_by(PowerOutage.scraped_at.desc()).limit(limit)
    if country:
        q = q.where(PowerOutage.country == country)
    if region:
        q = q.where(PowerOutage.region == region)
    if city:
        q = q.where(PowerOutage.city == city)
    if outage_type and outage_type in ("SCHEDULED", "UNSCHEDULED"):
        q = q.where(PowerOutage.outage_type == outage_type)
    result = await db.execute(q)
    return list(result.scalars().all())


async def _ingest_outage(db: AsyncSession, outage_id: int) -> dict:
    """Convert one outage into an AI-classified entry. Raises on failure."""
    from datetime import date as date_cls
    from app.api.events import create_event_with_ai
    from app.schemas import EventCreateMinimal

    # Eager-load source to avoid an async lazy-load (MissingGreenlet) when reading .name
    result = await db.execute(
        select(PowerOutage)
        .options(selectinload(PowerOutage.source))
        .where(PowerOutage.id == outage_id)
    )
    outage = result.scalar_one_or_none()
    if not outage:
        raise HTTPException(status_code=404, detail="Outage not found")
    if outage.ingested:
        raise HTTPException(status_code=400, detail="Already ingested")

    location = ", ".join(x for x in [outage.city, outage.region, outage.country] if x)
    summary = f"[{outage.outage_type}] {outage.title}. Location: {location}."
    if outage.details:
        summary += f" {outage.details}"
    if outage.url:
        summary += f"\nSource URL: {outage.url}"

    payload = EventCreateMinimal(
        event_date=date_cls.today(),
        title=f"Power outage — {location}" if location else f"Power outage — {outage.title[:60]}",
        summary=summary,
        source_name=outage.source.name if outage.source else "Power Outage Feed",
        min_confidence="MEDIUM",  # grid/utility feeds are at least medium
    )
    ev_out = await create_event_with_ai(payload, db)
    outage.ingested = True
    outage.ingested_event_id = ev_out.event.id
    await db.commit()
    return {
        "ingested": True,
        "event_id": ev_out.event.id,
        "entry_number": ev_out.event.entry_number,
        "ai_confidence": ev_out.ai_confidence,
        "ai_categories": ev_out.ai_categories,
    }


async def _recent_outage_ids(db: AsyncSession, limit: int = 12) -> list[int]:
    """Newest uningested outage ids (for auto-ingest after a scrape)."""
    result = await db.execute(
        select(PowerOutage.id)
        .where(PowerOutage.ingested == False)  # noqa: E712
        .order_by(PowerOutage.scraped_at.desc())
        .limit(limit)
    )
    return [row[0] for row in result.all()]


@router.post("/{outage_id}/ingest")
async def ingest(outage_id: int, db: AsyncSession = Depends(get_db)):
    """Convert an outage into a fully AI-classified entry."""
    return await _ingest_outage(db, outage_id)
