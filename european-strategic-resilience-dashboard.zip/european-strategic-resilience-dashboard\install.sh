#!/usr/bin/env bash
#
# European Strategic Resilience Dashboard — Linux/macOS installer.
#
# Self-documenting one-command installer. Checks prerequisites, prepares .env,
# builds + starts the stack with Docker Compose, waits for health, prints URLs.
#
# Prerequisites:
#   1. Docker + Docker Compose (REQUIRED)  — https://docs.docker.com/get-docker/
#   2. LM Studio (OPTIONAL)                — for AI features; run on :1234 with a model loaded
#   3. Internet (OPTIONAL)                 — for map tiles + OSINT feed scraping
#
# Usage:
#   chmod +x install.sh && ./install.sh
#   ./install.sh --reset     # wipe DB volume and re-seed sample data
#   ./install.sh --no-build  # reuse existing images
#
set -euo pipefail

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
RESET_DATA=0
NO_BUILD=0
for arg in "$@"; do
  case "$arg" in
    --reset)    RESET_DATA=1 ;;
    --no-build) NO_BUILD=1 ;;
  esac
done

step()  { printf '\n==> %s\n' "$1"; }
ok()    { printf '    [OK] %s\n' "$1"; }
warn()  { printf '    [!!] %s\n' "$1"; }
bad()   { printf '    [X ] %s\n' "$1"; }

echo "============================================================"
echo "  European Strategic Resilience Dashboard — Installer"
echo "  Strategic early-warning / resilience tracking (NOT a prediction engine)"
echo "============================================================"

# --- Step 1: Docker + Compose ---
step "Checking prerequisite: Docker"
if ! command -v docker >/dev/null 2>&1; then
  bad "Docker is not installed."
  echo "    Install: https://docs.docker.com/get-docker/  then re-run."
  exit 1
fi
if ! docker info >/dev/null 2>&1; then
  bad "Docker daemon is not running. Start Docker (or add yourself to the 'docker' group) and re-run."
  exit 1
fi
ok "Docker engine is running."
if ! docker compose version >/dev/null 2>&1; then
  bad "Docker Compose plugin not found. Install docker-compose-plugin."
  exit 1
fi
ok "Docker Compose is available."

# --- Step 2: LM Studio (optional) ---
step "Checking optional prerequisite: LM Studio (AI features)"
if command -v curl >/dev/null 2>&1 && curl -fsS -m 3 http://localhost:1234/v1/models >/dev/null 2>&1; then
  ok "LM Studio reachable on port 1234 (AI features enabled)."
else
  warn "LM Studio not detected on http://localhost:1234."
  echo "    App still runs; AI features show 'offline' until LM Studio is started on :1234."
fi

# --- Step 3: .env ---
step "Preparing configuration (.env)"
if [ ! -f "$PROJECT_ROOT/.env" ]; then
  cp "$PROJECT_ROOT/.env.example" "$PROJECT_ROOT/.env"
  ok "Created .env from .env.example."
else
  ok ".env already exists (left untouched)."
fi

# --- Step 4: optional reset ---
if [ "$RESET_DATA" -eq 1 ]; then
  step "Resetting database (down -v) — sample data re-seeded on next start"
  (cd "$PROJECT_ROOT" && docker compose down -v)
  ok "Database volume removed."
fi

# --- Step 5: build + start ---
step "Building and starting the stack (Postgres + backend + frontend)"
cd "$PROJECT_ROOT"
if [ "$NO_BUILD" -eq 1 ]; then
  docker compose up -d
else
  docker compose up -d --build
fi
ok "Containers started."

# --- Step 6: wait for health ---
step "Waiting for services to become healthy"
backend_up=0; frontend_up=0
for i in $(seq 1 18); do
  sleep 5
  if [ "$backend_up" -eq 0 ]  && curl -fsS -m 5 http://localhost:8000/ >/dev/null 2>&1; then backend_up=1; fi
  if [ "$frontend_up" -eq 0 ] && curl -fsS -m 5 http://localhost:3000 >/dev/null 2>&1; then frontend_up=1; fi
  [ "$backend_up" -eq 1 ] && [ "$frontend_up" -eq 1 ] && break
done
if [ "$backend_up" -eq 1 ];  then ok "Backend  -> http://localhost:8000  (docs: http://localhost:8000/docs)"; else warn "Backend not healthy. Check: docker compose logs backend"; fi
if [ "$frontend_up" -eq 1 ]; then ok "Frontend -> http://localhost:3000"; else warn "Frontend not healthy. Check: docker compose logs frontend"; fi

echo ""
echo "============================================================"
echo "  DONE"
echo "============================================================"
echo "  Open the dashboard:  http://localhost:3000"
echo "  API documentation:   http://localhost:8000/docs"
echo ""
echo "  Useful commands (in this folder):"
echo "    docker compose ps        # container status"
echo "    docker compose logs -f   # tail all logs"
echo "    docker compose down      # stop (keep data)"
echo "    docker compose down -v   # stop + wipe DB (re-seeds next start)"
echo ""
echo "  More detail: see README.md and AI_SETUP_GUIDE.md"
echo "============================================================"
