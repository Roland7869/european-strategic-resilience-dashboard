# AI Setup Guide — European Strategic Resilience Dashboard

> **Audience:** an AI coding/ops agent (or a human) handed this folder and asked to
> install, run, modify or troubleshoot the app. This file is the single source of
> truth for how the system is put together and how to operate it. Read it top to
> bottom; you should not need to guess.

---

## 1. What this is

A **local-first, self-hosted strategic early-warning, resilience and geopolitical
trend-tracking dashboard**. It is explicitly **NOT a prediction engine**. It tracks
indicators, trends, resilience measures and threat signals, and always separates
**Event → Evidence → Interpretation → Dashboard Impact**. The dashboard always shows
the **Threat side and the Resilience side together** (never all-doom, never all-fine).

Everything is open-source: Next.js/React/TS/Tailwind/Recharts/Leaflet (frontend),
Python FastAPI + SQLAlchemy + asyncpg (backend), PostgreSQL 16 (DB), Docker Compose
(container), LM Studio (optional local LLM for the AI features).

---

## 2. Quick start (the short version)

```bash
# Windows (PowerShell, from this folder):
.\install.ps1

# Linux / macOS:
chmod +x install.sh && ./install.sh
```

The installer checks prerequisites, writes `.env`, runs `docker compose up --build`,
waits for health and prints the URLs. Then open **http://localhost:3000**.

Manual equivalent (what the installer does):
```bash
cp .env.example .env          # once
docker compose up --build     # builds images, starts db + backend + frontend
```

Stop / reset:
```bash
docker compose down           # stop, keep data
docker compose down -v        # stop + WIPE the database (re-seeds sample data next start)
```

---

## 3. Prerequisites

| Requirement | Needed? | Notes |
|---|---|---|
| **Docker Desktop** (or Docker Engine + Compose plugin) | **Required** | Runs Postgres + backend + frontend. The user does NOT need Python/Node/Postgres installed. |
| **LM Studio** | Optional | Only for AI features (auto-classification, briefings, Run-to-Store, OSINT ingest). Must run on `http://localhost:1234` with a chat model loaded. |
| **Internet** | Optional | OpenStreetMap tiles (Regions page) and OSINT feed scraping. App works offline otherwise. |

Ports used: **3000** (frontend), **8000** (backend API), **5432** (Postgres).

---

## 4. Architecture / folder map

```
european-strategic-resilience-dashboard/
├── install.ps1            Windows installer (self-documenting)
├── install.sh             Linux/macOS installer
├── docker-compose.yml     3 services: db, backend, frontend
├── .env.example           config template (copy to .env)
├── README.md              full user documentation
├── AI_SETUP_GUIDE.md      this file
├── backend/               FastAPI (Python 3.12 in Docker)
│   ├── Dockerfile
│   ├── requirements.txt
│   ├── alembic.ini + alembic/       migrations (tables also auto-create on startup)
│   └── app/
│       ├── main.py        FastAPI app + lifespan (create tables + seed)
│       ├── config.py      env settings (DATABASE_URL, LMSTUDIO_*, CORS, RUN_SEED)
│       ├── database.py    async engine + session
│       ├── constants.py   seed definitions (categories/regions/confidence/source types)
│       ├── seed.py        sample data (18 events, 12 preps, ~29 OSINT feeds)
│       ├── models/        SQLAlchemy ORM models (all tables)
│       ├── schemas/       Pydantic request/response models
│       ├── api/           routers: dashboard, events, meta, ai, reports, preps, scrape, settings, uploads
│       └── services/      scoring, scoring_discipline, rule_engine, ai_service, scraper, report_service, approvals
└── frontend/              Next.js 15 App Router (React 19, TS, Tailwind 4)
    └── src/
        ├── app/           pages: / (dashboard), /entries, /map, /preps, /osint, /briefing, /assistant, /settings
        ├── components/    dashboard/, charts/, map/, feed/, ui/
        ├── lib/           types.ts (all TS interfaces), api.ts (fetch client), constants.ts, auth.ts, RefreshContext
        └── stores/
```

Runtime data: uploaded entry images land in `backend/uploads/` (served at `/uploads`).
The database lives in a Docker volume (`esrd_pgdata`).

---

## 5. Configuration (`.env`)

Copy `.env.example` → `.env`. Key variables:

| Variable | Default | Meaning |
|---|---|---|
| `POSTGRES_USER/PASSWORD/DB` | `esrd`/`esrd`/`esrd` | DB credentials |
| `DATABASE_URL` | `postgresql+asyncpg://esrd:esrd@localhost:5432/esrd` | Backend→DB (async SQLAlchemy) |
| `CORS_ORIGINS` | `http://localhost:3000` | Allowed frontend origin |
| `LMSTUDIO_BASE_URL` | `http://localhost:1234/v1` | OpenAI-compatible endpoint (host runs) |
| `LMSTUDIO_BASE_URL_DOCKER` | `http://host.docker.internal:1234/v1` | What the backend CONTAINER uses to reach the host's LM Studio |
| `LMSTUDIO_MODEL` | `google/gemma-4-e2b` | Loaded model id |
| `RUN_SEED` | `true` | Seed sample data on first start |
| `NEXT_PUBLIC_API_URL` | `http://localhost:8000` | Frontend→backend URL |
| `NEXTAUTH_URL` / `NEXTAUTH_SECRET` | — | NextAuth stub settings |

Some settings are **persisted in the DB** (`app_settings` table) and editable in the
UI (Settings page): `lmstudio_base_url`, `lmstudio_model`, `run_to_store_threshold`,
`auto_approve`, `household_size`. DB values win over env at runtime.

---

## 6. How the AI (LM Studio) integration works

- The backend calls any **OpenAI-compatible** `/v1/chat/completions` endpoint.
- Endpoint + model come from Settings (or env). Default: LM Studio on `:1234`.
- The **AI Assistant** page (`/assistant`) exposes capabilities: summarize,
  trend_changes, suggest_scores, contradictions, daily, weekly, executive — plus a
  **Run All** button that runs every capability sequentially.
- **Auto-approve** (Settings, default ON): AI score-change proposals are applied
  immediately. Turn OFF to require manual approval in the Assistant page.
- The AI intake (`POST /events/ai`) classifies raw analyst input into
  categories/regions/confidence/notes automatically. Score impacts are
  confidence-weighted (see §8) and auto-applied when auto-approve is on.

If LM Studio is offline, everything still runs; AI panels show "offline" and intake
falls back to neutral defaults.

---

## 7. OSINT scraping

- The **OSINT** page (`/osint`) manages ~29 seeded public RSS/Atom feeds grouped by
  **tier** (Tier 1 news wires, geopolitical intel, cyber, maritime, energy, etc.).
- Collection is **restricted to 4 topics** (keyword-matched in
  `backend/app/services/scraper.py` → `TOPIC_KEYWORDS`): **Economy, Flash Points,
  Food Shortages, Supply Chain**. Only matching headlines are kept.
- A source's **tier → base_confidence** (`TIER_CONFIDENCE` in scraper.py) sets a
  confidence floor on ingest: Tier 1 wires never score below HIGH (100% impact),
  OSINT/early-warning stays LOW (25%, detection only).
- **Run scrape** pulls new items; **Ingest All** (or per-item Ingest) converts each
  headline into a fully AI-classified entry.
- **Security:** every scrape URL is SSRF-validated (http(s) only, public hosts only;
  private/loopback/link-local/metadata addresses rejected). Fetches use a
  browser-like User-Agent and are size-capped.
- Dead/blocked feeds are removed over time; failures are collected per-source and do
  not abort a run. To add a feed: OSINT page → Add (name, url, kind=rss, tier).

---

## 8. Scoring model (important — do not break)

Enforced in `backend/app/services/scoring_discipline.py`:

- Score only **severity, strategic importance, escalation potential, systemic impact**.
  **Event frequency never directly raises scores** (Event Density is a separate metric).
- **10.0 is gated**: reserved for an active strategic emergency; at most **~15%** of
  threat indicators may sit at 10.0 (excess auto-demoted to 9.5). Prefer 7.0–9.5
  under uncertainty; any score >9.0 needs an evidence-based justification.
- **Confidence-weighted impact**: HIGH 100%, MEDIUM 50%, LOW 25%, UNVERIFIED social
  media 0% (watchlist only).
- **Strategic Friction Index (0–10)**: composite of simultaneous crises, political
  polarization, economic friction, information warfare, infrastructure stress
  (resilience-side categories inverted). Shown on the dashboard.
- **Run-To-Shop matrix**: RED only on hard gates (direct NATO–Russia clash, major
  infra catastrophe, mass-casualty hybrid attack, systemic collapse); ORANGE when
  multiple concurrent threat categories are elevated.

---

## 9. Key API endpoints (backend, port 8000; interactive docs at `/docs`)

| Method + path | Purpose |
|---|---|
| `GET /dashboard` | Full dashboard payload (summary incl. SFI + flashpoints, categories, all chart data) |
| `GET/POST /events`, `GET/DELETE /events/{id}` | Entry CRUD + filters |
| `POST /events/ai` | Minimal intake → AI classifies (categories/regions/confidence/notes) |
| `POST/DELETE /events/{id}/attachments[/{att}]` | Entry picture upload/remove |
| `GET /meta/categories` `/regions` `/confidence-levels` `/source-types` `/sources` | Reference data |
| `POST /ai/run`, `GET /ai/health` | AI capabilities + LM Studio health |
| `GET /ai/proposals`, `POST /ai/proposals/{id}/decide` | Proposal approval (auto-approve usually on) |
| `POST/GET /reports`, `GET /reports/briefing`, `GET /reports/export/{id}?format=pdf\|docx\|markdown` | Briefings + export |
| `GET/POST/PUT/DELETE /preps`, `POST /preps/run-to-store`, `GET /preps/readiness`, `POST /preps/household-size` | Preps inventory + Run-to-Store + Household Readiness |
| `GET/POST/DELETE /scrape/sources`, `POST /scrape/run`, `GET /scrape/items`, `POST /scrape/items/{id}/ingest`, `POST /scrape/items/ingest-all` | OSINT scraping |
| `GET/POST /settings` | LM Studio config + Run-to-Store threshold + auto-approve |

---

## 10. Database

Tables (auto-created on startup via `Base.metadata.create_all`; Alembic available for
versioned migrations): `users`, `categories`, `regions`, `confidence_levels`,
`source_types`, `sources`, `events`, `event_categories`, `event_regions`,
`assessments`, `reports`, `watchlists`, `watchlist_items`, `attachments`,
`ai_proposals`, `preps`, `scrape_sources`, `scraped_items`, `app_settings`.

Sample seed (first start, `RUN_SEED=true`): 18 categories (14 threat + 4 resilience),
12 regions, confidence levels + source types, sources, 18 events, 12 preps, ~29 OSINT
feeds. To re-seed: `docker compose down -v && docker compose up`.

---

## 11. Common tasks (for an agent)

- **Add an OSINT feed:** `POST /scrape/sources` `{name,url,kind:"rss",tier}` (tier sets
  confidence), or use the OSINT page. Add topic keywords in `scraper.py` if the feed's
  topics aren't already covered.
- **Add a tracked category:** insert into `categories` (name, side=threat|resilience,
  current_score, confidence, trend). It appears on the dashboard automatically.
- **Change scoring rules:** edit `backend/app/services/scoring_discipline.py` (weights,
  10-cap, SFI signal mapping). Rebuild backend.
- **Change AI behaviour:** edit prompts in `backend/app/services/ai_service.py`.
- **Change what OSINT collects:** edit `TOPIC_KEYWORDS` in `scraper.py`.
- **After any backend change:** `docker compose up -d --build backend`.
- **After any frontend change:** `docker compose up -d --build frontend` (or `npm run dev`
  in `frontend/` for hot reload during development).

---

## 12. Troubleshooting

| Symptom | Fix |
|---|---|
| Frontend "unable to connect" | Docker not running / stack not up. `docker compose up -d`, then hard-refresh the browser (Ctrl+Shift+R). |
| Frontend "Backend unreachable" | Backend down. `docker compose logs backend`. |
| AI shows "offline" | Start LM Studio on :1234 with a model. Check Settings → base URL/model. In Docker the backend uses `host.docker.internal:1234`. |
| OSINT scrape returns few/0 items | Feeds may be down/blocked (errors listed in the response). Check `docker compose logs backend`. |
| Port already in use | Another process owns 3000/8000/5432. Stop it or change the host ports in `docker-compose.yml`. |
| Want a clean slate | `docker compose down -v && docker compose up --build` (re-seeds sample data). |
| Backend won't start | `docker compose logs backend` — usually a migration/import error. Python syntax: `python -m py_compile app/main.py` inside `backend/`. |
| Frontend build error | `cd frontend && npm run build` to see the error; `npx tsc --noEmit` for type errors. |

---

## 13. Verification checklist (after install or changes)

```bash
docker compose ps                 # all 3 containers Up, db healthy
curl http://localhost:8000/       # {"status":"ok"...}
curl http://localhost:8000/dashboard   # JSON with summary + categories
curl http://localhost:3000        # HTML
```
Frontend pages that must return 200: `/`, `/entries`, `/map`, `/preps`, `/osint`,
`/briefing`, `/assistant`, `/settings`.

---

*This project is local-first and self-hosted. Auth is a NextAuth stub (app runs open
on localhost). Change default secrets and add real auth before any shared/hosted
deployment — see the Security section of README.md.*
