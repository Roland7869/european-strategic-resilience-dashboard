"""Image attachment upload for entries.

Security: uploads are restricted to images, size-capped, filenames sanitised,
and stored under a UUID-based name (no user-controlled path components).
Served read-only from the /uploads static mount.
"""
import re
import uuid
from pathlib import Path

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.models import Attachment, Event

UPLOAD_DIR = Path(__file__).resolve().parent.parent / "uploads"
UPLOAD_DIR.mkdir(exist_ok=True)

ALLOWED_TYPES = {
    "image/jpeg": ".jpg",
    "image/png": ".png",
    "image/gif": ".gif",
    "image/webp": ".webp",
}
MAX_BYTES = 5 * 1024 * 1024  # 5 MB

router = APIRouter(prefix="/events", tags=["attachments"])


def _sanitize_filename(name: str) -> str:
    name = Path(name or "image").name  # strip any path components
    name = re.sub(r"[^A-Za-z0-9._-]", "_", name)
    return name[:100] or "image"


@router.post("/{event_id}/attachments", status_code=201)
async def upload_attachment(
    event_id: int,
    file: UploadFile = File(...),
    db: AsyncSession = Depends(get_db),
):
    event = await db.get(Event, event_id)
    if not event:
        raise HTTPException(status_code=404, detail="Event not found")

    content_type = (file.content_type or "").lower()
    if content_type not in ALLOWED_TYPES:
        raise HTTPException(status_code=400, detail="Only JPEG, PNG, GIF or WebP images are allowed")

    data = await file.read()
    if len(data) > MAX_BYTES:
        raise HTTPException(status_code=400, detail="File too large (max 5 MB)")
    if not data:
        raise HTTPException(status_code=400, detail="Empty file")

    ext = ALLOWED_TYPES[content_type]
    safe_name = _sanitize_filename(file.filename)
    stored_name = f"{uuid.uuid4().hex}_{safe_name}"
    if not stored_name.lower().endswith(ext):
        stored_name += ext
    dest = UPLOAD_DIR / stored_name
    dest.write_bytes(data)

    att = Attachment(
        event_id=event_id,
        filename=safe_name,
        content_type=content_type,
        path=f"/uploads/{stored_name}",
    )
    db.add(att)
    await db.commit()
    await db.refresh(att)
    return {
        "id": att.id,
        "filename": att.filename,
        "content_type": att.content_type,
        "path": att.path,
        "uploaded_at": att.uploaded_at,
    }


@router.delete("/{event_id}/attachments/{att_id}", status_code=204)
async def delete_attachment(event_id: int, att_id: int, db: AsyncSession = Depends(get_db)):
    att = await db.get(Attachment, att_id)
    if not att or att.event_id != event_id:
        raise HTTPException(status_code=404, detail="Attachment not found")
    # Remove file from disk (best-effort)
    try:
        fname = att.path.rsplit("/", 1)[-1]
        (UPLOAD_DIR / fname).unlink(missing_ok=True)
    except OSError:
        pass
    await db.delete(att)
    await db.commit()
