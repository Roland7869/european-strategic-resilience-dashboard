# European Strategic Resilience Dashboard

A strategic early-warning, resilience and geopolitical trend tracking system.

> **This is NOT a prediction engine.** It tracks indicators, trends, resilience measures and
> threat signals. The system always separates **Event → Evidence → Interpretation → Dashboard
> Impact**. An event must never automatically become a conclusion.

The dashboard always displays the **Threat Side** and the **Resilience Side** simultaneously.
It is deliberately balanced — never a "Doom Dashboard" and never an "Everything is Fine Dashboard".

---

## Core Principle

Every entry is stored and displayed with four distinct layers:

| Layer | Meaning |
|---|---|
| **Event** | What happened (title, date, summary) |
| **Evidence** | Source, source type, confidence level, evidence notes |
| **Interpretation** | Analyst notes — the human analytical layer |
| **Dashboard Impact** | Which category scores change and by how much |

---

## Technology Stack (all open-source)

| Layer | Technology |
|---|---|
| Frontend | Next.js 15 (App Router), React 19, TypeScript, Tailwind CSS 4, Recharts, Leaflet |
| Backend | Python FastAPI (async) |
| Database | PostgreSQL 16 |
| ORM | SQLAlchemy 2 (async) + Alembic |
| Auth | NextAuth (stub — wired in, app runs open locally) |
| AI | LM Studio (OpenAI-compatible endpoint) |
| Container | Docker Compose |

**Design:** NATO situation-room / intelligence briefing board aesthetic. Dark theme
(`#0b0f17` background) with a strict status colour language:

| Colour | Meaning |
|---|---|
| 🟢 Green | Resilience / baseline |
| 🟡 Yellow | Watch |
| 🟠 Orange | Elevated concern |
| 🔴 Red | Critical |

---

## Quick Start (Docker — recommended)

Prerequisites: Docker + Docker Compose, and (for the AI module) [LM Studio](https://lmstudio.ai)
running locally on port `1234` with a chat model loaded.

```bash
cd european-strategic-resilience-dashboard

# 1. Configure (optional — sensible defaults are built in)
cp .env.example .env

# 2. Build and start everything (Postgres + backend + frontend)
docker compose up --build
```

Then open:

| Service | URL |
|---|---|
| Dashboard | http://localhost:3000 |
| API (OpenAPI docs) | http://localhost:8000/docs |
| Database | `localhost:5432` (user/pass/db: `esrd`/`esrd`/`esrd`) |

On first start the backend **automatically creates tables and seeds** a sample dataset:
18 categories, 12 regions, 10 confidence/source types, 12 sources and 18 sample events.
The overall status computes to **ORANGE** out of the box.

Stop the stack:

```bash
docker compose down        # stop
docker compose down -v     # stop AND wipe the database volume (re-seeds on next start)
```

### Local development (without Docker for the app)

You can run the app components directly on the host while letting Docker serve only Postgres:

```bash
# Database only
docker compose up -d db

# Backend (host Python 3.11+ recommended)
cd backend
python -m venv .venv && .venv\Scripts\activate     # Windows
pip install -r requirements.txt
set DATABASE_URL=postgresql+asyncpg://esrd:esrd@localhost:5432/esrd
uvicorn app.main:app --reload

# Frontend (second terminal)
cd frontend
npm install
npm run dev
```

---

## AI Setup (LM Studio)

The AI Assistant connects to any **OpenAI-compatible** endpoint. It is configured for
LM Studio by default.

1. Start **LM Studio**, load a chat model (e.g. `google/gemma-4-e2b`, `qwen/qwen3.8-27b`),
   and start the local server on port **1234**.
2. Open the dashboard → **Settings**. Verify/set:
   - **Base URL:** `http://localhost:1234/v1` (this is the default)
   - **Model:** the exact model id shown in LM Studio
3. Open **AI Assistant**. The status dot turns green when connected; the loaded models are listed.

> When running in Docker, the backend reaches LM Studio through `host.docker.internal`
> automatically. The **Settings** page can override the endpoint at any time.

### AI capabilities

| Capability | What it does |
|---|---|
| Summarize All Events | Groups events by category and confidence, separating the four layers |
| Identify Trend Changes | Notes which categories are rising / stable / falling and why |
| Suggest Score Adjustments | Proposes 0–10 score changes as JSON |
| Highlight Contradictory Evidence | Surfaces where sources conflict |
| Generate Daily Briefing | Full daily intelligence briefing |
| Generate Weekly Report | Weekly roll-up |
| Generate Executive Assessment | Concise senior-leadership assessment |

**Human-in-the-loop:** the AI can only **propose** changes. Score-adjustment suggestions are
queued as `PENDING` proposals. A human analyst must **Approve** or **Reject** each one from the
Assistant page before any category score changes.

---

## Using the Dashboard

### Primary screen
- **Status banner** — current strategic status (GREEN / YELLOW / ORANGE / RED) plus the four
  headline metrics.
- **Executive summary** — Threat Trend, Resilience Trend, Strategic Surprise Index (0–100),
  Event Density Index (0–100).
- **Flashpoints** — the hottest regions by activity × threat intensity, with their top implicated
  categories. Also embedded in the briefing and the AI executive assessment.
- **Category grids** — Threat and Resilience environments side by side. Each category shows a
  0–10 score, a confidence badge (LOW/MEDIUM/HIGH) and a trend arrow (UP/DOWN/STABLE).
- **Visualizations** — event density heatmap, category radar (threat vs resilience), event
  timeline, threat histogram and confidence distribution.
- **Latest entries** — most recent feed, newest first.

The **Update All** button in the header refreshes every panel (dashboard, map, feed) in one go.

### Entry system (`/entries`)
To add an entry you only supply the **raw data** — date, title, an optional source and a
description of what happened. On save, the AI (LM Studio) automatically classifies it:

- **Categories** it implicates (1–3) and a small score impact
- **Regions** involved
- **Confidence** (HIGH / MEDIUM / LOW) and **source type**
- **Evidence** and **interpretation** notes
- The **verification badge** (via the rule engine)

The classification is applied immediately. Any suggested **category score changes** are queued
as PENDING proposals in the **AI Assistant** for human approval — so classification is automatic
while dashboard score movement stays human-approved.

Use the filters to slice the feed by date, confidence, category, region or source type.

### Regions (`/map`)
Interactive Leaflet map with 14 regions. Click a region to load all of its entries.
Marker colour/size reflects event density. Updates live via the **Update All** button.

### Entry pictures
Each entry supports attached **images** (JPEG/PNG/GIF/WebP, max 5 MB). Upload from the entry
form after saving, or from an expanded feed row. Images are stored under `/uploads` and shown
as thumbnails.

### Preps (`/preps`)
The owner's **preparedness inventory** — water, food, power, medical, fuel, shelter, comms, etc.
Track quantity, unit, a minimum (restock) level and priority.

**Run to the Store:** set a threshold in **Settings** (0–10). When the live threat environment
reaches that level, the AI reviews the inventory and suggests what to top up (flagging items
below their minimum and what to prioritise given the current threat picture). You can also
force a run anytime from the Preps page.

### OSINT (`/osint`)
Configure public **RSS/HTML feeds** to scrape for headlines. **Run scrape** pulls new items
(SSRF-safe), then **Ingest → entry** converts a headline into a fully AI-classified entry.
Scraped items are held for human review before ingestion.

### Briefing (`/briefing`)
Auto-generated printable report with Executive Summary, Major Changes, Fastest Rising Risks,
Fastest Rising Resilience Indicators, Watch List and Strategic Assessment. Export as
**PDF**, **DOCX** or **Markdown**, or print directly.

### AI Assistant (`/assistant`)
Run the capabilities above and approve/reject proposed changes.

### Settings (`/settings`)
LM Studio endpoint + model, the confidence scale reference, and the verification-status rules.

---

## Category Scoring & Scoring Discipline

Each category has a `score` (0–10), `confidence` (LOW/MEDIUM/HIGH) and `trend` (UP/DOWN/STABLE).
Categories are split into a **threat** side and a **resilience** side so the dashboard stays
balanced.

Score changes are governed by an enforced **scoring discipline** (`backend/app/services/scoring_discipline.py`):

**What is scored** — only *severity*, *strategic importance*, *escalation potential* and *systemic
impact*. **Event frequency is a separate metric** and never directly raises a threat score;
headline volume alone does not justify an increase.

**The 10.0 rule** — 10.0 is reserved for an active strategic emergency with multiple independent
confirmations, immediate operational consequences and no higher escalation category. At most
**~15%** of tracked threat indicators may sit at 10.0 at once (excess 10.0s are auto-demoted to
9.5). Under uncertainty the model prefers **7.0–9.5** over 10.0, and must justify any score above
9.0 with evidence (why it is not 7.0 / 8.0 / 9.0).

**Confidence-weighted score impact** — every score adjustment is scaled by the evidence confidence:

| Confidence | Score impact |
|---|---|
| HIGH | 100% |
| MEDIUM | 50% |
| LOW | 25% |
| UNVERIFIED (social media) | 0% — watchlist only, no adjustment unless corroborated |

**Strategic Friction Index (0–10)** — a composite of five signals shown on the dashboard:
simultaneous active crises, political polarization, economic friction, information warfare and
infrastructure stress. Resilience-side categories inside a friction signal are inverted, so
stronger resilience lowers the reading.

Creating an entry with a category and a non-zero **impact delta** adjusts that category's score
(confidence-weighted, clamped to 0–10, 10.0-capped) and updates its trend.

---

## Verification Status Rule Engine

Every event is automatically assigned a verification badge from its **source type + confidence**:

| Badge | Rule |
|---|---|
| **Confirmed** | High-trust source (government / military / intelligence / official) + HIGH confidence |
| **Reported** | High-trust source, or medium-trust source with HIGH confidence |
| **Claimed** | Medium-trust source (major media / expert / OSINT) |
| **Speculated** | Low-trust source with elevated confidence |
| **Unverified** | Low-trust source (social media / rumour / unverified) + LOW confidence |

### Confidence scale
- **HIGH** — government statements, military reports, intelligence assessments, official publications
- **MEDIUM** — major media, expert analysis, open-source intelligence
- **LOW** — social media, rumours, unverified claims

---

## Dashboard Calculations & Run-To-Shop Matrix

Computed live by the backend (`backend/app/services/scoring.py` and `rule_engine.py`):

- **Threat Environment** — confidence-weighted mean of threat-side categories → 0–10
- **Resilience Environment** — confidence-weighted mean of resilience-side categories → 0–10
- **Strategic Surprise Index (0–100)** — combines recent score volatility, high-confidence event
  density and low-confidence anomalies
- **Event Density Index (0–100)** — events/day over a 14-day window vs a 90-day baseline

**Overall status (Run-To-Shop Matrix):**

| Level | Rule |
|---|---|
| **RED** | Only on: direct NATO–Russia clash, major infrastructure catastrophe, mass-casualty hybrid attack, or systemic-collapse indicators |
| **ORANGE** | Multiple (≥3) concurrent threat categories at/above the elevated threshold, or any category at/above the critical threshold |
| **YELLOW** | Highest threat category in the watch band |
| **GREEN** | Baseline |

The RED conditions are deliberate hard gates — the system will not drift into RED on aggregate
scores alone.

---

## API Overview

Interactive docs at **http://localhost:8000/docs**. Key routes:

| Method & path | Purpose |
|---|---|
| `GET /dashboard` | Full dashboard payload (summary, categories, all chart data) |
| `GET/POST /events`, `GET/DELETE /events/{id}` | Entry CRUD with filters |
| `POST /events/ai` | Minimal intake — raw data in, AI classifies (categories/regions/confidence/notes) |
| `POST/DELETE /events/{id}/attachments[/{att}]` | Entry picture upload / remove |
| `GET /meta/categories` `/regions` `/confidence-levels` `/source-types` `/sources` | Reference data |
| `POST /ai/run`, `GET /ai/health` | AI capabilities + LM Studio health |
| `GET /ai/proposals`, `POST /ai/proposals/{id}/decide` | Human approval workflow |
| `POST/GET /reports`, `GET /reports/briefing`, `GET /reports/export/{id}` | Briefings + export |
| `GET/POST/PUT/DELETE /preps`, `POST /preps/run-to-store` | Preparedness inventory + AI top-up |
| `GET/POST/DELETE /scrape/sources`, `POST /scrape/run`, `GET /scrape/items`, `POST /scrape/items/{id}/ingest` | OSINT scraping |
| `GET/POST /settings` | LM Studio config + Run-to-Store threshold |

---

## Database Schema

Tables: `users`, `categories`, `regions`, `confidence_levels`, `source_types`, `sources`,
`events`, `event_categories`, `event_regions`, `assessments`, `reports`, `watchlists`,
`watchlist_items`, `attachments`, `ai_proposals`, `preps`, `scrape_sources`, `scraped_items`,
`app_settings`.

Tables are created automatically on startup. For versioned migrations use Alembic:

```bash
cd backend
alembic revision --autogenerate -m "initial"
alembic upgrade head
```

---

## Project Structure

```
european-strategic-resilience-dashboard/
├── docker-compose.yml
├── .env.example
├── README.md
├── backend/
│   ├── Dockerfile
│   ├── requirements.txt
│   ├── alembic.ini + alembic/
│   └── app/
│       ├── main.py            FastAPI app + lifespan (create tables + seed)
│       ├── config.py          Settings (env-driven)
│       ├── database.py        Async engine + session
│       ├── constants.py       Seed definitions
│       ├── seed.py            Sample dataset
│       ├── models/            SQLAlchemy ORM models
│       ├── schemas/           Pydantic request/response models
│       ├── api/               Routers: dashboard, events, meta, ai, reports, settings
│       └── services/          scoring, rule_engine, ai_service, report_service
└── frontend/
    ├── Dockerfile
    └── src/
        ├── app/               Pages: /, /entries, /map, /briefing, /assistant, /settings
        ├── components/        dashboard/, charts/, map/, feed/, ui/
        ├── lib/               types.ts (interfaces), api.ts (client), constants.ts, auth.ts
        └── stores/
```

---

## Configuration Reference (`.env`)

| Variable | Default | Notes |
|---|---|---|
| `POSTGRES_USER` / `POSTGRES_PASSWORD` / `POSTGRES_DB` | `esrd` | Database credentials |
| `DATABASE_URL` | `postgresql+asyncpg://esrd:esrd@localhost:5432/esrd` | Async SQLAlchemy URL |
| `CORS_ORIGINS` | `http://localhost:3000` | Comma-separated allowed origins |
| `LMSTUDIO_BASE_URL` | `http://localhost:1234/v1` | OpenAI-compatible endpoint |
| `LMSTUDIO_BASE_URL_DOCKER` | `http://host.docker.internal:1234/v1` | Used by the backend container |
| `LMSTUDIO_MODEL` | `google/gemma-4-e2b` | Loaded model id |
| `RUN_SEED` | `true` | Seed sample data on startup |
| `NEXT_PUBLIC_API_URL` | `http://localhost:8000` | Frontend → backend URL |
| `NEXTAUTH_URL` / `NEXTAUTH_SECRET` | — | NextAuth stub settings |

---

## Authentication

NextAuth is **wired in as a stub** (`frontend/src/lib/auth.ts` and the
`/api/auth/[...nextauth]` route). The app runs open for local use; the credentials provider
accepts any non-empty input. To enforce real login, add user records with hashed passwords to
the `users` table and tighten `authorize()`.

---

## Security Notes

The app is local-first and self-hosted, but the following protections are built in:

- **SSRF protection (scraper)** — every scrape URL is validated before fetching: `http(s)` only,
  and the host must resolve to a public address. Private / loopback / link-local / metadata
  addresses (e.g. `169.254.169.254`, `localhost`, `10.x`) are rejected with `400`.
- **Upload validation (entry pictures)** — only `image/jpeg|png|gif|webp`, capped at **5 MB**,
  filenames stripped of path components and stored under a **UUID-based** name (no user-controlled
  path segments → no path traversal). Served read-only from `/uploads`.
- **SQL injection** — all queries go through SQLAlchemy ORM with bound parameters.
- **CORS** — restricted to the configured frontend origin (`CORS_ORIGINS`, default
  `http://localhost:3000`); credentials allowed only for that origin.
- **Secrets** — `.env.example` ships with development defaults (`esrd`/`esrd`, a placeholder
  `NEXTAUTH_SECRET`). **Change these before any shared/hosted deployment.**

### Hardening checklist for a shared deployment
1. Set strong `POSTGRES_PASSWORD` and `NEXTAUTH_SECRET`.
2. Restrict `CORS_ORIGINS` to your real origin(s).
3. Put the stack behind a reverse proxy with TLS (e.g. Caddy/nginx) — do not expose raw ports.
4. Enable real authentication (replace the NextAuth stub with user records + hashed passwords).
5. Run the containers as a non-root user and keep images updated.

> Authentication is currently a **stub** (see below) — the app runs open on localhost. Treat it
> as a single-analyst workstation tool unless you add auth and TLS.

---

## Troubleshooting

| Symptom | Fix |
|---|---|
| Frontend shows "Backend unreachable" | Ensure `docker compose up` is running; backend on :8000 |
| AI status stays red | Start LM Studio server on 1234; check **Settings** base URL/model |
| AI works on host but not in Docker | The container uses `host.docker.internal`; ensure LM Studio listens on localhost |
| Empty dashboard | Backend seeds on first start; check `docker compose down -v` then restart for a clean reseed |
| Map tiles blank | OpenStreetMap tiles need internet; region list and drawer still work offline |

---

## License

Open-source. Built entirely with open-source technologies.
