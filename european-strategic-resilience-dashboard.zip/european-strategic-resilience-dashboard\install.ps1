<#
.SYNOPSIS
    European Strategic Resilience Dashboard — Windows installer.

.DESCRIPTION
    One-command installer. It checks every prerequisite, prepares the .env
    configuration, builds and starts the whole stack with Docker Compose, then
    waits for the services to become healthy and prints the URLs.

    This file is intentionally self-documenting so that an AI agent (or a human)
    can read it top-to-bottom and understand exactly what the app needs and how
    to run, verify, stop and reset it.

.NOTES
    Prerequisites (checked below):
      1. Docker Desktop (provides `docker` + `docker compose`). REQUIRED.
      2. LM Studio (optional) — only needed for the AI features. It must be
         running on http://localhost:1234 with a chat model loaded.
      3. Internet (optional) — for OpenStreetMap tiles and OSINT feed scraping.

.EXAMPLE
    # From this folder in PowerShell:
    .\install.ps1

.EXAMPLE
    # Skip the interactive prompts (for automation):
    .\install.ps1 -NonInteractive
#>
[CmdletBinding()]
param(
    [switch]$NonInteractive,
    [switch]$ResetData,      # wipe the database volume and re-seed sample data
    [switch]$NoBuild         # skip the image build (use existing images)
)

$ErrorActionPreference = "Stop"
$ProjectRoot = $PSScriptRoot

function Write-Step($msg) { Write-Host "`n==> $msg" -ForegroundColor Cyan }
function Write-Ok($msg)   { Write-Host "    [OK] $msg" -ForegroundColor Green }
function Write-Warn($msg) { Write-Host "    [!!] $msg" -ForegroundColor Yellow }
function Write-Bad($msg)  { Write-Host "    [X ] $msg" -ForegroundColor Red }

Write-Host "============================================================" -ForegroundColor White
Write-Host "  European Strategic Resilience Dashboard — Installer" -ForegroundColor White
Write-Host "  Strategic early-warning / resilience tracking (NOT a prediction engine)" -ForegroundColor DarkGray
Write-Host "============================================================" -ForegroundColor White

# ---------------------------------------------------------------------------
# Step 1 — Docker Desktop + Docker Compose
# ---------------------------------------------------------------------------
Write-Step "Checking prerequisite: Docker Desktop"
$docker = Get-Command docker -ErrorAction SilentlyContinue
if (-not $docker) {
    Write-Bad "Docker is not installed (or not on PATH)."
    Write-Host "    Install Docker Desktop from https://www.docker.com/products/docker-desktop/" -ForegroundColor Yellow
    Write-Host "    then re-run this script." -ForegroundColor Yellow
    exit 1
}

# Is the Docker engine running? If not, try to start Docker Desktop.
$engineUp = $false
try { docker info 2>$null | Out-Null; if ($LASTEXITCODE -eq 0) { $engineUp = $true } } catch {}
if (-not $engineUp) {
    Write-Warn "Docker engine is not running. Attempting to start Docker Desktop..."
    $dd = "C:\Program Files\Docker\Docker\Docker Desktop.exe"
    if (Test-Path $dd) { Start-Process $dd } else { Write-Warn "Docker Desktop.exe not at default path." }
    $deadline = (Get-Date).AddSeconds(120)
    while ((Get-Date) -lt $deadline) {
        Start-Sleep -Seconds 5
        try { docker info 2>$null | Out-Null; if ($LASTEXITCODE -eq 0) { $engineUp = $true; break } } catch {}
    }
}
if (-not $engineUp) {
    Write-Bad "Could not start the Docker engine. Start Docker Desktop manually and re-run."
    exit 1
}
Write-Ok "Docker engine is running."

# docker compose (v2 plugin)
docker compose version 2>$null | Out-Null
if ($LASTEXITCODE -ne 0) {
    Write-Bad "Docker Compose plugin not found. Update Docker Desktop or install the compose plugin."
    exit 1
}
Write-Ok "Docker Compose is available."

# ---------------------------------------------------------------------------
# Step 2 — LM Studio (optional, for AI features)
# ---------------------------------------------------------------------------
Write-Step "Checking optional prerequisite: LM Studio (AI features)"
$lmOk = $false
try {
    $resp = Invoke-WebRequest -Uri "http://localhost:1234/v1/models" -TimeoutSec 3 -UseBasicParsing
    if ($resp.StatusCode -eq 200) { $lmOk = $true }
} catch {}
if ($lmOk) {
    Write-Ok "LM Studio is reachable on port 1234 (AI features enabled)."
} else {
    Write-Warn "LM Studio not detected on http://localhost:1234."
    Write-Host "    The app will still run; AI features show 'offline' until you start LM Studio," -ForegroundColor Yellow
    Write-Host "    load a chat model and start its local server on port 1234." -ForegroundColor Yellow
}

# ---------------------------------------------------------------------------
# Step 3 — Prepare .env
# ---------------------------------------------------------------------------
Write-Step "Preparing configuration (.env)"
$envFile = Join-Path $ProjectRoot ".env"
if (-not (Test-Path $envFile)) {
    Copy-Item (Join-Path $ProjectRoot ".env.example") $envFile
    Write-Ok "Created .env from .env.example (defaults are fine for local use)."
} else {
    Write-Ok ".env already exists (left untouched)."
}

# ---------------------------------------------------------------------------
# Step 4 — (Optional) reset data
# ---------------------------------------------------------------------------
if ($ResetData) {
    Write-Step "Resetting database (down -v) — sample data will be re-seeded on next start"
    Push-Location $ProjectRoot
    docker compose down -v | Out-Null
    Pop-Location
    Write-Ok "Database volume removed."
}

# ---------------------------------------------------------------------------
# Step 5 — Build + start the stack
# ---------------------------------------------------------------------------
Write-Step "Building and starting the stack (Postgres + backend + frontend)"
Push-Location $ProjectRoot
$upArgs = @("compose", "up", "-d")
if (-not $NoBuild) { $upArgs += "--build" }
docker @upArgs
if ($LASTEXITCODE -ne 0) {
    Pop-Location
    Write-Bad "docker compose up failed. See the output above."
    exit 1
}
Pop-Location
Write-Ok "Containers started."

# ---------------------------------------------------------------------------
# Step 6 — Wait for health + report
# ---------------------------------------------------------------------------
Write-Step "Waiting for services to become healthy"
function Test-Url($url) {
    try { $r = Invoke-WebRequest -Uri $url -TimeoutSec 20 -UseBasicParsing; return $r.StatusCode -eq 200 } catch { return $false }
}
$deadline = (Get-Date).AddSeconds(90)
$backendUp = $false; $frontendUp = $false
while ((Get-Date) -lt $deadline) {
    Start-Sleep -Seconds 5
    if (-not $backendUp)  { $backendUp  = Test-Url "http://localhost:8000/" }
    if (-not $frontendUp) { $frontendUp = Test-Url "http://localhost:3000" }
    if ($backendUp -and $frontendUp) { break }
}
if ($backendUp)  { Write-Ok "Backend  -> http://localhost:8000  (API docs: http://localhost:8000/docs)" } else { Write-Warn "Backend not healthy yet. Check: docker compose logs backend" }
if ($frontendUp) { Write-Ok "Frontend -> http://localhost:3000" } else { Write-Warn "Frontend not healthy yet. Check: docker compose logs frontend" }

# ---------------------------------------------------------------------------
# Summary
# ---------------------------------------------------------------------------
Write-Host "`n============================================================" -ForegroundColor White
Write-Host "  DONE" -ForegroundColor Green
Write-Host "============================================================" -ForegroundColor White
Write-Host "  Open the dashboard:  http://localhost:3000" -ForegroundColor White
Write-Host "  API documentation:   http://localhost:8000/docs" -ForegroundColor White
Write-Host ""
Write-Host "  Useful commands (run in this folder):" -ForegroundColor DarkGray
Write-Host "    docker compose ps        # container status" -ForegroundColor DarkGray
Write-Host "    docker compose logs -f   # tail all logs" -ForegroundColor DarkGray
Write-Host "    docker compose down      # stop (keep data)" -ForegroundColor DarkGray
Write-Host "    docker compose down -v   # stop + wipe DB (re-seeds next start)" -ForegroundColor DarkGray
Write-Host ""
Write-Host "  More detail: see README.md and AI_SETUP_GUIDE.md" -ForegroundColor DarkGray
Write-Host "============================================================" -ForegroundColor White
