"use client";

import {
  Bar,
  CartesianGrid,
  Cell,
  ComposedChart,
  Line,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import type { TimelinePoint } from "@/lib/types";

export function TimelineChart({ data }: { data: TimelinePoint[] }) {
  return (
    <div className="h-[220px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <ComposedChart data={data} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
          <CartesianGrid stroke="#1a2334" strokeDasharray="3 3" />
          <XAxis dataKey="date" tick={{ fill: "#64748b", fontSize: 10 }} tickFormatter={(v) => String(v).slice(5)} />
          <YAxis tick={{ fill: "#64748b", fontSize: 10 }} allowDecimals={false} />
          <Tooltip
            contentStyle={{ background: "#0d1420", border: "1px solid #2a3a55", borderRadius: 4, fontSize: 12 }}
            labelStyle={{ color: "#94a3b8" }}
          />
          <Bar dataKey="events" fill="#f97316" radius={[2, 2, 0, 0]} />
          <Line dataKey="events" stroke="#38bdf8" strokeWidth={2} dot={{ r: 2 }} />
        </ComposedChart>
      </ResponsiveContainer>
    </div>
  );
}
