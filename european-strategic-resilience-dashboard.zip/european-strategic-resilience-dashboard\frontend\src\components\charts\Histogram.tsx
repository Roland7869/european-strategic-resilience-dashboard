"use client";

import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import type { HistogramBucket } from "@/lib/types";

export function Histogram({ data }: { data: HistogramBucket[] }) {
  return (
    <div className="h-[220px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
          <CartesianGrid stroke="#1a2334" strokeDasharray="3 3" />
          <XAxis dataKey="bucket" tick={{ fill: "#64748b", fontSize: 10 }} />
          <YAxis tick={{ fill: "#64748b", fontSize: 10 }} allowDecimals={false} />
          <Tooltip
            contentStyle={{ background: "#0d1420", border: "1px solid #2a3a55", borderRadius: 4, fontSize: 12 }}
          />
          <Legend wrapperStyle={{ fontSize: 11 }} />
          <Bar dataKey="threat" stackId="a" fill="#ef4444" radius={[0, 0, 0, 0]} />
          <Bar dataKey="resilience" stackId="a" fill="#22c55e" radius={[2, 2, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
