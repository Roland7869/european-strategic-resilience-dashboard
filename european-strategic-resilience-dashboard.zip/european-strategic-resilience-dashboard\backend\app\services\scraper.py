"""OSINT scraper: fetch headlines from configured RSS/HTML sources.

Security: every URL is validated before fetching to prevent SSRF (no private /
loopback / link-local hosts, http(s) only). Responses are size-capped.
"""
import ipaddress
import re
import socket
from datetime import datetime, timezone
from urllib.parse import urlparse

import httpx

from app.models import ScrapeSource, ScrapedItem

MAX_BYTES = 2_000_000  # 2 MB cap per response
FETCH_TIMEOUT = 20.0
MAX_ITEMS_PER_SOURCE = 25

# Collection is restricted to these four OSINT topics. Only headlines matching at
# least one topic are kept. Adjust here to change the collection focus.
TOPIC_KEYWORDS: dict[str, list[str]] = {
    "Economy": [
        "econom", "inflation", "gdp", "market", "currency", "trade", "recession",
        "employment", "interest rate", "central bank", "fiscal", "bond", "stock",
        "unemployment", "growth", "export", "import", "tariff", "budget", "debt",
        "sanction", "currency", "pricing", "energy price",
    ],
    "Flash Points": [
        "conflict", "war", "military", "nato", "escalat", "strike", "missile",
        "troop", "invasion", "border", "tension", "defen", "attack", "airstrike",
        "drone", "combat", "frontline", "security", "cessefire", "nuclear",
        "kyiv", "kremlin", "baltic", "black sea",
    ],
    "Food Shortages": [
        "food", "shortage", "famine", "hunger", "crop", "harvest", "grain",
        "agricultur", "drought", "nutrition", "starv", "rice", "wheat",
        "food security", "cereal", "livestock", "harvest fail",
    ],
    "Supply Chain": [
        "supply chain", "logistic", "shipping", "port", "freight", "bottleneck",
        "delivery", "manufactur", "warehouse", "cargo", "container", "disruption",
        "supplier", "inventory", "procurement", "semiconductor", "energy supply",
    ],
}


def detect_topics(text: str) -> list[str]:
    """Return which of the restricted OSINT topics a text matches."""
    t = (text or "").lower()
    hits = []
    for topic, kws in TOPIC_KEYWORDS.items():
        if any(kw in t for kw in kws):
            hits.append(topic)
    return hits


# Source tier -> base confidence (drives confidence-weighted score impact).
TIER_CONFIDENCE = {
    "Tier 1 - News Wires": "HIGH",
    "Tier 2 - Geopolitical Intel": "HIGH",
    "NATO / Defence": "HIGH",
    "Sanctions / Financial Warfare": "HIGH",
    "Cyber Threat Intelligence": "MEDIUM",
    "Maritime / Shipping": "MEDIUM",
    "Energy Security": "MEDIUM",
    "Infrastructure & Resilience": "MEDIUM",
    "Space & Satellite": "MEDIUM",
    "OSINT / Early Warning": "LOW",
}


_BLOCKED_HOSTS = {"localhost", "metadata.google.internal"}


class SSRFError(ValueError):
    """Raised when a URL points at an internal / disallowed target."""


def validate_public_url(url: str) -> str:
    """Validate a URL is a public http(s) address. Raises SSRFError otherwise."""
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https"):
        raise SSRFError("Only http/https URLs are allowed")
    host = (parsed.hostname or "").lower()
    if not host:
        raise SSRFError("URL has no host")
    if host in _BLOCKED_HOSTS:
        raise SSRFError("Host is not allowed")
    # Resolve and reject private/loopback/link-local/reserved addresses
    try:
        infos = socket.getaddrinfo(host, None)
    except socket.gaierror as e:
        raise SSRFError(f"Could not resolve host: {e}") from e
    for info in infos:
        ip = info[4][0]
        try:
            addr = ipaddress.ip_address(ip)
        except ValueError:
            continue
        if (
            addr.is_private
            or addr.is_loopback
            or addr.is_link_local
            or addr.is_reserved
            or addr.is_multicast
            or addr.is_unspecified
        ):
            raise SSRFError(f"Host resolves to a non-public address ({ip})")
    return url


_TAG_RE = re.compile(r"<[^>]+>")
_WS_RE = re.compile(r"\s+")


def _clean(text: str) -> str:
    text = _TAG_RE.sub("", text or "")
    text = _WS_RE.sub(" ", text).strip()
    return text


def _parse_rss(xml: str) -> list[dict]:
    """Very small RSS/Atom item extractor (stdlib-only)."""
    items: list[dict] = []
    # Split on <item> (RSS) or <entry> (Atom)
    chunks = re.split(r"<(?:item|entry)[\s>]", xml, flags=re.IGNORECASE)[1:]
    for chunk in chunks[:MAX_ITEMS_PER_SOURCE]:
        def grab(tag: str) -> str | None:
            m = re.search(
                rf"<{tag}[^>]*>(.*?)</{tag}>", chunk, flags=re.IGNORECASE | re.DOTALL
            )
            return _clean(m.group(1)) if m else None

        title = grab("title")
        if not title:
            continue
        link = grab("link")
        if not link:
            m = re.search(r'<link[^>]+href="([^"]+)"', chunk, flags=re.IGNORECASE)
            link = m.group(1) if m else None
        summary = grab("description") or grab("summary") or grab("content")
        published = grab("pubDate") or grab("published") or grab("updated")
        items.append({"title": title, "url": link, "summary": summary, "published": published})
    return items


_HEADING_RE = re.compile(
    r"<h[12][^>]*>(.*?)</h[12]>", flags=re.IGNORECASE | re.DOTALL
)


def _parse_html(html: str, base_url: str) -> list[dict]:
    """Extract h1/h2 headings as candidate headlines."""
    items: list[dict] = []
    seen: set[str] = set()
    for m in _HEADING_RE.finditer(html):
        title = _clean(m.group(1))
        if not title or len(title) < 15 or title.lower() in seen:
            continue
        seen.add(title.lower())
        items.append({"title": title, "url": base_url, "summary": None, "published": None})
        if len(items) >= MAX_ITEMS_PER_SOURCE:
            break
    return items


_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
    ),
    "Accept": "application/rss+xml, application/xml, application/atom+xml, text/xml, text/html, */*",
    "Accept-Language": "en-US,en;q=0.9",
}


async def fetch_source(source: ScrapeSource) -> list[dict]:
    """Fetch a single source and return parsed items. Raises on SSRF / network errors."""
    validate_public_url(source.url)
    async with httpx.AsyncClient(timeout=FETCH_TIMEOUT, follow_redirects=True) as client:
        resp = await client.get(source.url, headers=_HEADERS)
        resp.raise_for_status()
        content = resp.text[:MAX_BYTES]

    if source.kind == "rss" or "<rss" in content[:500].lower() or "<feed" in content[:500].lower():
        return _parse_rss(content)
    return _parse_html(content, source.url)


async def run_scrape(sources: list[ScrapeSource], db) -> dict:
    """Scrape enabled sources, keep only items matching the restricted OSINT topics,
    dedupe, and persist."""
    new_count = 0
    errors: list[str] = []
    from sqlalchemy import select

    for src in sources:
        if not src.enabled:
            continue
        try:
            items = await fetch_source(src)
        except Exception as e:  # noqa: BLE001 - collect per-source errors
            errors.append(f"{src.name}: {e}")
            continue
        for it in items:
            # Restrict collection to the four OSINT topics (Economy, Flash Points,
            # Food Shortages, Supply Chain). Skip anything irrelevant.
            text = f"{it['title']} {it.get('summary') or ''}"
            if not detect_topics(text):
                continue
            # Dedupe by (source, title)
            exists = (
                await db.execute(
                    select(ScrapedItem).where(
                        ScrapedItem.source_id == src.id,
                        ScrapedItem.title == it["title"],
                    )
                )
            ).scalar_one_or_none()
            if exists:
                continue
            db.add(
                ScrapedItem(
                    source_id=src.id,
                    title=it["title"][:1000],
                    url=it.get("url"),
                    summary=(it.get("summary") or "")[:4000] or None,
                    published=it.get("published"),
                )
            )
            new_count += 1
        src.last_fetched = datetime.now(timezone.utc).replace(tzinfo=None)
    await db.commit()
    return {"sources": len([s for s in sources if s.enabled]), "new_items": new_count, "errors": errors}
