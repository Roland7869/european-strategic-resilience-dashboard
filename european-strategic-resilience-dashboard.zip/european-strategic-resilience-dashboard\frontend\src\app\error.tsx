"use client";

import { useEffect } from "react";

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    // eslint-disable-next-line no-console
    console.error("Preps/dashboard error:", error);
  }, [error]);

  return (
    <div className="mx-auto max-w-lg py-20 text-center">
      <div className="panel p-8">
        <div className="label text-red-400">Something went wrong</div>
        <h1 className="mt-2 text-lg font-bold text-slate-100">This view hit an unexpected error</h1>
        <p className="mt-2 text-sm text-slate-400">
          Your data is safe on the server — this is only a display error. Try again, or reload the page.
        </p>
        {error?.digest && (
          <p className="mt-2 font-mono text-[11px] text-slate-600">ref: {error.digest}</p>
        )}
        <div className="mt-5 flex justify-center gap-3">
          <button className="btn btn-primary" onClick={() => reset()}>Try again</button>
          <button className="btn" onClick={() => window.location.reload()}>Reload page</button>
        </div>
      </div>
    </div>
  );
}
