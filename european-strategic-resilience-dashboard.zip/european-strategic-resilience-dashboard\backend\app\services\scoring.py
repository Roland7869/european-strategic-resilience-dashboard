"""Dashboard calculation formulas."""
from datetime import date, timedelta

from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.models import (
    Assessment, Category, Event, EventCategory, EventRegion, Side, Trend
)


async def get_category_scores(db: AsyncSession) -> list[Category]:
    result = await db.execute(select(Category).order_by(Category.current_score.desc()))
    return list(result.scalars().all())


def _weighted_side_mean(cats: list[Category], side: str) -> float:
    selected = [c for c in cats if c.side == side]
    if not selected:
        return 0.0
    # Confidence weights
    weights = {"HIGH": 1.0, "MEDIUM": 0.8, "LOW": 0.5}
    total_w = sum(weights.get(c.confidence, 0.8) for c in selected)
    if total_w == 0:
        return 0.0
    return sum(c.current_score * weights.get(c.confidence, 0.8) for c in selected) / total_w


def _trend_of(cats: list[Category], side: str) -> str:
    selected = [c for c in cats if c.side == side]
    if not selected:
        return "STABLE"
    ups = sum(1 for c in selected if c.trend == Trend.UP.value)
    downs = sum(1 for c in selected if c.trend == Trend.DOWN.value)
    if ups > downs:
        return "UP"
    if downs > ups:
        return "DOWN"
    return "STABLE"


async def strategic_surprise_index(db: AsyncSession, cats: list[Category]) -> float:
    """Volatility + high-confidence recent events + low-confidence anomalies."""
    window_start = date.today() - timedelta(days=30)
    recent = await db.execute(
        select(Event).options(selectinload(Event.confidence_level)).where(Event.event_date >= window_start)
    )
    events = list(recent.scalars().all())

    if not events:
        return 0.0

    # Score volatility (std-dev proxy of scores around mean)
    scores = [c.current_score for c in cats]
    mean = sum(scores) / len(scores) if scores else 0
    variance = sum((s - mean) ** 2 for s in scores) / len(scores) if scores else 0
    volatility = min(variance ** 0.5, 3.0) / 3.0  # 0..1

    # High-confidence event density
    high_conf = sum(1 for e in events if e.confidence_level.name == "HIGH")
    high_conf_factor = min(high_conf / 20.0, 1.0)

    # Low-confidence anomalies (tension between low-conf events and high category scores)
    low_conf = sum(1 for e in events if e.confidence_level.name == "LOW")
    anomaly = min(low_conf / 15.0, 1.0) * (mean / 10.0)

    surprise = (volatility * 0.35 + high_conf_factor * 0.35 + anomaly * 0.30) * 100
    return round(min(max(surprise, 0), 100), 1)


async def event_density_index(db: AsyncSession) -> float:
    """Events per day over rolling window vs baseline (0-100)."""
    today = date.today()
    window = today - timedelta(days=14)
    baseline_start = today - timedelta(days=90)

    window_count = await db.execute(
        select(func.count(Event.id)).where(Event.event_date >= window, Event.event_date <= today)
    )
    baseline_count = await db.execute(
        select(func.count(Event.id)).where(Event.event_date >= baseline_start, Event.event_date < window)
    )
    wc = window_count.scalar() or 0
    bc = baseline_count.scalar() or 0

    # Baseline is over 76 days, window over 14 days. Normalize to per-day.
    baseline_daily = bc / 76.0 if bc else 0.1
    window_daily = wc / 14.0

    ratio = window_daily / baseline_daily if baseline_daily else 1.0
    density = min(ratio, 3.0) / 3.0 * 100
    return round(density, 1)


async def compute_summary(db: AsyncSession) -> dict:
    cats = await get_category_scores(db)
    threat = _weighted_side_mean(cats, Side.threat.value)
    resilience = _weighted_side_mean(cats, Side.resilience.value)
    threat_trend = _trend_of(cats, Side.threat.value)
    resilience_trend = _trend_of(cats, Side.resilience.value)
    surprise = await strategic_surprise_index(db, cats)
    density = await event_density_index(db)
    from app.services.scoring_discipline import strategic_friction_index
    sfi = await strategic_friction_index(db)

    from app.services.rule_engine import compute_overall_status
    overall = compute_overall_status(cats)

    return {
        "threat_score": round(threat, 2),
        "resilience_score": round(resilience, 2),
        "threat_trend": threat_trend,
        "resilience_trend": resilience_trend,
        "strategic_surprise_index": surprise,
        "event_density_index": density,
        "strategic_friction_index": sfi["index"],
        "friction_signals": sfi["signals"],
        "overall_status": overall,
    }


async def heatmap_data(db: AsyncSession) -> list[dict]:
    """Category x recent-week matrix of event counts."""
    today = date.today()
    weeks = [today - timedelta(days=7 * i) for i in range(6)]
    rows = []
    cats = await get_category_scores(db)
    for cat in cats:
        cell = {"category": cat.name, "side": cat.side, "weeks": []}
        for i in range(len(weeks) - 1, -1, -1):
            end = weeks[i]
            start = weeks[i + 1] if i + 1 < len(weeks) else today - timedelta(days=42)
            count = await db.execute(
                select(func.count(EventCategory.id))
                .join(Event, Event.id == EventCategory.event_id)
                .where(
                    EventCategory.category_id == cat.id,
                    Event.event_date >= start,
                    Event.event_date <= end,
                )
            )
            cell["weeks"].append({"week": end.isoformat(), "count": count.scalar() or 0})
        rows.append(cell)
    return rows


async def timeline_data(db: AsyncSession) -> list[dict]:
    """Event counts over last 12 weeks + average threat score proxy."""
    today = date.today()
    rows = []
    for i in range(11, -1, -1):
        end = today - timedelta(days=7 * i)
        start = end - timedelta(days=7)
        count = await db.execute(
            select(func.count(Event.id)).where(Event.event_date > start, Event.event_date <= end)
        )
        rows.append({"date": end.isoformat(), "events": count.scalar() or 0})
    return rows


async def radar_data(db: AsyncSession) -> list[dict]:
    cats = await get_category_scores(db)
    return [
        {"category": c.name, "side": c.side, "score": c.current_score}
        for c in cats
    ]


async def histogram_data(db: AsyncSession) -> list[dict]:
    """Distribution of category scores in buckets of 1."""
    cats = await get_category_scores(db)
    buckets = {i: {"bucket": f"{i}-{i+1}", "count": 0, "threat": 0, "resilience": 0} for i in range(10)}
    for c in cats:
        idx = min(int(c.current_score), 9)
        buckets[idx]["count"] += 1
        buckets[idx]["threat" if c.side == Side.threat.value else "resilience"] += 1
    return list(buckets.values())


async def confidence_distribution(db: AsyncSession) -> list[dict]:
    from app.models import ConfidenceLevel
    rows = []
    levels = await db.execute(select(ConfidenceLevel).order_by(ConfidenceLevel.rank.desc()))
    for lvl in levels.scalars().all():
        count = await db.execute(
            select(func.count(Event.id)).where(Event.confidence_level_id == lvl.id)
        )
        rows.append({"level": lvl.name, "count": count.scalar() or 0})
    return rows


async def flashpoints(db: AsyncSession, limit: int = 6) -> list[dict]:
    """Compute the hottest regions (flashpoints) by event density + implicated threat scores.

    A flashpoint = a region where recent activity concentrates across high-scoring
    threat categories. Returned hottest-first for the executive assessment.
    """
    from sqlalchemy.orm import selectinload
    from app.models import EventRegion as ER, Region

    window_start = date.today() - timedelta(days=120)

    # All recent events with their regions + category links eagerly loaded
    result = await db.execute(
        select(Event)
        .options(
            selectinload(Event.region_links).selectinload(ER.region),
            selectinload(Event.category_links).selectinload(EventCategory.category),
        )
        .where(Event.event_date >= window_start)
    )
    events = list(result.scalars().unique().all())

    region_events: dict[int, dict] = {}
    for ev in events:
        for rl in ev.region_links:
            rid = rl.region_id
            rname = rl.region.name
            bucket = region_events.setdefault(
                rid, {"region": rname, "count": 0, "cats": {}}
            )
            bucket["count"] += 1
            for cl in ev.category_links:
                cat = cl.category
                # Only threat-side categories contribute to a flashpoint
                if cat.side != "threat":
                    continue
                prev = bucket["cats"].get(cat.name, 0.0)
                # keep the highest current score seen for that category
                bucket["cats"][cat.name] = max(prev, cat.current_score)

    flash = []
    for rid, b in region_events.items():
        cats_sorted = sorted(b["cats"].items(), key=lambda kv: kv[1], reverse=True)[:3]
        # intensity = activity weighted by top threat scores
        intensity = round(
            b["count"] * (sum(c[1] for c in cats_sorted) / max(len(cats_sorted), 1)) / 10.0, 2
        )
        flash.append(
            {
                "region": b["region"],
                "event_count": b["count"],
                "top_categories": [
                    {"name": n, "score": s} for n, s in cats_sorted
                ],
                "intensity": intensity,
            }
        )
    flash.sort(key=lambda f: f["intensity"], reverse=True)
    return flash[:limit]
