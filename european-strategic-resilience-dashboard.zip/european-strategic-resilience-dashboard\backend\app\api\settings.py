"""App settings: LM Studio endpoint/model + the owner's Run-to-Store threshold.

Values persist in the app_settings key/value table so they survive restarts.
"""
from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings as env_settings
from app.database import get_db
from app.api.preps import get_setting, set_setting
from app.schemas import AppSettingsIn, AppSettingsOut

router = APIRouter(prefix="/settings", tags=["settings"])

DEFAULT_RUN_TO_STORE = 7.0


def _truthy(v: str | None, default: bool) -> bool:
    if v is None:
        return default
    return str(v).strip().lower() in ("1", "true", "yes", "on")


@router.get("", response_model=AppSettingsOut)
async def get_settings(db: AsyncSession = Depends(get_db)):
    thr = await get_setting(db, "run_to_store_threshold", str(DEFAULT_RUN_TO_STORE))
    base = await get_setting(db, "lmstudio_base_url", env_settings.LMSTUDIO_BASE_URL)
    model = await get_setting(db, "lmstudio_model", env_settings.LMSTUDIO_MODEL)
    auto = _truthy(await get_setting(db, "auto_approve", None), True)  # default ON
    try:
        threshold = float(thr or DEFAULT_RUN_TO_STORE)
    except ValueError:
        threshold = DEFAULT_RUN_TO_STORE
    return AppSettingsOut(
        lmstudio_base_url=base,
        lmstudio_model=model,
        run_to_store_threshold=threshold,
        auto_approve=auto,
    )


@router.post("", response_model=AppSettingsOut)
async def update_settings(payload: AppSettingsIn, db: AsyncSession = Depends(get_db)):
    # Keep the in-process config in sync for the AI client
    if payload.lmstudio_base_url is not None:
        env_settings.LMSTUDIO_BASE_URL = payload.lmstudio_base_url
        await set_setting(db, "lmstudio_base_url", payload.lmstudio_base_url)
    if payload.lmstudio_model is not None:
        env_settings.LMSTUDIO_MODEL = payload.lmstudio_model
        await set_setting(db, "lmstudio_model", payload.lmstudio_model)
    if payload.run_to_store_threshold is not None:
        await set_setting(db, "run_to_store_threshold", str(payload.run_to_store_threshold))
    if payload.auto_approve is not None:
        await set_setting(db, "auto_approve", "true" if payload.auto_approve else "false")
    await db.commit()
    return await get_settings(db)
