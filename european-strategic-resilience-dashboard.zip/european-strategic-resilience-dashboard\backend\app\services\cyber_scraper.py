"""Cyber-attack scraper: fetch threat-intelligence feeds and classify each headline
by severity and attack type. Reuses the SSRF-safe fetch from the OSINT scraper."""
from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import select

from app.models import CyberAttack, CyberAttackSource
from app.services.scraper import fetch_source  # SSRF-validated fetch + RSS/HTML parse

# Severity signals (checked in order; first strong match wins the level).
SEVERITY_SIGNALS: list[tuple[str, list[str]]] = [
    ("CRITICAL", [
        "critical", "actively exploited", "zero-day", "0-day", "wiper", "destructive",
        "ransomware", "major breach", "nation-state", "critical infrastructure",
        "catastrophic", "emergency patch",
    ]),
    ("HIGH", [
        "high severity", "high-risk", "targeted", "apt", "espionage", "supply chain",
        "data breach", "leak", "vulnerability", "cve-", "ddos", "attack", "breach",
        "compromise", "hacked", "intrusion",
    ]),
    ("MEDIUM", ["flaw", "bug", "vulnerability", "patch", "warning", "advisory", "risk"]),
    ("LOW", ["update", "report", "study", "research", "guidance", "best practice"]),
]

ATTACK_TYPES: list[tuple[str, list[str]]] = [
    ("Ransomware", ["ransomware", "ransom", "lockbit", "contiu", "blackcat", "encrypt"]),
    ("Data Breach", ["data breach", "breach", "leak", "stolen data", "exfiltrat", "dump"]),
    ("DDoS", ["ddos", "denial of service", "botnet", "traffic surge"]),
    ("Wiper / Destructive", ["wiper", "destructive", "disk wiping", "hermeticwiper"]),
    ("Espionage", ["espionage", "apt", "spying", "state-sponsored", "surveillance"]),
    ("Supply Chain", ["supply chain", "third-party", "vendor", "software supply"]),
    ("Vulnerability / Exploit", ["vulnerability", "cve-", "zero-day", "0-day", "exploit", "rce"]),
    ("Critical Infrastructure", ["critical infrastructure", "scada", "ics", "ot network", "grid", "pipeline"]),
    ("Credential Theft", ["credential", "phishing", "password", "mfa bypass", "session hijack"]),
]


def classify_severity(text: str) -> str:
    t = (text or "").lower()
    for level, kws in SEVERITY_SIGNALS:
        if any(k in t for k in kws):
            return level
    return "MEDIUM"


def classify_type(text: str) -> str:
    t = (text or "").lower()
    for name, kws in ATTACK_TYPES:
        if any(k in t for k in kws):
            return name
    return "Other"


async def scrape_cyber(sources: list[CyberAttackSource], db) -> dict:
    """Scrape enabled cyber sources, classify severity + type, dedupe, persist."""
    new_count = 0
    errors: list[str] = []
    for src in sources:
        if not src.enabled:
            continue
        try:
            items = await fetch_source(src)
        except Exception as e:  # noqa: BLE001 - collect per-source errors
            errors.append(f"{src.name}: {e}")
            continue
        for it in items:
            text = f"{it['title']} {it.get('summary') or ''}"
            exists = (
                await db.execute(
                    select(CyberAttack).where(
                        CyberAttack.source_id == src.id,
                        CyberAttack.title == it["title"],
                    )
                )
            ).scalar_one_or_none()
            if exists:
                continue
            db.add(CyberAttack(
                source_id=src.id,
                title=it["title"][:1000],
                summary=(it.get("summary") or "")[:4000] or None,
                url=it.get("url"),
                severity=classify_severity(text),
                attack_type=classify_type(text),
            ))
            new_count += 1
        src.last_fetched = datetime.now(timezone.utc).replace(tzinfo=None)
    await db.commit()
    return {"sources": len([s for s in sources if s.enabled]), "new_attacks": new_count, "errors": errors}
