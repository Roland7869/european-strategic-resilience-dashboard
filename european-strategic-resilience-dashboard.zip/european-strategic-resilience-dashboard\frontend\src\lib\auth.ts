import type { NextAuthOptions } from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";

// AUTH STUB — NextAuth is wired in but the app runs open locally.
// Add real user records + hashed passwords to enable login later.
export const authOptions: NextAuthOptions = {
  providers: [
    CredentialsProvider({
      name: "Credentials",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials) {
        // Stub: accept any non-empty credentials for local development.
        if (credentials?.email && credentials?.password) {
          return { id: "1", email: credentials.email, name: "Analyst" };
        }
        return null;
      },
    }),
  ],
  session: { strategy: "jwt" },
  pages: { signIn: "/api/auth/signin" },
  secret: process.env.NEXTAUTH_SECRET || "change-me-in-production",
};
