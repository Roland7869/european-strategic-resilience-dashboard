"""Scoring discipline — enforces the analyst scoring governance rules.

Core rules:
- 10.0 is reserved for an active strategic emergency with multiple independent
  confirmations, immediate operational consequences and no higher escalation
  category. Never more than ~15% of tracked threat indicators sit at 10.0 at once.
- Under uncertainty prefer 7.0–9.5 over 10.0.
- Score only severity, strategic importance, escalation potential and systemic
  impact. Event frequency is a SEPARATE metric and must not drive scores.
- Confidence-weighted score impact: HIGH 100%, MEDIUM 50%, LOW 25%,
  UNVERIFIED social media = watchlist only (no score adjustment).
"""
from __future__ import annotations

import math
from datetime import datetime, timedelta, timezone

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import Category, Side

CONFIDENCE_WEIGHTS = {"HIGH": 1.0, "MEDIUM": 0.5, "LOW": 0.25}
UNVERIFIED_SOURCE_TYPES = {"Social Media", "Rumour", "Unverified Claim"}
MAX_TEN_FRACTION = 0.15  # at most 15% of threat indicators at 10.0
DEMOTED_TEN_SCORE = 9.5  # default demotion target for capped 10.0s

# --- State-estimation tuning (anti-inflation) --------------------------------
# More feeds => more corroboration => higher CONFIDENCE, not automatically a
# higher SCORE. A category only moves when the underlying state materially
# changes; repeated reports of the same state are corroboration.
CONFIDENCE_PCT_BASE = {"HIGH": 85.0, "MEDIUM": 60.0, "LOW": 35.0}
UNVERIFIED_PCT = 15.0
CORROBORATION_BOOST = {"HIGH": 8.0, "MEDIUM": 5.0, "LOW": 2.5}  # confidence_pct added per corroborating event
CORROBORATION_WINDOW_HOURS = 48  # within this, new events corroborate rather than re-score
MAX_DELTA_PER_EVENT = 0.5        # hard cap on a single event's weighted impact
MAX_DAILY_MOVEMENT = 0.25        # max |score| movement per rolling 24h
MAX_48H_MOVEMENT = 0.50          # max |score| movement per rolling 48h
CRITICAL_SEVERITY = "CRITICAL"   # bypasses rate limits (real state break)


def _utcnow() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


def confidence_weight(confidence_name: str | None, source_type_name: str | None = None) -> float:
    """Return the score-impact multiplier for a confidence level / source type."""
    if source_type_name in UNVERIFIED_SOURCE_TYPES:
        return 0.0  # unverified social media: watchlist only
    return CONFIDENCE_WEIGHTS.get((confidence_name or "MEDIUM").upper(), 0.5)


def weighted_delta(raw_delta: float, confidence_name: str | None, source_type_name: str | None = None) -> float:
    """Apply the confidence adjustment to a raw score delta."""
    return raw_delta * confidence_weight(confidence_name, source_type_name)


def _base_pct(confidence_name: str | None) -> float:
    return CONFIDENCE_PCT_BASE.get((confidence_name or "MEDIUM").upper(), 60.0)


def _rolling_abs(current: float | None, start: datetime | None, now: datetime, hours: int) -> tuple[float, datetime]:
    """Return (movement_since_start, window_start), resetting the window if expired."""
    if start is None or (now - start).total_seconds() / 3600.0 >= hours:
        return 0.0, now
    return current or 0.0, start


def apply_intelligence_impact(
    cat: Category,
    raw_delta: float,
    confidence_name: str | None,
    source_type_name: str | None = None,
    severity: str | None = None,
    when: datetime | None = None,
) -> float:
    """State-estimation impact: corroboration raises confidence; only a material
    state change (outside the corroboration window, or CRITICAL severity) moves the
    score, and then only within rate-of-change limits.

    Returns the score delta actually applied (0.0 if this was corroboration-only).
    """
    now = when or _utcnow()
    weight = confidence_weight(confidence_name, source_type_name)
    is_critical = (severity or "").upper() == CRITICAL_SEVERITY

    # 1) Corroboration always increases confidence + count (more evidence => more certainty).
    cat.corroboration_count = (cat.corroboration_count or 0) + 1
    current_pct = cat.confidence_pct if cat.confidence_pct is not None else _base_pct(confidence_name)
    if weight > 0.0:
        boost = CORROBORATION_BOOST.get((confidence_name or "MEDIUM").upper(), 2.5)
        current_pct = min(100.0, current_pct + boost)
    else:
        current_pct = min(100.0, current_pct + 1.0)  # weak signal: tiny confidence nudge only
    # On a state change, never let confidence sit below the source's base level.
    cat.confidence_pct = current_pct

    if weight == 0.0:
        return 0.0  # unverified social: watchlist only, no score impact

    # 2) State vs signal: decide whether this materially changes the picture.
    last_state = cat.last_state_change_at
    within_window = (
        last_state is not None
        and (now - last_state).total_seconds() / 3600.0 < CORROBORATION_WINDOW_HOURS
    )
    if within_window and not is_critical:
        # Corroboration of an already-scored state -> confidence rose, score unchanged.
        return 0.0

    # 3) Material state change -> move the score, but rate-limited.
    eff = raw_delta * weight
    if not is_critical:
        eff = max(-MAX_DELTA_PER_EVENT, min(MAX_DELTA_PER_EVENT, eff))
        cat.move_24h, cat.move_24h_start = _rolling_abs(cat.move_24h, cat.move_24h_start, now, 24)
        cat.move_48h, cat.move_48h_start = _rolling_abs(cat.move_48h, cat.move_48h_start, now, 48)
        remaining = min(
            MAX_DAILY_MOVEMENT - (cat.move_24h or 0.0),
            MAX_48H_MOVEMENT - (cat.move_48h or 0.0),
        )
        if remaining <= 0.0:
            return 0.0  # movement budget exhausted for now
        if abs(eff) > remaining:
            eff = math.copysign(remaining, eff)

    if eff == 0.0:
        return 0.0
    cat.current_score = min(max(cat.current_score + eff, 0.0), 10.0)
    cat.move_24h = (cat.move_24h or 0.0) + abs(eff)
    cat.move_48h = (cat.move_48h or 0.0) + abs(eff)
    cat.last_state_change_at = now
    cat.confidence_pct = min(100.0, max(cat.confidence_pct or 0.0, _base_pct(confidence_name)))
    if eff > 0:
        cat.trend = "UP"
    elif eff < 0:
        cat.trend = "DOWN"
    return eff


def apply_score_change(cat: Category, raw_delta: float, confidence_name: str | None, source_type_name: str | None = None) -> float:
    """Legacy path (kept for compatibility): confidence-weighted delta, no state logic."""
    eff = weighted_delta(raw_delta, confidence_name, source_type_name)
    if eff == 0.0:
        return 0.0
    cat.current_score = min(max(cat.current_score + eff, 0.0), 10.0)
    if eff > 0:
        cat.trend = "UP"
    elif eff < 0:
        cat.trend = "DOWN"
    return eff


def enforce_ten_cap(categories: list[Category]) -> list[str]:
    """Cap the number of threat indicators at 10.0 to <= ~15%.

    Demotes the lowest-confidence 10.0s to DEMOTED_TEN_SCORE. Returns names demoted.
    """
    threat = [c for c in categories if c.side == Side.threat.value]
    n = len(threat)
    if n == 0:
        return []
    max_ten = max(1, int(n * MAX_TEN_FRACTION))
    at_ten = [c for c in threat if c.current_score >= 9.99]
    if len(at_ten) <= max_ten:
        return []
    # Demote lowest-confidence first
    excess = sorted(at_ten, key=lambda c: CONFIDENCE_WEIGHTS.get(c.confidence, 0.5))
    to_demote = excess[: len(at_ten) - max_ten]
    for c in to_demote:
        c.current_score = DEMOTED_TEN_SCORE
    return [c.name for c in to_demote]


# --- Strategic Friction Index -------------------------------------------------
# Maps existing categories to the five friction signals. Resilience-side
# categories inside a friction signal are inverted (10 - score) so a stronger
# resilience lowers the friction reading.

SFI_SIGNALS: dict[str, list[tuple[str, bool]]] = {
    # signal -> [(category_name, invert?)]
    "active_crises": [
        ("Multi-Theatre Stress", False),
        ("Eastern Flank Pressure", False),
        ("Middle East Escalation", False),
        ("Korean Peninsula Tension", False),
    ],
    "political_polarization": [
        ("Strategic Divergence", False),
        ("Trust Architecture", False),
    ],
    "economic_friction": [
        ("Dependency Risk", False),
        ("Financial Resilience", True),   # stronger resilience = less friction
    ],
    "information_warfare": [
        ("Information Warfare", False),
        ("Hybrid Warfare", False),
    ],
    "infrastructure_stress": [
        ("Critical Infrastructure Vulnerability", False),
        ("Air Defence Scarcity", False),
    ],
}


async def strategic_friction_index(db: AsyncSession) -> dict:
    """Compute the Strategic Friction Index (0-10) and its five sub-signals."""
    cats = list((await db.execute(select(Category))).scalars().all())
    by_name = {c.name: c for c in cats}

    signals: dict[str, float] = {}
    for signal, mapping in SFI_SIGNALS.items():
        vals: list[float] = []
        for name, invert in mapping:
            c = by_name.get(name)
            if not c:
                continue
            v = 10.0 - c.current_score if invert else c.current_score
            vals.append(v)
        signals[signal] = round(sum(vals) / len(vals), 2) if vals else 0.0

    index = round(sum(signals.values()) / len(signals), 2) if signals else 0.0
    return {"index": index, "signals": signals}
