"use client";

import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import type { Settings } from "@/lib/types";
import { CONFIDENCE_SCALE } from "@/lib/constants";

export default function SettingsPage() {
  const [settings, setSettings] = useState<Settings | null>(null);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api.getSettings().then(setSettings).catch((e) => setError(String(e)));
  }, []);

  const save = async () => {
    if (!settings) return;
    try {
      const s = await api.updateSettings(settings);
      setSettings(s);
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    } catch (e) {
      setError(String(e));
    }
  };

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-lg font-bold tracking-wide">Settings</h1>
        <p className="text-xs text-slate-500">Local-first configuration. AI endpoint points at LM Studio.</p>
      </div>

      {error && <div className="panel border-red-500/40 p-4 text-sm text-red-400">{error}</div>}

      <div className="panel">
        <div className="panel-header">
          <span className="text-[12px] font-bold uppercase tracking-wider">LM Studio (AI Endpoint)</span>
        </div>
        <div className="grid grid-cols-1 gap-3 p-4 md:grid-cols-2">
          <div>
            <label className="label">Base URL</label>
            <input
              className="mt-1 w-full"
              value={settings?.lmstudio_base_url || ""}
              onChange={(e) => setSettings({ ...settings!, lmstudio_base_url: e.target.value })}
              placeholder="http://localhost:1234/v1"
            />
            <p className="mt-1 text-[10px] text-slate-500">
              OpenAI-compatible endpoint. Default LM Studio: http://localhost:1234/v1
            </p>
          </div>
          <div>
            <label className="label">Model</label>
            <input
              className="mt-1 w-full"
              value={settings?.lmstudio_model || ""}
              onChange={(e) => setSettings({ ...settings!, lmstudio_model: e.target.value })}
              placeholder="google/gemma-4-e2b"
            />
            <p className="mt-1 text-[10px] text-slate-500">
              Must match a model loaded in LM Studio.
            </p>
          </div>
          <div className="md:col-span-2">
            <label className="label">Run-to-Store threshold (0–10)</label>
            <input
              type="number"
              step="0.1"
              min="0"
              max="10"
              className="mt-1 w-full md:w-48"
              value={settings?.run_to_store_threshold ?? 7}
              onChange={(e) => setSettings({ ...settings!, run_to_store_threshold: Number(e.target.value) })}
            />
            <p className="mt-1 text-[10px] text-slate-500">
              When the threat environment reaches this level, the AI reviews your Preps and suggests what to top up.
            </p>
          </div>
          <div className="md:col-span-2">
            <label className="flex items-center gap-2 text-[12px] text-slate-300">
              <input
                type="checkbox"
                checked={settings?.auto_approve ?? true}
                onChange={(e) => setSettings({ ...settings!, auto_approve: e.target.checked })}
              />
              Auto-approve AI score proposals
            </label>
            <p className="mt-1 text-[10px] text-slate-500">
              When on, AI score-change suggestions are applied immediately (no manual approval step).
            </p>
          </div>
          <div className="md:col-span-2 flex justify-end">
            <button className="btn btn-primary" onClick={save}>Save Settings</button>
            {saved && <span className="ml-3 self-center text-[12px] text-emerald-400">Saved ✓</span>}
          </div>
        </div>
      </div>

      <div className="panel">
        <div className="panel-header">
          <span className="text-[12px] font-bold uppercase tracking-wider">Confidence Scale</span>
        </div>
        <div className="divide-y divide-[#1a2334]">
          {CONFIDENCE_SCALE.map((c) => (
            <div key={c.level} className="flex items-start gap-3 px-4 py-2.5">
              <span
                className="badge mt-0.5"
                style={{
                  color: c.level === "HIGH" ? "#22c55e" : c.level === "MEDIUM" ? "#eab308" : "#94a3b8",
                  borderColor: "#2a3a55",
                }}
              >
                {c.level}
              </span>
              <span className="text-[12px] text-slate-300">{c.sources}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="panel">
        <div className="panel-header">
          <span className="text-[12px] font-bold uppercase tracking-wider">Verification Status Rules</span>
        </div>
        <div className="p-4 text-[12px] leading-relaxed text-slate-300">
          The rule engine automatically derives a verification badge from source type + confidence:
          <ul className="mt-2 space-y-1">
            <li>• <strong className="text-emerald-400">Confirmed</strong> — high-trust source + HIGH confidence</li>
            <li>• <strong className="text-blue-400">Reported</strong> — high-trust source, or medium-trust with HIGH confidence</li>
            <li>• <strong className="text-yellow-400">Claimed</strong> — medium-trust source</li>
            <li>• <strong className="text-orange-400">Speculated</strong> — low-trust source with elevated confidence</li>
            <li>• <strong className="text-slate-400">Unverified</strong> — low-trust source + LOW confidence</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
