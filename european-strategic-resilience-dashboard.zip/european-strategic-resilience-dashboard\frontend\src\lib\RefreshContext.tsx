"use client";

import { createContext, useCallback, useContext, useState } from "react";

type RefreshCtx = {
  refreshKey: number;
  refresh: () => void;
};

const Ctx = createContext<RefreshCtx>({ refreshKey: 0, refresh: () => {} });

export function RefreshProvider({ children }: { children: React.ReactNode }) {
  const [refreshKey, setRefreshKey] = useState(0);
  const refresh = useCallback(() => setRefreshKey((k) => k + 1), []);
  return <Ctx.Provider value={{ refreshKey, refresh }}>{children}</Ctx.Provider>;
}

export function useRefresh() {
  return useContext(Ctx);
}
