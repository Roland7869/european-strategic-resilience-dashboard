"""Rule engine: verification status derivation and Run-To-Shop status matrix."""
from datetime import date

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import Category, ConfidenceLevel, Event, SourceType, Side


# --- Verification status ---
HIGH_TRUST_TYPES = {"Government Statement", "Military Report", "Intelligence Assessment", "Official Publication"}
MEDIUM_TRUST_TYPES = {"Major Media", "Expert Analysis", "Open-Source Intelligence"}
LOW_TRUST_TYPES = {"Social Media", "Rumour", "Unverified Claim"}


def derive_status(source_type_name: str, confidence_name: str) -> str:
    st = source_type_name
    conf = confidence_name
    if st in HIGH_TRUST_TYPES and conf == "HIGH":
        return "CONFIRMED"
    if st in HIGH_TRUST_TYPES or (st in MEDIUM_TRUST_TYPES and conf == "HIGH"):
        return "REPORTED"
    if st in MEDIUM_TRUST_TYPES and conf == "MEDIUM":
        return "REPORTED"
    if st in MEDIUM_TRUST_TYPES:
        return "CLAIMED"
    if st in LOW_TRUST_TYPES and conf == "LOW":
        return "UNVERIFIED"
    if st in LOW_TRUST_TYPES:
        return "SPECULATED"
    return "UNVERIFIED"


STATUS_BADGES = {
    "CONFIRMED": {"color": "#22c55e", "label": "Confirmed"},
    "REPORTED": {"color": "#3b82f6", "label": "Reported"},
    "CLAIMED": {"color": "#eab308", "label": "Claimed"},
    "SPECULATED": {"color": "#f97316", "label": "Speculated"},
    "UNVERIFIED": {"color": "#94a3b8", "label": "Unverified"},
}


# --- Run-To-Shop status matrix ---
GREEN_MAX = 3.5
YELLOW_MAX = 6.0
ORANGE_MAX = 8.5
ORANGE_CONCURRENT_THRESHOLD = 7.0  # category score considered "elevated"
ORANGE_CONCURRENT_MIN = 3          # need at least this many concurrent elevated categories


def compute_overall_status(
    cats: list[Category],
    *,
    direct_nato_russia_clash: bool = False,
    major_infrastructure_catastrophe: bool = False,
    mass_casualty_hybrid_attack: bool = False,
    systemic_collapse: bool = False,
) -> str:
    if direct_nato_russia_clash or major_infrastructure_catastrophe or mass_casualty_hybrid_attack or systemic_collapse:
        return "RED"

    threat_cats = [c for c in cats if c.side == Side.threat.value]
    elevated = [c for c in threat_cats if c.current_score >= ORANGE_CONCURRENT_THRESHOLD]

    max_score = max((c.current_score for c in threat_cats), default=0)

    if len(elevated) >= ORANGE_CONCURRENT_MIN:
        return "ORANGE"
    if max_score >= ORANGE_MAX:
        return "ORANGE"
    if max_score >= YELLOW_MAX:
        return "YELLOW"
    return "GREEN"


async def refresh_event_status(db: AsyncSession, event: Event) -> None:
    st = await db.get(SourceType, event.source_type_id)
    cl = await db.get(ConfidenceLevel, event.confidence_level_id)
    if st and cl:
        event.status = derive_status(st.name, cl.name)
