from datetime import date, datetime
from enum import Enum as PyEnum

from sqlalchemy import (
    Boolean, Date, DateTime, Float, ForeignKey, Integer, String, Text, UniqueConstraint, func
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database import Base


class Side(str, PyEnum):
    threat = "threat"
    resilience = "resilience"


class Trend(str, PyEnum):
    UP = "UP"
    DOWN = "DOWN"
    STABLE = "STABLE"


class Confidence(str, PyEnum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"


class EventStatus(str, PyEnum):
    CONFIRMED = "CONFIRMED"
    REPORTED = "REPORTED"
    CLAIMED = "CLAIMED"
    SPECULATED = "SPECULATED"
    UNVERIFIED = "UNVERIFIED"


class ProposalStatus(str, PyEnum):
    PENDING = "PENDING"
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"


class UserRole(str, PyEnum):
    admin = "admin"
    analyst = "analyst"
    viewer = "viewer"


class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    email: Mapped[str] = mapped_column(String, unique=True, index=True)
    name: Mapped[str] = mapped_column(String)
    hashed_password: Mapped[str] = mapped_column(String)
    role: Mapped[str] = mapped_column(String, default=UserRole.analyst.value)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())


class Category(Base):
    __tablename__ = "categories"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String, unique=True, index=True)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    side: Mapped[str] = mapped_column(String, default=Side.threat.value)
    current_score: Mapped[float] = mapped_column(Float, default=0.0)
    confidence: Mapped[str] = mapped_column(String, default=Confidence.MEDIUM.value)
    trend: Mapped[str] = mapped_column(String, default=Trend.STABLE.value)
    # Intelligence-grade dimensions (state estimation, not signal accumulation):
    confidence_pct: Mapped[float] = mapped_column(Float, default=60.0)   # 0-100, rises with corroboration
    corroboration_count: Mapped[int] = mapped_column(Integer, default=0) # supporting sources/events
    last_state_change_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    # Rolling absolute score-movement budgets for rate-of-change limits:
    move_24h: Mapped[float] = mapped_column(Float, default=0.0)
    move_24h_start: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    move_48h: Mapped[float] = mapped_column(Float, default=0.0)
    move_48h_start: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), onupdate=func.now())

    event_links: Mapped[list["EventCategory"]] = relationship(back_populates="category")


class Region(Base):
    __tablename__ = "regions"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String, unique=True, index=True)
    lat: Mapped[float] = mapped_column(Float)
    lng: Mapped[float] = mapped_column(Float)
    event_links: Mapped[list["EventRegion"]] = relationship(back_populates="region")


class ConfidenceLevel(Base):
    __tablename__ = "confidence_levels"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String, unique=True)
    rank: Mapped[int] = mapped_column(Integer)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)


class SourceType(Base):
    __tablename__ = "source_types"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String, unique=True)
    default_confidence: Mapped[str] = mapped_column(String, default=Confidence.MEDIUM.value)


class Source(Base):
    __tablename__ = "sources"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String)
    source_type_id: Mapped[int] = mapped_column(ForeignKey("source_types.id"))
    url: Mapped[str | None] = mapped_column(String, nullable=True)
    reliability_note: Mapped[str | None] = mapped_column(Text, nullable=True)

    source_type: Mapped[SourceType] = relationship()


class Event(Base):
    __tablename__ = "events"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    entry_number: Mapped[int] = mapped_column(Integer, unique=True, index=True)
    title: Mapped[str] = mapped_column(String)
    event_date: Mapped[date] = mapped_column(Date)
    source_id: Mapped[int] = mapped_column(ForeignKey("sources.id"))
    source_type_id: Mapped[int] = mapped_column(ForeignKey("source_types.id"))
    confidence_level_id: Mapped[int] = mapped_column(ForeignKey("confidence_levels.id"))
    summary: Mapped[str] = mapped_column(Text)
    evidence_notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    analyst_notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    status: Mapped[str] = mapped_column(String, default=EventStatus.REPORTED.value)
    severity: Mapped[str] = mapped_column(String, default="MEDIUM")  # LOW | MEDIUM | HIGH | CRITICAL
    created_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), onupdate=func.now())

    source: Mapped[Source] = relationship()
    source_type: Mapped[SourceType] = relationship()
    confidence_level: Mapped[ConfidenceLevel] = relationship()
    category_links: Mapped[list["EventCategory"]] = relationship(back_populates="event", cascade="all, delete-orphan")
    region_links: Mapped[list["EventRegion"]] = relationship(back_populates="event", cascade="all, delete-orphan")
    attachments: Mapped[list["Attachment"]] = relationship(back_populates="event", cascade="all, delete-orphan")


class EventCategory(Base):
    __tablename__ = "event_categories"
    __table_args__ = (UniqueConstraint("event_id", "category_id"),)
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    event_id: Mapped[int] = mapped_column(ForeignKey("events.id", ondelete="CASCADE"))
    category_id: Mapped[int] = mapped_column(ForeignKey("categories.id"))
    impact_delta: Mapped[float] = mapped_column(Float, default=0.0)

    event: Mapped[Event] = relationship(back_populates="category_links")
    category: Mapped[Category] = relationship(back_populates="event_links")


class EventRegion(Base):
    __tablename__ = "event_regions"
    __table_args__ = (UniqueConstraint("event_id", "region_id"),)
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    event_id: Mapped[int] = mapped_column(ForeignKey("events.id", ondelete="CASCADE"))
    region_id: Mapped[int] = mapped_column(ForeignKey("regions.id"))

    event: Mapped[Event] = relationship(back_populates="region_links")
    region: Mapped[Region] = relationship(back_populates="event_links")


class Assessment(Base):
    __tablename__ = "assessments"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    category_id: Mapped[int] = mapped_column(ForeignKey("categories.id"))
    score: Mapped[float] = mapped_column(Float)
    confidence: Mapped[str] = mapped_column(String)
    trend: Mapped[str] = mapped_column(String)
    rationale: Mapped[str | None] = mapped_column(Text, nullable=True)
    effective_date: Mapped[date] = mapped_column(Date)
    created_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    category: Mapped[Category] = relationship()


class Report(Base):
    __tablename__ = "reports"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    report_type: Mapped[str] = mapped_column(String)  # DAILY | WEEKLY | EXECUTIVE
    content_json: Mapped[str] = mapped_column(Text)
    format: Mapped[str] = mapped_column(String, default="markdown")
    created_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())


class Watchlist(Base):
    __tablename__ = "watchlists"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    items: Mapped[list["WatchlistItem"]] = relationship(back_populates="watchlist", cascade="all, delete-orphan")


class WatchlistItem(Base):
    __tablename__ = "watchlist_items"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    watchlist_id: Mapped[int] = mapped_column(ForeignKey("watchlists.id", ondelete="CASCADE"))
    category_id: Mapped[int | None] = mapped_column(ForeignKey("categories.id"), nullable=True)
    region_id: Mapped[int | None] = mapped_column(ForeignKey("regions.id"), nullable=True)
    keyword: Mapped[str | None] = mapped_column(String, nullable=True)

    watchlist: Mapped[Watchlist] = relationship(back_populates="items")


class Attachment(Base):
    __tablename__ = "attachments"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    event_id: Mapped[int] = mapped_column(ForeignKey("events.id", ondelete="CASCADE"))
    filename: Mapped[str] = mapped_column(String)
    content_type: Mapped[str] = mapped_column(String)
    path: Mapped[str] = mapped_column(String)
    uploaded_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    event: Mapped[Event] = relationship(back_populates="attachments")


class AIProposal(Base):
    __tablename__ = "ai_proposals"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    event_id: Mapped[int | None] = mapped_column(ForeignKey("events.id"), nullable=True)
    category_id: Mapped[int | None] = mapped_column(ForeignKey("categories.id"), nullable=True)
    proposed_changes_json: Mapped[str] = mapped_column(Text)
    rationale: Mapped[str | None] = mapped_column(Text, nullable=True)
    status: Mapped[str] = mapped_column(String, default=ProposalStatus.PENDING.value)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
    reviewed_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    category: Mapped[Category] = relationship()


class Prep(Base):
    """Owner's preparedness inventory ('preps'), organised as a 3-stage roadmap:
    Stage 1 Immediate Readiness (0-14d), Stage 2 Resilience (14-180d),
    Stage 3 Self-Reliance / Rebuilding (180+d)."""
    __tablename__ = "preps"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String, index=True)
    category: Mapped[str] = mapped_column(String, default="General")  # Water, Food, Power, Medical, Fuel, Shelter, Comms, Other
    stage: Mapped[int] = mapped_column(Integer, default=1)            # 1 | 2 | 3 (roadmap layer)
    quantity: Mapped[float] = mapped_column(Float, default=0.0)
    unit: Mapped[str] = mapped_column(String, default="units")
    min_quantity: Mapped[float] = mapped_column(Float, default=0.0)  # restock threshold
    priority: Mapped[str] = mapped_column(String, default="MEDIUM")  # HIGH | MEDIUM | LOW
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), onupdate=func.now())


class ScrapeSource(Base):
    """An OSINT website / feed the system can scrape for headlines."""
    __tablename__ = "scrape_sources"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String)
    url: Mapped[str] = mapped_column(String)
    kind: Mapped[str] = mapped_column(String, default="rss")  # rss | html
    tier: Mapped[str] = mapped_column(String, default="OSINT / Early Warning")
    base_confidence: Mapped[str] = mapped_column(String, default="LOW")  # HIGH | MEDIUM | LOW
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    last_fetched: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    items: Mapped[list["ScrapedItem"]] = relationship(back_populates="source", cascade="all, delete-orphan")


class ScrapedItem(Base):
    """A headline / article captured from a ScrapeSource, pending human ingestion."""
    __tablename__ = "scraped_items"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    source_id: Mapped[int] = mapped_column(ForeignKey("scrape_sources.id", ondelete="CASCADE"))
    title: Mapped[str] = mapped_column(Text)
    url: Mapped[str | None] = mapped_column(String, nullable=True)
    summary: Mapped[str | None] = mapped_column(Text, nullable=True)
    published: Mapped[str | None] = mapped_column(String, nullable=True)
    ingested: Mapped[bool] = mapped_column(Boolean, default=False)
    ingested_event_id: Mapped[int | None] = mapped_column(ForeignKey("events.id"), nullable=True)
    fetched_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    source: Mapped[ScrapeSource] = relationship(back_populates="items")


class AppSetting(Base):
    """Persistent key/value app settings (e.g. run_to_store_threshold, lmstudio_*)."""
    __tablename__ = "app_settings"
    key: Mapped[str] = mapped_column(String, primary_key=True)
    value: Mapped[str] = mapped_column(Text)


class PowerOutageSource(Base):
    """A location-scoped feed/page scraped for power outages."""
    __tablename__ = "power_outage_sources"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String)
    country: Mapped[str] = mapped_column(String, index=True)
    region: Mapped[str | None] = mapped_column(String, nullable=True, index=True)  # state / province
    city: Mapped[str | None] = mapped_column(String, nullable=True, index=True)
    url: Mapped[str] = mapped_column(String)
    kind: Mapped[str] = mapped_column(String, default="rss")  # rss | html
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    last_fetched: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    outages: Mapped[list["PowerOutage"]] = relationship(back_populates="source", cascade="all, delete-orphan")


class PowerOutage(Base):
    """A scraped power outage, classified SCHEDULED or UNSCHEDULED."""
    __tablename__ = "power_outages"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    source_id: Mapped[int] = mapped_column(ForeignKey("power_outage_sources.id", ondelete="CASCADE"))
    country: Mapped[str] = mapped_column(String, index=True)
    region: Mapped[str | None] = mapped_column(String, nullable=True)
    city: Mapped[str | None] = mapped_column(String, nullable=True)
    outage_type: Mapped[str] = mapped_column(String)  # SCHEDULED | UNSCHEDULED
    title: Mapped[str] = mapped_column(Text)
    details: Mapped[str | None] = mapped_column(Text, nullable=True)
    url: Mapped[str | None] = mapped_column(String, nullable=True)
    customers_affected: Mapped[int | None] = mapped_column(Integer, nullable=True)
    ingested: Mapped[bool] = mapped_column(Boolean, default=False)
    ingested_event_id: Mapped[int | None] = mapped_column(ForeignKey("events.id"), nullable=True)
    scraped_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    source: Mapped[PowerOutageSource] = relationship(back_populates="outages")
