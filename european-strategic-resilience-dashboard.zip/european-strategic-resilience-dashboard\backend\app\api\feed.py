"""Feed tab: speculation / OSINT feeds (read-only — never drives scores)."""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.models import SpeculationItem, SpeculationSource
from app.schemas import (
    FeedItemOut, FeedScrapeResult, FeedSourceCreate, FeedSourceOut
)
from app.services.speculation_scraper import scrape_speculation
from app.services.scraper import SSRFError, validate_public_url

router = APIRouter(prefix="/feed", tags=["feed"])


@router.get("/sources", response_model=list[FeedSourceOut])
async def list_sources(db: AsyncSession = Depends(get_db), category: str | None = None):
    q = select(SpeculationSource).order_by(SpeculationSource.category, SpeculationSource.name)
    if category:
        q = q.where(SpeculationSource.category == category)
    result = await db.execute(q)
    return list(result.scalars().all())


@router.post("/sources", response_model=FeedSourceOut, status_code=201)
async def create_source(payload: FeedSourceCreate, db: AsyncSession = Depends(get_db)):
    try:
        validate_public_url(payload.url)
    except SSRFError as e:
        raise HTTPException(status_code=400, detail=f"Invalid URL: {e}")
    if payload.kind not in ("rss", "html"):
        raise HTTPException(status_code=400, detail="kind must be 'rss' or 'html'")
    src = SpeculationSource(**payload.model_dump())
    db.add(src)
    await db.commit()
    await db.refresh(src)
    return src


@router.delete("/sources/{source_id}", status_code=204)
async def delete_source(source_id: int, db: AsyncSession = Depends(get_db)):
    src = await db.get(SpeculationSource, source_id)
    if not src:
        raise HTTPException(status_code=404, detail="Source not found")
    await db.delete(src)
    await db.commit()


@router.post("/scrape", response_model=FeedScrapeResult)
async def scrape(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(SpeculationSource).where(SpeculationSource.enabled == True))  # noqa: E712
    sources = list(result.scalars().all())
    if not sources:
        return FeedScrapeResult(sources=0, new_items=0, errors=["No feed sources configured"])
    out = await scrape_speculation(sources, db)
    return FeedScrapeResult(**out)


@router.get("/items", response_model=list[FeedItemOut])
async def list_items(
    db: AsyncSession = Depends(get_db),
    category: str | None = None,
    fringe_level: str | None = None,
    limit: int = 150,
):
    q = select(SpeculationItem).order_by(SpeculationItem.fetched_at.desc()).limit(limit)
    if category:
        q = q.where(SpeculationItem.category == category)
    if fringe_level:
        q = q.where(SpeculationItem.fringe_level == fringe_level)
    result = await db.execute(q)
    return list(result.scalars().all())
