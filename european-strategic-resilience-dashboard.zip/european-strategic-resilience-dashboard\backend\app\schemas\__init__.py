from datetime import date, datetime
from pydantic import BaseModel, ConfigDict


class ORMModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)


# ---------- Category ----------
class CategoryOut(ORMModel):
    id: int
    name: str
    description: str | None
    side: str
    current_score: float
    confidence: str
    trend: str
    confidence_pct: float
    corroboration_count: int
    updated_at: datetime


# ---------- Region ----------
class RegionOut(ORMModel):
    id: int
    name: str
    lat: float
    lng: float


# ---------- Confidence / SourceType / Source ----------
class ConfidenceLevelOut(ORMModel):
    id: int
    name: str
    rank: int
    description: str | None


class SourceTypeOut(ORMModel):
    id: int
    name: str
    default_confidence: str


class SourceOut(ORMModel):
    id: int
    name: str
    source_type_id: int
    url: str | None
    reliability_note: str | None


# ---------- Event ----------
class EventCategoryIn(BaseModel):
    category_id: int
    impact_delta: float = 0.0


class EventCreate(BaseModel):
    title: str
    event_date: date
    source_id: int
    source_type_id: int
    confidence_level_id: int
    summary: str
    evidence_notes: str | None = None
    analyst_notes: str | None = None
    status: str = "REPORTED"
    category_ids: list[int] = []
    region_ids: list[int] = []
    impact_deltas: dict[int, float] = {}


class EventCreateMinimal(BaseModel):
    """Raw data only — the AI classifies everything else."""
    event_date: date
    title: str
    summary: str
    source_name: str | None = None
    min_confidence: str | None = None  # confidence floor (e.g. from an OSINT source tier)
    severity: str | None = None         # LOW | MEDIUM | HIGH | CRITICAL (rate-limit bypass if CRITICAL)


class EventCategoryOut(ORMModel):
    category_id: int
    impact_delta: float
    category: CategoryOut


class EventRegionOut(ORMModel):
    region_id: int
    region: RegionOut


class EventOut(ORMModel):
    id: int
    entry_number: int
    title: str
    event_date: date
    summary: str
    evidence_notes: str | None
    analyst_notes: str | None
    status: str
    severity: str
    created_at: datetime
    source: SourceOut
    source_type: SourceTypeOut
    confidence_level: ConfidenceLevelOut
    category_links: list[EventCategoryOut]
    region_links: list[EventRegionOut]
    attachments: list["AttachmentOut"] = []


class EventAIOut(BaseModel):
    """Result of an AI-classified intake: the stored event plus what the AI decided."""
    event: EventOut
    ai_confidence: str
    ai_categories: list[str]
    ai_regions: list[str]
    ai_source_type: str
    proposals_created: int
    ai_available: bool


# ---------- Dashboard ----------
class ExecutiveSummary(BaseModel):
    threat_score: float
    resilience_score: float
    threat_trend: str
    resilience_trend: str
    strategic_surprise_index: float
    event_density_index: float
    strategic_friction_index: float
    friction_signals: dict[str, float]
    overall_status: str


class CategoryScore(BaseModel):
    id: int
    name: str
    side: str
    current_score: float
    confidence: str
    trend: str
    event_count: int
    confidence_pct: float
    corroboration_count: int


class DashboardData(BaseModel):
    summary: ExecutiveSummary
    threat_categories: list[CategoryScore]
    resilience_categories: list[CategoryScore]
    heatmap: list[dict]
    timeline: list[dict]
    radar: list[dict]
    histogram: list[dict]
    confidence_distribution: list[dict]
    flashpoints: list[dict]


# ---------- AI ----------
class AIPromptIn(BaseModel):
    capability: str  # summarize | trend_changes | suggest_scores | contradictions | daily | weekly | executive
    context: str | None = None


class WatchlistOut(BaseModel):
    markdown: str


class AIProposalOut(ORMModel):
    id: int
    event_id: int | None
    category_id: int | None
    proposed_changes_json: str
    rationale: str | None
    status: str
    created_at: datetime


class AIProposalDecision(BaseModel):
    decision: str  # APPROVED | REJECTED


# ---------- Preps ----------
class PrepBase(BaseModel):
    name: str
    category: str = "General"
    stage: int = 1
    quantity: float = 0.0
    unit: str = "units"
    min_quantity: float = 0.0
    priority: str = "MEDIUM"
    notes: str | None = None


class PrepCreate(PrepBase):
    pass


class PrepUpdate(BaseModel):
    name: str | None = None
    category: str | None = None
    stage: int | None = None
    quantity: float | None = None
    unit: str | None = None
    min_quantity: float | None = None
    priority: str | None = None
    notes: str | None = None


class PrepOut(ORMModel):
    id: int
    name: str
    category: str
    stage: int
    quantity: float
    unit: str
    min_quantity: float
    priority: str
    notes: str | None
    updated_at: datetime


class PrepChatMessage(BaseModel):
    role: str    # user | assistant
    content: str


class PrepChatIn(BaseModel):
    messages: list[PrepChatMessage]  # conversation so far; last message is from the user


class PrepChatOut(BaseModel):
    reply: str


class RunToStoreRequest(BaseModel):
    force: bool = False  # run regardless of threshold


class RunToStoreResult(BaseModel):
    reached: bool
    threshold: float
    current_level: float
    status: str
    suggestions: str  # markdown from the AI
    low_items: list[PrepOut]


class HouseholdReadiness(BaseModel):
    household_size: int
    economic: float | None
    infrastructure: float | None
    threat_environment: float | None
    household_readiness: float | None


class HouseholdSizeIn(BaseModel):
    size: int


# ---------- Scraping ----------
class ScrapeSourceCreate(BaseModel):
    name: str
    url: str
    kind: str = "rss"
    tier: str = "OSINT / Early Warning"
    base_confidence: str = "LOW"
    enabled: bool = True


class ScrapeSourceOut(ORMModel):
    id: int
    name: str
    url: str
    kind: str
    tier: str
    base_confidence: str
    enabled: bool
    last_fetched: datetime | None


class ScrapedItemOut(ORMModel):
    id: int
    source_id: int
    title: str
    url: str | None
    summary: str | None
    published: str | None
    ingested: bool
    ingested_event_id: int | None
    fetched_at: datetime
    topics: list[str] = []


class ScrapeRunResult(BaseModel):
    sources: int
    new_items: int
    errors: list[str]


class IngestAllResult(BaseModel):
    attempted: int
    succeeded: int
    failed: int
    errors: list[str]


# ---------- Power outages ----------
class OutageSourceCreate(BaseModel):
    name: str
    country: str
    region: str | None = None
    city: str | None = None
    url: str
    kind: str = "rss"
    enabled: bool = True


class OutageSourceOut(ORMModel):
    id: int
    name: str
    country: str
    region: str | None
    city: str | None
    url: str
    kind: str
    enabled: bool
    last_fetched: datetime | None


class OutageOut(ORMModel):
    id: int
    source_id: int
    country: str
    region: str | None
    city: str | None
    outage_type: str
    title: str
    details: str | None
    url: str | None
    customers_affected: int | None
    ingested: bool
    ingested_event_id: int | None
    scraped_at: datetime


class OutageScrapeRequest(BaseModel):
    country: str | None = None
    region: str | None = None
    city: str | None = None


class OutageScrapeResult(BaseModel):
    sources: int
    new_outages: int
    errors: list[str]


class OutageLocations(BaseModel):
    countries: list[str]
    regions: dict[str, list[str]]   # country -> regions
    cities: dict[str, list[str]]    # "country|region" -> cities


# ---------- Attachments ----------
class AttachmentOut(ORMModel):
    id: int
    filename: str
    content_type: str
    path: str
    uploaded_at: datetime


# ---------- Settings ----------
class AppSettingsOut(BaseModel):
    lmstudio_base_url: str
    lmstudio_model: str
    run_to_store_threshold: float
    auto_approve: bool


class AppSettingsIn(BaseModel):
    lmstudio_base_url: str | None = None
    lmstudio_model: str | None = None
    run_to_store_threshold: float | None = None
    auto_approve: bool | None = None


# ---------- Report ----------
class ReportCreate(BaseModel):
    report_type: str  # DAILY | WEEKLY | EXECUTIVE
    format: str = "markdown"


class ReportOut(ORMModel):
    id: int
    report_type: str
    content_json: str
    format: str
    created_at: datetime


# ---------- Settings ----------
class SettingsOut(BaseModel):
    lmstudio_base_url: str
    lmstudio_model: str


class SettingsIn(BaseModel):
    lmstudio_base_url: str
    lmstudio_model: str
