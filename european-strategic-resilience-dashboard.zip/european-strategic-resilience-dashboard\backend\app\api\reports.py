import json
from datetime import datetime

from fastapi import APIRouter, Depends, Response
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.database import get_db
from app.models import Event, EventCategory, Report
from app.schemas import ReportCreate, ReportOut
from app.services.scoring import flashpoints, get_category_scores
from app.services import report_service

router = APIRouter(prefix="/reports", tags=["reports"])


async def _gather_report_data(db: AsyncSession) -> dict:
    cats = await get_category_scores(db)
    threat = sorted([c for c in cats if c.side == "threat"], key=lambda c: c.current_score, reverse=True)
    resilience = sorted([c for c in cats if c.side == "resilience"], key=lambda c: c.current_score, reverse=True)

    result = await db.execute(
        select(Event).options(selectinload(Event.category_links).selectinload(EventCategory.category))
        .order_by(Event.event_date.desc()).limit(25)
    )
    events = list(result.scalars().unique().all())

    major_changes = [f"{c.name} at {c.current_score}/10 ({c.trend})" for c in threat[:5]]
    rising_risks = [f"{c.name} — {c.current_score}/10, trend {c.trend}, confidence {c.confidence}"
                    for c in threat if c.trend == "UP"][:5]
    rising_resilience = [f"{c.name} — {c.current_score}/10, trend {c.trend}, confidence {c.confidence}"
                         for c in resilience if c.trend == "UP"][:5]

    exec_summary = (
        f"Threat environment elevated at {sum(c.current_score for c in threat)/max(len(threat),1):.1f}/10. "
        f"Resilience environment holds at {sum(c.current_score for c in resilience)/max(len(resilience),1):.1f}/10. "
        f"Top pressure: {threat[0].name if threat else 'N/A'}. "
        f"Strongest adaptation: {resilience[0].name if resilience else 'N/A'}."
    )

    watch_list = [f"{c.name} ({c.side}) — {c.current_score}/10" for c in (threat + resilience)[:8]]

    flash = await flashpoints(db)
    flash_lines = [
        f"{f['region']} — {f['event_count']} events; top: " +
        ", ".join(f"{c['name']} {c['score']}/10" for c in f["top_categories"])
        for f in flash
    ]
    flashpoints_text = (
        "Key flashpoints (hottest regions by activity × threat intensity):\n" +
        "\n".join(f"- {l}" for l in flash_lines)
        if flash_lines else "No concentrated flashpoints in the current window."
    )

    strategic = (
        "The dashboard tracks indicators, trends and threat signals. It is not a prediction engine. "
        "Multiple concurrent elevated categories indicate an ORANGE environment. "
        "Resilience indicators must be monitored alongside risk indicators to avoid a one-sided assessment.\n\n"
        + flashpoints_text
    )

    return {
        "title": datetime.utcnow().strftime("%Y-%m-%d"),
        "executive_summary": exec_summary,
        "major_changes": major_changes,
        "rising_risks": rising_risks,
        "rising_resilience": rising_resilience,
        "watch_list": watch_list,
        "strategic_assessment": strategic,
        "flashpoints": flash,
        "events": [{"title": e.title, "date": str(e.event_date), "status": e.status} for e in events],
    }


@router.post("", response_model=ReportOut)
async def create_report(payload: ReportCreate, db: AsyncSession = Depends(get_db)):
    data = await _gather_report_data(db)
    content = report_service.build_markdown_report(data)
    report = Report(
        report_type=payload.report_type,
        content_json=json.dumps({"markdown": content, "data": data}),
        format=payload.format,
    )
    db.add(report)
    await db.commit()
    await db.refresh(report)
    return report


@router.get("", response_model=list[ReportOut])
async def list_reports(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Report).order_by(Report.created_at.desc()).limit(50))
    return list(result.scalars().all())


@router.get("/export/{report_id}")
async def export_report(report_id: int, format: str = "markdown", db: AsyncSession = Depends(get_db)):
    report = await db.get(Report, report_id)
    if not report:
        return Response(status_code=404)
    payload = json.loads(report.content_json)
    data = payload.get("data", {})

    if format == "docx":
        content = report_service.build_docx_report(data)
        return Response(
            content=content,
            media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            headers={"Content-Disposition": f"attachment; filename=briefing_{report_id}.docx"},
        )
    if format == "pdf":
        content = report_service.build_pdf_report(data)
        return Response(
            content=content,
            media_type="application/pdf",
            headers={"Content-Disposition": f"attachment; filename=briefing_{report_id}.pdf"},
        )
    md = report_service.build_markdown_report(data)
    return Response(
        content=md,
        media_type="text/markdown",
        headers={"Content-Disposition": f"attachment; filename=briefing_{report_id}.md"},
    )


@router.get("/briefing")
async def briefing_preview(db: AsyncSession = Depends(get_db)):
    data = await _gather_report_data(db)
    return data
